import React, { useState, useEffect, useCallback } from 'react';
import styles from '@/styles/components/popup/Popup.module.css';
import { Service } from '@/config/types';
import { sendMessage } from '@/utils/chrome';
import { connectToBackground } from '@/utils/keepAlive';

const App: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [activeService, setActiveService] = useState<Service | null>(null);
  const [isPanelEnabled, setIsPanelEnabled] = useState(false);

  useEffect(() => {
    connectToBackground('popup');
  }, []);

  const getCurrentTab = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  };
  
  const openOptionsPage = () => sendMessage('openOptionsPage');

  const updatePanelState = useCallback(async () => {
    const tab = await getCurrentTab();
    if (tab?.id) {
      try {
        const { enabled } = await chrome.sidePanel.getOptions({ tabId: tab.id });
        setIsPanelEnabled(!!enabled);
        if (enabled) {
          const service = await sendMessage<Service | null>('getActiveService', null);
          setActiveService(service);
        } else {
          setActiveService(null);
        }
      } catch (e) {
        console.warn("Could not access side panel API.", e);
        setIsPanelEnabled(false);
        setActiveService(null);
      }
    }
  }, []);

  const loadData = useCallback(async () => {
    const allServices: Service[] = (await sendMessage('getServices')) || [];
    setServices(allServices);
    await updatePanelState();
  }, [updatePanelState]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleTogglePanel = async () => {
    const tab = await getCurrentTab();
    if (!tab?.id) return;
    const windowId = tab.windowId;

    if (isPanelEnabled) {
      await chrome.sidePanel.setOptions({ tabId: tab.id, enabled: false });
    } else {
      await chrome.sidePanel.setOptions({ tabId: tab.id, enabled: true });
      await chrome.sidePanel.open({ windowId });
    }
    await updatePanelState();
  };

  const handleOpenInPanel = async (service: Service) => {
    const tab = await getCurrentTab();
    if (!tab?.id) return;
    const windowId = tab.windowId;

    await sendMessage('setActiveService', { serviceId: service.id });
    
    await chrome.sidePanel.setOptions({ tabId: tab.id, enabled: true });
    await chrome.sidePanel.open({ windowId });
    await updatePanelState();
  };

  const handleOpenInTab = (service: Service) => {
    sendMessage('openServiceInTab', { serviceId: service.id });
  };

  return (
    <div className={styles.app}>
      <header className={styles.header}>
        <h1 className={styles.title}>ChatDemon</h1>
        <div className={styles.actions}>
          <button
            onClick={handleTogglePanel}
            className={styles.actionButton}
            disabled={services.length === 0}
            title={isPanelEnabled ? 'Hide Side Panel' : 'Show Side Panel'}
          >
            {isPanelEnabled ? 'Hide Panel' : 'Show Panel'}
          </button>
          <button onClick={openOptionsPage} className={styles.actionButton} title="Manage Services">
            Manage
          </button>
        </div>
      </header>
      <main className={styles.main}>
        {services.length > 0 ? (
          services.map((service) => (
            <div key={service.id} className={styles.serviceCard}>
              <span className={styles.serviceName}>{service.name}</span>
              <div className={styles.serviceActions}>
                <button onClick={() => handleOpenInTab(service)}>Tab</button>
                <button onClick={() => handleOpenInPanel(service)}>
                  {isPanelEnabled && activeService?.id === service.id ? 'Active' : 'Panel'}
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className={styles.noServices}>
            <p>No services configured.</p>
            <button onClick={openOptionsPage}>Add a Service</button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App; 
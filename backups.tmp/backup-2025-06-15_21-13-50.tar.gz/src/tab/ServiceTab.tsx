import React, { useState, useEffect } from 'react';
import { Service } from '@/config/types';
import { storageManager } from "@/storage/storageManager";
import { sendMessage } from '@/utils/chrome';
import ViewRouter from "@/components/ViewRouter";
import '@/styles/global.css';
import styles from '@/styles/components/tab/ServiceTab.module.css';
import { connectToBackground } from '@/utils/keepAlive';

const ServiceTab: React.FC = () => {
    const [service, setService] = useState<Service | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        connectToBackground('service-tab');

        const loadService = async () => {
            const params = new URLSearchParams(window.location.search);
            const serviceId = params.get('serviceId');
            if (!serviceId) {
                setError('No Service ID provided in URL.');
                return;
            }
            
            try {
                const allServices: Service[] = (await storageManager.get('services')) || [];
                const activeService = allServices.find(s => s.id === serviceId);

                if (activeService) {
                    setService(activeService);
                } else {
                    setError(`Service with ID "${serviceId}" not found.`);
                }
            } catch (e) {
                console.error("Failed to load service:", e);
                setError("Failed to load service data. See console for details.");
            }
        };
        loadService();
    }, []);
    
    const handleSwitchToPanel = async () => {
        if (!service) return;
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.id) {
            try {
                // Set the active service first
                await sendMessage('setActiveService', { serviceId: service.id });
                
                // Configure and open the side panel for the current tab
                await chrome.sidePanel.setOptions({ 
                    tabId: tab.id, 
                    path: 'src/sidepanel/index.html', 
                    enabled: true 
                });
                await chrome.sidePanel.open({ tabId: tab.id });
                
                // Close the current tab, this is more reliable
                // window.close() can have permission issues.
                chrome.tabs.remove(tab.id);

            } catch (error) {
                console.error("Failed to switch to panel:", error);
                setError("Could not open the panel. See console for details.");
            }
        }
    };

    const renderContent = () => {
        if (error) return <div className={styles.container}><h2 className={styles.error}>{error}</h2></div>;
        if (!service) return <div className={styles.container}><h2>Loading...</h2></div>;
        
        return (
            <div className={styles.container}>
                <main className={styles.mainContent}>
                    <ViewRouter service={service} isTab={true} />
                </main>
            </div>
        );
    };

    return renderContent();
};

export default ServiceTab; 
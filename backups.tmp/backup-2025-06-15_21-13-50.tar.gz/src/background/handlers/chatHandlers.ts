import { storageManager } from "@/storage/storageManager";
import { connectorManager } from "../connectors";
import { getChatHistory as getHistoryFromStorage, saveChatHistory, getServices } from "../utils/storage";
import type { ChatMessage, RequestHandler, ChatConnector, LLMModel, ImageModel, ImageGenConnector } from "../../config/types";
import type { Service, Conversation } from "@/config/types";

// Constants
const CHAT_HISTORY_LIMIT = 100; // Maximum number of messages to keep in history

interface ChatRequest {
  serviceId: string;
  messages: ChatMessage[];
  model?: string;
  options?: Record<string, unknown>;
}

// Define ChatConnector locally to avoid circular dependencies
interface ChatConnector {
  chat: (messages: ChatMessage[], model: string, options: any) => Promise<ChatMessage>;
  getModels(): Promise<LLMModel[]>;
}

export const getConversations: RequestHandler<{ serviceId: string }, Conversation[]> = async ({ serviceId }) => {
  const allConversations = await storageManager.get<Conversation[]>('conversations', []);
  return allConversations.filter((c: Conversation) => c.serviceId === serviceId).sort((a: Conversation, b: Conversation) => b.timestamp - a.timestamp);
};

export const getActiveConversation: RequestHandler<{ serviceId: string }, string | null> = async ({ serviceId }) => {
  const activeIds = await storageManager.get<Record<string, string>>('activeConversations', {});
  return activeIds[serviceId] || null;
};

export const setActiveConversation: RequestHandler<{ serviceId: string, conversationId: string }, void> = async ({ serviceId, conversationId }) => {
  const activeIds = await storageManager.get<Record<string, string>>('activeConversations', {});
  activeIds[serviceId] = conversationId;
  await storageManager.set('activeConversations', activeIds);
};

/**
 * Send a chat message and handle the conversation history
 */
export const sendMessage: RequestHandler<{
  serviceId: string;
  messages: ChatMessage[];
  model: string;
  conversationId?: string | null;
}, { fullHistory: ChatMessage[], conversation: Conversation }> = async ({
  serviceId,
  messages,
  model,
  conversationId,
}) => {
  const services = await storageManager.get<Service[]>('services', []);
  const service = services.find((s: Service) => s.id === serviceId);
  if (!service) throw new Error("Service not found");

  const connector = (await connectorManager.getConnector(service)) as ChatConnector | null;
  if (!connector) throw new Error("Could not get connector for service");
  
  const response = await connector.chat(messages, model, {});

  const fullHistory = [...messages, response];

  let conversation;
  const allConversations = await storageManager.get<Conversation[]>('conversations', []);
  const conversationIndex = conversationId ? allConversations.findIndex((c: Conversation) => c.id === conversationId) : -1;

  if (conversationIndex > -1) {
    conversation = allConversations[conversationIndex];
    conversation.messages = fullHistory;
    conversation.updatedAt = Date.now();
    conversation.timestamp = Date.now();
    allConversations[conversationIndex] = conversation;
  } else {
    conversation = {
      id: `conv_${Date.now()}`,
      serviceId,
      title: messages[0]?.content.substring(0, 30) || 'New Chat',
      messages: fullHistory,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      timestamp: Date.now(),
    };
    allConversations.unshift(conversation);
  }

  await storageManager.set('conversations', allConversations);
  await setActiveConversation({ serviceId, conversationId: conversation.id });

  return { fullHistory, conversation };
};

/**
 * Clear chat history for a service
 */
export const clearChatHistory: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }) => {
  const activeIds = await storageManager.get<Record<string, string>>('activeConversations', {});
  delete activeIds[serviceId];
  await storageManager.set('activeConversations', activeIds);
};

/**
 * Get available models for a service
 */
export const getModels: RequestHandler<{serviceId: string}, LLMModel[]> = async ({ serviceId }) => {
    const services = await storageManager.get<Service[]>('services', []);
    const service = services.find((s: Service) => s.id === serviceId);
    if (!service) throw new Error("Service not found");
    
    const connector = await connectorManager.getConnector(service) as ChatConnector | null;
    if (!connector) throw new Error("Could not get connector for service");

    return connector.getModels();
}

/**
 * Get chat history for a service
 */
export const getChatHistory: RequestHandler<{
  serviceId: string;
  conversationId?: string;
}, ChatMessage[]> = async ({ serviceId, conversationId }) => {
  if (!conversationId) return [];

  const allConversations = await storageManager.get<Conversation[]>('conversations', []);
  const conversation = allConversations.find((c: Conversation) => c.id === conversationId && c.serviceId === serviceId);
  
  return conversation ? conversation.messages : [];
};

export const deleteConversation: RequestHandler<{ serviceId: string, conversationId: string }, void> = async ({ conversationId }) => {
  let allConversations = await storageManager.get<Conversation[]>('conversations', []);
  allConversations = allConversations.filter((c: Conversation) => c.id !== conversationId);
  await storageManager.set('conversations', allConversations);
};

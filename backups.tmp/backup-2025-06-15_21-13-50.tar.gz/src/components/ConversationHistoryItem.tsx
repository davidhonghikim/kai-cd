import React from 'react';
import styles from '@/styles/components/ChatInterface.module.css'; // Reuse styles for now

interface ConversationHistoryItemProps {
  conversation: { id: string; title: string };
  isActive: boolean;
  onClick: (id: string) => void;
  onDelete: (id: string) => void;
}

const ConversationHistoryItem: React.FC<ConversationHistoryItemProps> = ({
  conversation,
  isActive,
  onClick,
  onDelete,
}) => {
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering onClick
    onDelete(conversation.id);
  };
  
  return (
    <div 
      className={`${styles.historyItem} ${isActive ? styles.activeHistoryItem : ''}`}
      onClick={() => onClick(conversation.id)}
    >
      <span className={styles.historyItemTitle}>{conversation.title}</span>
      <button onClick={handleDelete} className={styles.deleteHistoryButton}>X</button>
    </div>
  );
};

export default ConversationHistoryItem; 
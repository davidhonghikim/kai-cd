import React from 'react';
import styles from '@/styles/components/IframeView.module.css';

interface IframeViewProps {
  url: string;
  serviceName: string;
}

const IframeView: React.FC<IframeViewProps> = ({ url, serviceName }) => {
  return (
    <div className={styles.iframeContainer}>
      <iframe src={url} title={serviceName} className={styles.iframe} />
    </div>
  );
};

export default IframeView; 
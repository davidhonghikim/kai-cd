import React, { useState, useEffect } from 'react';
import { Service, LLMModel } from '@/config/types';
import { sendMessage } from '@/utils/chrome';
import styles from '@/styles/components/ChatInterface.module.css';
import ChatHeader from './ChatHeader';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import remarkGfm from 'remark-gfm';
import ConversationHistoryItem from './ConversationHistoryItem';

interface ChatInterfaceProps {
  service: Service;
  isPanel?: boolean;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ service, isPanel = false }) => {
  const [models, setModels] = useState<LLMModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<any[]>([]);
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  useEffect(() => {
    const fetchModelsAndHistory = async () => {
      if (service) {
        try {
          // Fetch models
          const fetchedModels = await sendMessage<LLMModel[]>('getModels', { serviceId: service.id });
          setModels(fetchedModels || []);
          setSelectedModel(service.model || (fetchedModels && fetchedModels[0]?.id) || '');
          
          // Fetch conversations
          const fetchedConversations = await sendMessage<any[]>('getConversations', { serviceId: service.id });
          setConversations(fetchedConversations || []);

          // Set active conversation and load its messages
          const lastActiveId = await sendMessage<string | null>('getActiveConversation', { serviceId: service.id });
          const initialConversation = fetchedConversations?.find(c => c.id === lastActiveId) || fetchedConversations?.[0];

          if (initialConversation) {
            await handleSelectConversation(initialConversation.id, true);
          } else {
            setMessages([]);
          }

        } catch (error) {
          console.error("Failed to fetch models or history:", error);
        }
      }
    };
    fetchModelsAndHistory();
  }, [service]);

  const handleModelChange = (modelId: string) => {
    setSelectedModel(modelId);
    sendMessage('setDefaultModel', { serviceId: service.id, modelId });
  };

  const handleSendMessage = async () => {
    if (!prompt.trim()) return;

    const newMessage = { role: 'user', content: prompt };
    const updatedMessages = [...messages, newMessage];
    
    setMessages(updatedMessages);
    setPrompt('');

    try {
      const { fullHistory, conversation } = await sendMessage('sendMessage', {
        serviceId: service.id,
        messages: updatedMessages,
        model: selectedModel,
        conversationId: activeConversationId
      });
      setMessages(fullHistory);
      if (!activeConversationId) {
        setActiveConversationId(conversation.id);
        setConversations(prev => [conversation, ...prev]);
      } else if (activeConversationId !== conversation.id) {
        setActiveConversationId(conversation.id);
        setConversations(prev => [conversation, ...prev.filter(c => c.id !== conversation.id)]);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      let displayMessage = 'An unknown error occurred.';
      if (error instanceof Error) {
        if (error.message.includes('403')) {
          displayMessage = 'Access Denied (Error 403). Please check if an API key is required and correctly configured for this service in the settings.';
        } else {
          displayMessage = error.message;
        }
      }
      setMessages(prev => [...prev, { role: 'assistant', content: `Error: ${displayMessage}` }]);
    }
  };

  const handleNewChat = async () => {
    setActiveConversationId(null);
    setMessages([]);
    if (service) {
      await sendMessage('clearChatHistory', { serviceId: service.id });
    }
  };

  const handleSelectConversation = async (conversationId: string, initialLoad = false) => {
    if (!service) return;
    setActiveConversationId(conversationId);
    if (!initialLoad) {
      await sendMessage('setActiveConversation', { serviceId: service.id, conversationId });
    }
    const chatHistory = await sendMessage<any[]>('getChatHistory', { serviceId: service.id, conversationId: conversationId });
    setMessages(chatHistory || []);
  };

  const handleDeleteConversation = async (conversationId: string) => {
    if (!service) return;
    await sendMessage('deleteConversation', { serviceId: service.id, conversationId });
    setConversations(prev => prev.filter(c => c.id !== conversationId));
    if (activeConversationId === conversationId) {
      setActiveConversationId(null);
      setMessages([]);
    }
  };
  
  const handleSettings = () => {
    sendMessage('openOptionsPage');
  };

  return (
    <div className={`${styles.appContainer} ${isPanel ? styles.panel : ''}`}>
      <div className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <button className={styles.newChatButton} onClick={handleNewChat}>+ New Chat</button>
        </div>
        <div className={styles.chatHistory}>
          <h2 className={styles.historyTitle}>History</h2>
          {conversations.map(convo => (
            <ConversationHistoryItem
              key={convo.id}
              conversation={convo}
              isActive={convo.id === activeConversationId}
              onClick={() => handleSelectConversation(convo.id)}
              onDelete={handleDeleteConversation}
            />
          ))}
        </div>
        <div className={styles.sidebarFooter}>
          <button className={styles.settingsButton} onClick={handleSettings}>Settings</button>
        </div>
      </div>
      <div className={styles.mainChatArea}>
        <ChatHeader
          service={service}
          isTab={!isPanel}
          models={models}
          selectedModel={selectedModel}
          onModelChange={handleModelChange}
        />
        <div className={styles.conversationArea}>
          {messages.length === 0 ? (
             <div className={`${styles.message} ${styles.aiMessage}`}>
              <p>Hello! This is the chat interface for {service.name}. Select a conversation or start a new one.</p>
            </div>
          ) : (
            messages.map((msg, index) => (
              <div key={index} className={`${styles.message} ${msg.role === 'user' ? styles.userMessage : styles.aiMessage}`}>
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  components={{
                    code(props) {
                      const { children, className, node, ...rest } = props;
                      const match = /language-(\w+)/.exec(className || '');
                      return match ? (
                        <SyntaxHighlighter
                          PreTag="div"
                          language={match[1]}
                          style={vscDarkPlus as any}
                        >
                          {String(children).replace(/\n$/, '')}
                        </SyntaxHighlighter>
                      ) : (
                        <code {...rest} className={className}>
                          {children}
                        </code>
                      );
                    },
                  }}
                >
                  {msg.content}
                </ReactMarkdown>
              </div>
            ))
          )}
        </div>
        <div className={styles.inputArea}>
          <textarea
            className={styles.textInput} 
            placeholder="Send a message..." 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
            rows={1}
          />
          <button className={styles.sendButton} onClick={handleSendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
import React from 'react';
import { Service, SERVICE_TYPES, SERVICE_TYPE_TO_CATEGORY, SERVICE_CATEGORIES } from '@/config/types';
import ChatInterface from './ChatInterface';
import IframeView from './IframeView';
import A1111View from '@/views/A1111View';
import ComfyUIView from '@/views/ComfyUIView';

interface ViewRouterProps {
  service: Service;
  isTab?: boolean;
}

const ViewRouter: React.FC<ViewRouterProps> = ({ service, isTab = false }) => {
  if (isTab) {
    // These services have full UIs that should be displayed in a tab
    if (
      service.type === SERVICE_TYPES.OPEN_WEBUI ||
      service.type === SERVICE_TYPES.A1111 ||
      service.type === SERVICE_TYPES.COMFY_UI ||
      service.type === SERVICE_TYPES.N8N
    ) {
      return <IframeView url={service.url} serviceName={service.name} />;
    }
  } else {
    // In the side panel, some services have dedicated compact UIs
    if (service.type === SERVICE_TYPES.A1111) {
      return <A1111View service={service} isTab={false} />;
    }
    if (service.type === SERVICE_TYPES.COMFY_UI) {
      return <ComfyUIView service={service} isTab={false} />;
    }
  }

  const category = SERVICE_TYPE_TO_CATEGORY[service.type];

  // LLM services use the custom chat interface
  if (category === SERVICE_CATEGORIES.LLM) {
    return <ChatInterface service={service} isPanel={!isTab} />;
  }
  
  // Fallback for any other service type, e.g., a generic automation service in the panel
  return <IframeView url={service.url} serviceName={service.name} />;
};

export default ViewRouter;

import React from 'react';
import { Service } from '@/config/types';
import { sendMessage } from '@/utils/chrome';
import styles from '@/styles/components/ViewHeader.module.css';

interface ViewHeaderProps {
  service: Service;
  isTab?: boolean;
}

const ViewHeader: React.FC<ViewHeaderProps> = ({ service, isTab = false }) => {
  const handleSwitchView = async () => {
    if (isTab) {
      // Logic to switch from a tab to the panel
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) {
        await sendMessage('setActiveService', { serviceId: service.id });
        await chrome.sidePanel.setOptions({ tabId: tab.id, enabled: true });
        await chrome.sidePanel.open({ tabId: tab.id });
        await chrome.tabs.remove(tab.id);
      }
    } else {
      // Logic to switch from the panel to a tab
      sendMessage('openServiceInTab', { serviceId: service.id });
    }
  };

  return (
    <header className={styles.header}>
      <h1 className={styles.title}>{service.name}</h1>
      <button onClick={handleSwitchView} className={styles.switchButton}>
        {isTab ? 'Switch to Panel' : 'Switch to Tab'}
      </button>
    </header>
  );
};

export default ViewHeader; 
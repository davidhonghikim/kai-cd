const fs = require('fs');
const path = require('path');

// Mapping of old import paths to new ones
const importMap = {
  // SidePanel imports
  "from './SidePanel.module.css'": "from '../../styles/components/sidepanel/SidePanel.module.css'",
  "from './ChatMessage.module.css'": "from '../../styles/components/sidepanel/ChatMessage.module.css'",
  "from './A1111View.module.css'": "from '../../styles/components/sidepanel/A1111View.module.css'",
  "from './ComfyUIView.module.css'": "from '../../styles/components/sidepanel/ComfyUIView.module.css'",
  
  // Popup imports
  "from './AdvancedSettings.module.css'": "from '../../styles/components/popup/AdvancedSettings.module.css'",
  "from './App.module.css'": "from '../../styles/components/popup/App.module.css'",
  "from './ArtifactGallery.module.css'": "from '../../styles/components/popup/ArtifactGallery.module.css'",
  "from './HistoryViewer.module.css'": "from '../../styles/components/popup/HistoryViewer.module.css'",
  "from './Message.module.css'": "from '../../styles/components/popup/Message.module.css'",
  "from './PromptManager.module.css'": "from '../../styles/components/popup/PromptManager.module.css'",
  
  // Options imports
  "from './Options.module.css'": "from '../../styles/components/options/Options.module.css'"
};

// Files to update
const filesToUpdate = [
  'src/sidepanel/SidePanel.tsx',
  'src/sidepanel/ChatMessage.tsx',
  'src/sidepanel/A1111View.tsx',
  'src/sidepanel/ComfyUIView.tsx',
  'src/popup/AdvancedSettings.tsx',
  'src/popup/App.tsx',
  'src/popup/ArtifactGallery.tsx',
  'src/popup/HistoryViewer.tsx',
  'src/popup/Message.tsx',
  'src/popup/PromptManager.tsx',
  'src/options/Options.tsx',
  'src/options/ServiceDetails.tsx',
  'src/options/ServiceForm.tsx'
];

// Update imports in files
filesToUpdate.forEach(filePath => {
  if (fs.existsSync(filePath)) {
    let content = fs.readFileSync(filePath, 'utf8');
    let updated = false;
    
    Object.entries(importMap).forEach(([oldImport, newImport]) => {
      if (content.includes(oldImport)) {
        content = content.replace(oldImport, newImport);
        updated = true;
        console.log(`Updated import in ${filePath}: ${oldImport} -> ${newImport}`);
      }
    });
    
    if (updated) {
      fs.writeFileSync(filePath, content, 'utf8');
    }
  }
});

console.log('CSS import updates completed!');

---
id: advanced-settings
slug: /advanced-settings
sidebar_label: Advanced Settings
---

# Advanced Settings System

This document describes the modular, dynamic advanced settings system for ChatDemon. It is intended for both users and developers.

## Features

- 🧩 Modular: Each settings group (UI, Network, Advanced, etc.) is a separate, dynamically loaded component.
- 🛠️ Centralized Config: All settings are defined in a single schema file (`src/config/settingsSchema.ts`).
- 🔄 Import/Export: Easily back up or restore all settings and server lists as JSON.
- 🧑‍💻 Power User Options: Exposes advanced and experimental options for those who need them.

## User Guide

### Accessing Advanced Settings
- Open the app and click the settings icon.
- Choose "Advanced Settings" to open the modal.
- Use the sidebar to switch between sections (UI, Network, Advanced, etc.).
- Edit settings as needed. Changes are saved automatically.
- Use the Import/Export buttons to back up or restore your settings and server list.

### Import/Export
- **Export:** Click "Export Settings" to download a JSON file containing all settings and servers.
- **Import:** Click "Import Settings" and select a compatible JSON file to restore settings and servers.

## Developer Guide

### Structure
- **Schema:** All settings are defined in `src/config/settingsSchema.ts` as an array of objects. Each object includes:
  - `key`: Unique identifier
  - `label`: Display name
  - `type`: Field type (`string`, `number`, `boolean`, `select`, `json`)
  - `default`: Default value
  - `description`: Help text
  - `section`: Which section/component it belongs to
  - `options`: (For `select` fields) List of allowed values
- **Modal:** `src/components/settings/AdvancedSettingsModal.tsx` dynamically loads section components and renders fields based on the schema.
- **Sections:** Each section is a separate file in `src/components/settings/sections/`, e.g., `NetworkSettingsSection.tsx`.
- **Import/Export:** Logic is in `src/utils/settingsIO.ts` (to be implemented).

### Adding a New Setting
1. Add a new object to `SETTINGS_SCHEMA` in `settingsSchema.ts`.
2. If it's a new section, create a new section component in `sections/`.
3. The modal will automatically pick up the new section and field.

### Extending Import/Export
- To include new data (e.g., user profiles), update the logic in `settingsIO.ts`.

## Example Schema Entry
```ts
{
  key: 'timeout',
  label: 'Network Timeout (seconds)',
  type: 'number',
  default: 30,
  description: 'Timeout for API requests.',
  section: 'Network',
}
```

---

This system is designed for easy maintenance, extensibility, and power-user flexibility. 
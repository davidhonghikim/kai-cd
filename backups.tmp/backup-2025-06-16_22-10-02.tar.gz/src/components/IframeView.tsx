import React from 'react';
import styles from '@/styles/components/IframeView.module.css';

interface IframeViewProps {
  url: string;
  serviceName: string;
}

const IframeView: React.FC<IframeViewProps> = ({ url, serviceName }) => {
  return (
    <div className={styles.iframeContainer}>
      <iframe 
        src={url} 
        title={serviceName} 
        className={styles.iframe} 
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
        allow="clipboard-write; clipboard-read; fullscreen; accelerometer; camera; microphone; geolocation; encrypted-media;"
      />
    </div>
  );
};

export default IframeView; 
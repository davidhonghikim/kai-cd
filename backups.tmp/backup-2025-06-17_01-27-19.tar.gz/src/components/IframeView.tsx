import React from 'react';
import styles from '@/styles/components/IframeView.module.css';
import ViewHeader from './ViewHeader';
import { Service } from '@/config/types';

interface IframeViewProps {
  url: string;
  serviceName: string;
  service: Service;
  isTab?: boolean;
}

const IframeView: React.FC<IframeViewProps> = ({ url, serviceName, service, isTab = false }) => {
  return (
    <div className={styles.container}>
      <ViewHeader service={service} isTab={isTab} />
      <div className={styles.iframeContainer}>
        <iframe 
          src={url} 
          title={serviceName} 
          className={styles.iframe} 
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
          allow="clipboard-write; clipboard-read; fullscreen; accelerometer; camera; microphone; geolocation; encrypted-media;"
        />
      </div>
    </div>
  );
};

export default IframeView; 
import { Service } from '../types';
import { SERVICE_TYPES } from './constants';

export const DEFAULT_SERVERS: Service[] = [
  {
    id: 'default_1',
    name: 'Default Server',
    type: SERVICE_TYPES.OLLAMA,
    url: 'http://localhost:11434',
    status: 'inactive',
    createdAt: Date.now(),
    updatedAt: Date.now()
  }
]; 
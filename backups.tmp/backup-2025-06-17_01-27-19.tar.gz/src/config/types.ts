import { ServiceType, ServiceCategory } from './constants';

export * from './constants';

// Add missing types
export interface Prompt extends PromptTemplate {
  id: string;
  name: string;
  content: string;
  description?: string;
  tags?: string[];
  isFavorite?: boolean;
  isDefault?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface ImageArtifact {
  id: string;
  prompt: string;
  imageUrl: string;
  model?: string;
  negativePrompt?: string;
  width: number;
  height: number;
  steps: number;
  cfgScale: number;
  sampler: string;
  seed: number;
  serviceId: string;
  timestamp: number;
}

export interface ServiceConfig {
  id: string;
  name: string;
  type: ServiceType;
  url: string;
  model?: string; // Default model for the service
  category: ServiceCategory;
  // Additional metadata that might be useful
  description?: string;
  isDefault?: boolean;
  isActive?: boolean;
  // Timestamps
  createdAt?: number;
  updatedAt?: number;
  // UI state (not persisted)
  isConnected?: boolean;
  isLoading?: boolean;
  error?: string;
}

export interface LLMModel {
  id: string;
  name: string;
  description?: string;
  format?: string;
  size?: string;
  parameters?: number;
  contextWindow?: number;
  // Model capabilities
  supportsChat?: boolean;
  supportsCompletion?: boolean;
  supportsEmbedding?: boolean;
  // Timestamps
  createdAt?: number;
  updatedAt?: number;
}

export interface ImageModel {
  id: string;
  name: string;
  type?: 'checkpoint' | 'vae' | 'lora' | 'embedding' | 'hypernetwork';
  baseModel?: string;
  filename: string;
  hash?: string;
  size?: number;
  metadata?: Record<string, any>;
  // Model metadata
  title?: string;
  author?: string;
  description?: string;
  version?: string;
  tags?: string[];
  // Image generation parameters
  width?: number;
  height?: number;
  steps?: number;
  sampler?: string;
  cfgScale?: number;
  // Timestamps
  createdAt?: number;
  updatedAt?: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'function';
  content: string;
  name?: string;
  sender?: string; // For UI display
  function_call?: {
    name: string;
    arguments: string;
  };
  // Metadata
  timestamp: number;
  model?: string;
  // UI state
  isStreaming?: boolean;
  isError?: boolean;
  metadata?: Record<string, any>;
}

export interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  serviceId: string;
  modelId?: string;
  // Metadata
  createdAt: number;
  updatedAt: number;
  timestamp: number; // For sorting/convenience
  // UI state
  isSelected?: boolean;
  isPinned?: boolean;
}

export interface PromptTemplate {
  id: string;
  name: string;
  content: string;
  description?: string;
  tags?: string[];
  // Model compatibility
  serviceTypes?: ServiceType[];
  modelIds?: string[];
  // Metadata
  createdAt: number;
  updatedAt: number;
  // UI state
  isFavorite?: boolean;
}

export interface ServiceStatus {
  isOnline: boolean;
  status: 'online' | 'offline' | 'checking' | 'error';
  message?: string;
  details?: {
    modelCount?: number;
    version?: string;
    [key: string]: any;
  };
  lastChecked: number;
}

export interface ServiceConnectionOptions {
  timeout?: number;
  retries?: number;
  retryDelay?: number;
  headers?: Record<string, string>;
  // Authentication
  auth?: {
    type: 'none' | 'api_key' | 'bearer' | 'basic';
    value?: string;
    username?: string;
    password?: string;
  };
  // Advanced
  validateSSL?: boolean;
  proxy?: string;
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  language: string;
  fontSize: number;
  lineHeight: number;
  // Chat settings
  autoScroll: boolean;
  compactView: boolean;
  markdown: boolean;
  codeHighlighting: boolean;
  // Notifications
  enableNotifications: boolean;
  soundEnabled: boolean;
  // Privacy
  telemetry: boolean;
  errorReporting: boolean;
  // Storage
  autoBackup: boolean;
  backupInterval: number;
  // Last updated timestamp
  updatedAt: number;
}

// =================================================================
// Image Generation Types
// =================================================================

export interface ImageGenSampler {
  name: string;
  id: string;
  description?: string;
}

export interface ImageGenOptions {
  width?: number;
  height?: number;
  steps?: number;
  cfgScale?: number;
  sampler?: string;
  seed?: number;
  negativePrompt?: string;
  [key: string]: any; // For additional options
}

export interface ComfyUIWorkflowInput {
  nodeId: string;
  nodeTitle: string;
  inputId: string;
  inputName: string;
  inputType: string;
}

export interface ComfyUIWorkflow {
  nodes: Array<{
    id: string;
    type: string;
    title: string;
    inputs: Array<{ name: string }>;
    widgets_values?: any[];
    [key: string]: any;
  }>;
  [key: string]: any;
}

// =================================================================
// Connector Interfaces
// =================================================================

export interface IConnector<T = any> {
  readonly id: string;
  readonly service: ServiceConfig;
  connect(): Promise<boolean>;
  disconnect(): Promise<void>;
  isConnected(): boolean;
  checkStatus(): Promise<{
    isOnline: boolean;
    details?: T;
    error?: string;
  }>;
  getDisplayName(): string;
  getType(): string;
  getCategory(): string;
  getMetadata(): Record<string, any>;
  updateService(service: Partial<ServiceConfig>): Promise<void>;
  validateConfig(): Promise<{
    isValid: boolean;
    errors?: string[];
    warnings?: string[];
  }>;
}

// =================================================================
// LLM Generation Types
// =================================================================

export interface GenerationParams {
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  frequencyPenalty?: number;
  presencePenalty?: number;
  stop?: string[];
  stream?: boolean;
  [key: string]: any;
}

export interface StreamChunk {
  content?: string;
  isComplete: boolean;
  error?: string;
  metadata?: Record<string, any>;
}

export type StreamCallback = (chunk: StreamChunk) => void;

export interface ILLMConnector extends IConnector {
  getModels(): Promise<LLMModel[]>;
  chat(
    messages: ChatMessage[],
    model: string,
    options?: GenerationParams
  ): Promise<ChatMessage>;
  embed(texts: string[], model: string): Promise<number[][]>;
  tokenize(text: string, model: string): Promise<number[]>;
  detokenize(tokens: number[], model: string): Promise<string>;
  countTokens(
    input: string | ChatMessage | ChatMessage[],
    model: string
  ): Promise<number>;
  getContextSize(model: string): Promise<number>;
  isModelSupported(model: string): Promise<boolean>;
  getDefaultParams(model: string): Promise<Record<string, any>>;
  complete(
    prompt: string,
    model: string,
    options: GenerationParams
  ): Promise<string>;
  streamResponse(
    response: Response,
    onChunk?: (chunk: StreamChunk) => void
  ): AsyncGenerator<StreamChunk>;
}

export interface ChatConnector extends IConnector {
  chat: (messages: ChatMessage[], model?: string, options?: Record<string, unknown>) => Promise<ChatMessage>;
  getModels: () => Promise<LLMModel[]>;
}

export interface ImageGenConnector extends IConnector {
  getModels: () => Promise<ImageModel[]>;
  generateImage: (prompt: string, options?: ImageGenOptions) => Promise<Partial<ImageArtifact>>;
  getSamplers?: () => Promise<ImageGenSampler[]>;
  getLoras?: () => Promise<ImageModel[]>;
  getEmbeddings?: () => Promise<ImageModel[]>;
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  timestamp: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

// Event Types
export type ServiceEvent = 
  | 'service:connected'
  | 'service:disconnected'
  | 'service:error'
  | 'service:status';

export type ModelEvent =
  | 'model:added'
  | 'model:updated'
  | 'model:removed';

export type MessageEvent =
  | 'message:received'
  | 'message:sent'
  | 'message:updated'
  | 'message:deleted';

export type AppEvent = ServiceEvent | ModelEvent | MessageEvent;

// Function Types
export type EventHandler<T = any> = (data: T) => void;
export type Unsubscribe = () => void;

/**
 * Type definition for request handlers
 * @template P The type of the payload
 * @template R The return type of the handler
 */
export type RequestHandler<P = any, R = any> = (
  payload: P,
  sender?: chrome.runtime.MessageSender
) => Promise<R>;

/**
 * Standard response format for API handlers
 */
export interface HandlerResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  code?: string;
}

/**
 * Standard error response format
 */
export interface ErrorResponse {
  code: string;
  message: string;
  details?: any;
}

export interface Model {
  id: string;
  name: string;
  details?: Record<string, any>;
}

import React, { useState, useEffect, useCallback } from 'react';
import styles from '@/styles/components/popup/Popup.module.css';
import { Service } from '@/config/types';
import { sendMessage } from '@/utils/chrome';
import { connectToBackground } from '@/utils/keepAlive';

const App: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [activeService, setActiveService] = useState<Service | null>(null);
  const [isPanelEnabled, setIsPanelEnabled] = useState(false);

  useEffect(() => {
    connectToBackground('popup');
  }, []);

  const getCurrentTab = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  };
  
  const openOptionsPage = () => sendMessage('openOptionsPage');

  const updatePanelState = useCallback(async () => {
    const tab = await getCurrentTab();
    if (tab?.id) {
      try {
        const { enabled } = await chrome.sidePanel.getOptions({ tabId: tab.id });
        setIsPanelEnabled(!!enabled);
        if (enabled) {
          const service = await sendMessage<Service | null>('getActiveService', null);
          setActiveService(service);
        } else {
          setActiveService(null);
        }
      } catch (e) {
        console.warn("Could not access side panel API.", e);
        setIsPanelEnabled(false);
        setActiveService(null);
      }
    }
  }, []);

  const loadData = useCallback(async () => {
    const allServices: Service[] = (await sendMessage('getServices')) || [];
    setServices(allServices);
    // Don't update panel state on initial load to keep "Show Panel" as default
    const service = await sendMessage<Service | null>('getActiveService', null);
    setActiveService(service);
    setIsPanelEnabled(false); // Ensure panel starts as hidden
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Listen for panel state changes
  useEffect(() => {
    const handlePanelStateChange = async (message: any) => {
      if (message.action === 'activeServiceChanged') {
        setActiveService(message.payload);
        await updatePanelState();
      } else if (message.action === 'panelStateChanged') {
        setIsPanelEnabled(message.payload.enabled);
      }
    };

    chrome.runtime.onMessage.addListener(handlePanelStateChange);
    return () => {
      chrome.runtime.onMessage.removeListener(handlePanelStateChange);
    };
  }, [updatePanelState]);

  const handleTogglePanel = async () => {
    const tab = await getCurrentTab();
    if (!tab?.id) return;
    const windowId = tab.windowId;

    try {
      if (isPanelEnabled) {
        // Hide panel
        await chrome.sidePanel.setOptions({ tabId: tab.id, enabled: false });
        setIsPanelEnabled(false);
        setActiveService(null);
        // Notify other components about panel state change
        chrome.runtime.sendMessage({ action: 'panelStateChanged', payload: { enabled: false } });
      } else {
        // Show panel
        await chrome.sidePanel.setOptions({ 
          tabId: tab.id, 
          path: 'src/sidepanel/index.html',
          enabled: true 
        });
        await chrome.sidePanel.open({ windowId });
        setIsPanelEnabled(true);
        // If we have an active service, ensure it's set
        if (activeService) {
          await sendMessage('setActiveService', { serviceId: activeService.id });
        }
        // Notify other components about panel state change
        chrome.runtime.sendMessage({ action: 'panelStateChanged', payload: { enabled: true } });
      }
      // Update panel state after changes
      await updatePanelState();
    } catch (error) {
      console.error('Failed to toggle panel:', error);
      // Revert state on error
      await updatePanelState();
    }
  };

  const handleOpenInPanel = async (service: Service) => {
    const tab = await getCurrentTab();
    if (!tab?.id) return;
    const windowId = tab.windowId;

    try {
      await sendMessage('setActiveService', { serviceId: service.id });
      await chrome.sidePanel.setOptions({ 
        tabId: tab.id, 
        path: 'src/sidepanel/index.html',
        enabled: true 
      });
      await chrome.sidePanel.open({ windowId });
      setIsPanelEnabled(true);
      setActiveService(service);
      await updatePanelState();
    } catch (error) {
      console.error('Failed to open in panel:', error);
      await updatePanelState();
    }
  };

  const handleOpenInTab = async (service: Service) => {
    try {
      const url = chrome.runtime.getURL(`src/tab/index.html?serviceId=${service.id}`);
      const tabs = await chrome.tabs.query({ url });
      if (tabs.length > 0) {
        await chrome.tabs.update(tabs[0].id!, { active: true });
      } else {
        await sendMessage('openServiceInTab', { serviceId: service.id });
      }
      
      // Always hide panel when switching to tab
      const tab = await getCurrentTab();
      if (tab?.id) {
        await chrome.sidePanel.setOptions({ tabId: tab.id, enabled: false });
        setIsPanelEnabled(false);
        setActiveService(null);
        await updatePanelState();
      }
    } catch (error) {
      console.error('Failed to open in tab:', error);
      await updatePanelState();
    }
  };

  return (
    <div className={styles.app}>
      <header className={styles.header}>
        <h1 className={styles.title}>ChatDemon</h1>
        <div className={styles.actions}>
          <button
            onClick={handleTogglePanel}
            className={styles.actionButton}
            disabled={services.length === 0}
            title={isPanelEnabled ? 'Hide Side Panel' : 'Show Side Panel'}
          >
            {isPanelEnabled ? 'Hide Panel' : 'Show Panel'}
          </button>
          <button onClick={() => { openOptionsPage(); }} className={styles.actionButton} title="Manage Services">
            Manage
          </button>
        </div>
      </header>
      <main className={styles.main}>
        {services.length > 0 ? (
          services.map((service) => (
            <div key={service.id} className={styles.serviceCard}>
              <span className={styles.serviceName}>{service.name}</span>
              <div className={styles.serviceActions}>
                <button onClick={() => handleOpenInTab(service)}>Tab</button>
                <button onClick={() => handleOpenInPanel(service)}>
                  {isPanelEnabled && activeService?.id === service.id ? 'Active' : 'Panel'}
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className={styles.noServices}>
            <p>No services configured.</p>
            <button onClick={() => { openOptionsPage(); }}>Add a Service</button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App; 
/* global console */
import { storageManager } from '../storage/storageManager';
import { DEFAULT_SERVICES } from '../config/constants';
import { handlers, Action } from './handlers';
import { setupKeepAliveListener } from '@/utils/keepAlive';
import { panelHandlers } from './handlers/panelHandlers';
import { RequestHandler } from './types';
import { serviceHandlers } from './handlers/serviceHandlers';
import { SETTINGS_KEY, SERVERS_KEY } from '../utils/settingsIO';
import { DEFAULT_SERVERS } from '../config/defaults';

// Keep the service worker alive
setupKeepAliveListener();

// Initialize default services on installation
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    console.log('ChatDemon first install, setting up default services...');
    const existingServices = await storageManager.get(SERVERS_KEY, []);

    if (existingServices.length === 0) {
      const servicesWithIds = DEFAULT_SERVICES.map((service, index) => ({
        ...service,
        id: `default_${index}_${Date.now()}`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        isActive: service.url.includes('localhost'),
      }));

      await storageManager.set(SERVERS_KEY, servicesWithIds);
      console.log('Default services created.');
    }
  }
});

// Function to check and initialize services if none exist
const ensureServicesExist = async () => {
  const existingServices = await storageManager.get(SERVERS_KEY, []);

  // If the stored services are empty or incomplete, reset to the default list.
  if (existingServices.length < DEFAULT_SERVICES.length) {
    console.log('Services are missing or empty. Resetting to default services...');
    const servicesWithIds = DEFAULT_SERVICES.map((service, index) => ({
      ...service,
      id: `default_${index}_${Date.now()}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isActive: service.url.includes('localhost'),
    }));

    await storageManager.set(SERVERS_KEY, servicesWithIds);
    console.log('Default services have been reset.');
  }
};

// Ensure services exist when the background script starts
ensureServicesExist();

// Run the check on browser startup
chrome.runtime.onStartup.addListener(ensureServicesExist);

// Initialize storage with default values if not present
async function initializeStorage() {
  const [settings, servers] = await Promise.all([
    storageManager.get(SETTINGS_KEY, {}),
    storageManager.get(SERVERS_KEY, [])
  ]);

  if (!servers || servers.length === 0) {
    await storageManager.set(SERVERS_KEY, DEFAULT_SERVICES);
  }
}

// Initialize storage when the background script starts
initializeStorage();

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message: { action: string; payload?: any }, sender, sendResponse) => {
  const { action, payload } = message;
  
  // Handle panel state changes
  if (action === 'panelStateChanged') {
    const handler = panelHandlers[action] as RequestHandler;
    if (handler) {
      handler(payload, sender, sendResponse);
      return true;
    }
  }
  
  // Handle service-related actions
  const handler = serviceHandlers[action] as RequestHandler;
  if (handler) {
    handler(payload, sender, sendResponse);
    return true;
  }
  
  // If no handler is found, send an error response
  sendResponse({ success: false, error: `No handler found for action: ${action}` });
  return false;
});

console.log('Background script initialized.');
import { ServiceType } from '../config/constants';

export type ServiceStatus = 'active' | 'inactive' | 'error' | 'online' | 'offline' | 'unknown';

export interface Service {
  id: string;
  name: string;
  type: ServiceType;
  url: string;
  status: ServiceStatus;
  createdAt: number;
  updatedAt: number;
  isActive?: boolean;
  apiKey?: string;
  endpoints?: {
    chat?: string;
    completion?: string;
    embedding?: string;
  };
  options?: Record<string, any>;
}

export interface ServiceFormData {
  name: string;
  type: ServiceType;
  url: string;
  endpoints?: {
    chat?: string;
    completion?: string;
    embedding?: string;
  } | string[];
  status?: ServiceStatus;
  apiKey?: string;
  options?: Record<string, any>;
} 
import {
  Service,
  ImageGenConnector,
  ImageModel,
  ImageGenSampler,
  ImageGenOptions,
  ImageArtifact,
} from '@/config/types';

export class A1111Connector implements ImageGenConnector {
  protected _service: Service;
  protected _isConnected: boolean = false;

  constructor(service: Service) {
    this._service = { ...service };
  }

  get id() {
    return this._service.id;
  }

  get service() {
    return this._service;
  }

  private getApiUrl(endpoint: string): string {
    const baseUrl = this._service.url?.replace(/\/$/, '');
    return `${baseUrl}${endpoint}`;
  }

  private async fetchWithAuth(endpoint: string, options: RequestInit = {}): Promise<Response> {
    const url = this.getApiUrl(endpoint);
    const headers = {
      'Content-Type': 'application/json',
      ...(this._service.apiKey ? { 'Authorization': `Bearer ${this._service.apiKey}` } : {}),
      ...options.headers,
    };

    const response = await fetch(url, {
      ...options,
      headers,
      mode: 'cors',
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error(`A1111 API error: ${response.statusText}`);
    }

    return response;
  }

  async connect(): Promise<boolean> {
    // Implement connection logic if needed
    this._isConnected = true;
    return true;
  }

  async disconnect(): Promise<void> {
    // Implement disconnect logic if needed
    this._isConnected = false;
  }

  isConnected(): boolean {
    return this._isConnected;
  }

  async checkStatus(): Promise<{ isOnline: boolean; details: any }> {
    try {
      const response = await this.fetchWithAuth('/sdapi/v1/progress');
      const models = await this.getModels();
      return { isOnline: true, details: { modelCount: models.length } };
    } catch (error) {
      return { isOnline: false, details: { error: (error as Error).message } };
    }
  }

  getDisplayName(): string {
    return this._service.name;
  }

  getType(): string {
    return this._service.type;
  }

  getCategory(): string {
    return 'Stable Diffusion';
  }

  getMetadata(): Record<string, any> {
    return {};
  }

  async updateService(service: Partial<Service>): Promise<void> {
    this._service = {
      ...this._service,
      ...service,
      id: this._service.id,
      type: service.type || this._service.type,
    };
    // Reconnect if connection details changed
    if (service.url || service.apiKey) {
      if (this._isConnected) {
        await this.disconnect();
        await this.connect();
      }
    }
  }

  async validateConfig(): Promise<{ isValid: boolean; errors?: string[]; warnings?: string[] }> {
    if (!this._service.url) {
      return { isValid: false, errors: ['Service URL is missing'] };
    }
    return { isValid: true };
  }

  async getModels(): Promise<ImageModel[]> {
    const res = await this.fetchWithAuth('/sdapi/v1/sd-models');
    const models = await res.json();
    return models.map((model: any) => ({ 
      id: model.title,
      name: model.model_name,
      filename: model.filename,
      hash: model.hash,
    }));
  }

  async getSamplers(): Promise<ImageGenSampler[]> {
    const res = await this.fetchWithAuth('/sdapi/v1/samplers');
    return await res.json();
  }

  async getLoras(): Promise<ImageModel[]> {
    const res = await this.fetchWithAuth('/sdapi/v1/loras');
    const loras = await res.json();
    return loras.map((lora: any) => ({ id: lora.name, name: lora.name, filename: lora.path }));
  }

  async getEmbeddings(): Promise<ImageModel[]> {
    const res = await this.fetchWithAuth('/sdapi/v1/embeddings');
    const embeddings = await res.json();
    return Object.keys(embeddings.loaded).map(name => ({ id: name, name, filename: '' }));
  }

  async generateImage(prompt: string, options?: ImageGenOptions): Promise<Partial<ImageArtifact>> {
    if (!this._service?.url) {
      throw new Error('Service URL not configured');
    }
    const response = await fetch(`${this._service.url}/sdapi/v1/txt2img`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        negative_prompt: options?.negativePrompt || '',
        steps: options?.steps || 20,
        width: options?.width || 512,
        height: options?.height || 512,
        cfg_scale: options?.cfgScale || 7,
        model: options?.model || '',
      }),
    });
    if (!response.ok) {
      throw new Error(`Failed to generate image: ${response.statusText}`);
    }
    const data = await response.json();
    const imageData = data.images[0];
    return {
      id: Date.now().toString(),
      imageUrl: `data:image/png;base64,${imageData}`,
      prompt,
      negativePrompt: options?.negativePrompt,
      model: options?.model,
      timestamp: Date.now(),
      width: options?.width,
      height: options?.height,
      steps: options?.steps,
      cfgScale: options?.cfgScale,
    };
  }
}
import {
  Service,
  ImageGenConnector,
  ImageModel,
  ImageGenOptions,
  ComfyUIWorkflow,
  ComfyUIWorkflowInput,
  ImageArtifact,
  ImageGenSampler,
} from '@/config/types';
import { v4 as uuidv4 } from 'uuid';

export class ComfyUIConnector implements ImageGenConnector {
  protected _service: Service;
  protected _isConnected: boolean = false;
  private clientId: string;

  constructor(service: Service) {
    this._service = { ...service };
    this.clientId = uuidv4();
  }

  get id() {
    return this._service.id;
  }

  get service() {
    return this._service;
  }

  private getApiUrl(endpoint: string): string {
    const baseUrl = this._service.url?.replace(/\/$/, '');
    return `${baseUrl}${endpoint}`;
  }

  private async fetchWithAuth(endpoint: string, options: RequestInit = {}): Promise<Response> {
    const url = this.getApiUrl(endpoint);
    const headers = {
      'Content-Type': 'application/json',
      ...(this._service.apiKey ? { 'Authorization': `Bearer ${this._service.apiKey}` } : {}),
      ...options.headers,
    };

    const response = await fetch(url, {
      ...options,
      headers,
      mode: 'cors',
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error(`ComfyUI API error: ${response.statusText}`);
    }

    return response;
  }

  async connect(): Promise<boolean> {
    this._isConnected = true;
    const { isOnline } = await this.checkStatus();
    return isOnline;
  }

  async disconnect(): Promise<void> {
    this._isConnected = false;
  }

  isConnected(): boolean {
    return this._isConnected;
  }

  async checkStatus(): Promise<{ isOnline: boolean; details: any }> {
    try {
      const response = await this.fetchWithAuth('/history');
      const models = await this.getModels();
      return { isOnline: true, details: { modelCount: models.length } };
    } catch (error) {
      return { isOnline: false, details: { error: (error as Error).message } };
    }
  }

  getDisplayName(): string {
    return this._service.name;
  }

  getType(): string {
    return this._service.type;
  }

  getMetadata(): Record<string, any> {
    return {};
  }

  async validateConfig(): Promise<{ isValid: boolean; errors?: string[]; warnings?: string[] }> {
    if (!this._service.url) {
      return { isValid: false, errors: ['Service URL is missing'] };
    }
    return { isValid: true };
  }

  parseWorkflow(workflowJson: string): ComfyUIWorkflowInput[] {
    const inputs: ComfyUIWorkflowInput[] = [];
    const workflow = JSON.parse(workflowJson);
    
    for (const node of workflow.nodes) {
      if (node.type === 'CLIPTextEncode') {
        inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'text', inputName: 'Prompt', inputType: 'text' });
      }
      if (node.type === 'KSampler') {
        inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'seed', inputName: 'Seed', inputType: 'number' });
        inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'steps', inputName: 'Steps', inputType: 'number' });
        inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'cfg', inputName: 'CFG Scale', inputType: 'number' });
      }
    }
    return inputs;
  }

  async executeWorkflow(workflowJson: string, inputs: Record<string, Record<string, any>>): Promise<string> {
    const workflow = JSON.parse(workflowJson);
    
    // Apply user inputs to the workflow
    for (const [nodeId, nodeInputs] of Object.entries(inputs)) {
      const node = workflow.nodes.find((n: any) => n.id === nodeId);
      if (node) {
        for (const [inputId, value] of Object.entries(nodeInputs)) {
          if (node.inputs && node.inputs[inputId]) {
            node.inputs[inputId] = value;
          }
        }
      }
    }

    // Queue the workflow
    const response = await this.fetchWithAuth('/prompt', {
      method: 'POST',
      body: JSON.stringify({ prompt: workflow }),
    });

    const { prompt_id } = await response.json();

    // Poll for completion
    while (true) {
      const statusResponse = await this.fetchWithAuth(`/history/${prompt_id}`);
      const status = await statusResponse.json();
      
      if (status.outputs && Object.keys(status.outputs).length > 0) {
        const output = Object.values(status.outputs)[0] as any;
        if (output.images && output.images.length > 0) {
          const image = output.images[0];
          return `data:image/png;base64,${image.data}`;
        }
      }

      if (status.status === 'error') {
        throw new Error('Workflow execution failed');
      }

      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  async generateImage(prompt: string, options?: ImageGenOptions): Promise<Partial<ImageArtifact>> {
    if (!this._service?.url) {
      throw new Error('Service URL not configured');
    }

    // TODO: Implement ComfyUI workflow execution
    // For now, return a placeholder
    return {
      id: Date.now().toString(),
      imageUrl: '',
      prompt,
      timestamp: Date.now(),
    };
  }

  async getModels(): Promise<ImageModel[]> {
    const res = await this.fetchWithAuth('/object_info');
    const data = await res.json();
    return Object.keys(data).map(name => ({ id: name, name, filename: '' }));
  }

  async getSamplers(): Promise<ImageGenSampler[]> {
    return Promise.resolve([]);
  }

  async getLoras(): Promise<ImageModel[]> {
    return Promise.resolve([]);
  }

  async getEmbeddings(): Promise<ImageModel[]> {
    return Promise.resolve([]);
  }

  getCategory(): string {
    return 'ComfyUI';
  }

  async updateService(service: Partial<Service>): Promise<void> {
    this._service = {
      ...this._service,
      ...service,
      id: this._service.id,
      type: service.type || this._service.type,
    };
    if (service.url || service.apiKey) {
      if (this._isConnected) {
        await this.disconnect();
        await this.connect();
      }
    }
  }
} 
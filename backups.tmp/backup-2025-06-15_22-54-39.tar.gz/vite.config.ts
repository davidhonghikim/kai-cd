import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';
import { viteStaticCopy } from 'vite-plugin-static-copy';

export default defineConfig({
  plugins: [
    react(),
    viteStaticCopy({
      targets: [
        {
          src: 'src/popup/index.html',
          dest: '.',
          rename: 'popup.html'
        },
        {
          src: 'src/sidepanel/index.html',
          dest: '.',
          rename: 'sidepanel.html'
        },
        {
          src: 'src/options/index.html',
          dest: '.',
          rename: 'options.html'
        },
        {
          src: 'src/tab/index.html',
          dest: '.',
          rename: 'tab.html'
        }
      ]
    })
  ],
  resolve: {
    alias: {
      '@': resolve(__dirname, './src')
    }
  },
  build: {
    outDir: 'dist',
    rollupOptions: {
      input: {
        background: resolve(__dirname, 'src/background/main.ts'),
        popup: resolve(__dirname, 'src/popup/main.tsx'),
        sidepanel: resolve(__dirname, 'src/sidepanel/main.tsx'),
        options: resolve(__dirname, 'src/options/main.tsx'),
        tab: resolve(__dirname, 'src/tab/main.tsx')
      },
      output: {
        entryFileNames: 'assets/[name].js',
        chunkFileNames: 'assets/chunks/[name].js',
        assetFileNames: 'assets/[name].[ext]',
      },
    },
    emptyOutDir: true,
  },
}); 
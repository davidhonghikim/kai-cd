import { connectorManager } from "../connectors";
import {
  getServices,
  getImageArtifacts,
  addImageArtifact,
  deleteImageArtifact as deleteArtifactFromStorage,
} from "../utils/storage";
import type {
  ImageArtifact,
  ImageGenConnector,
  ImageModel,
} from "../../config/types";

interface GenerateImageRequest {
  serviceId: string;
  prompt: string;
  negativePrompt?: string;
  model?: string;
  options?: Record<string, unknown>;
}

/**
 * Generate an image using a service
 */
export async function generateImage(payload: GenerateImageRequest): Promise<any> {
  const { serviceId, prompt, negativePrompt, model, options = {} } = payload;
  
  const services = await getServices();
  const service = services.find(s => s.id === serviceId);
  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  const connector = await connectorManager.getConnector(service) as ImageGenConnector;
  if (!connector || typeof connector.generateImage !== 'function') {
    throw new Error(`Connector for service ${serviceId} does not support image generation`);
  }
  
  const artifact = await connector.generateImage(prompt, { ...options, negativePrompt, model });
  
  const newArtifact: ImageArtifact = {
    id: `art_${Date.now()}`,
    ...artifact,
    serviceId,
    timestamp: Date.now(),
    // Add dummy data for required fields that might be missing
    imageUrl: artifact.imageUrl || '',
    width: artifact.width || 512,
    height: artifact.height || 512,
    steps: artifact.steps || 20,
    sampler: artifact.sampler || 'Euler a',
    seed: artifact.seed || -1,
    prompt: prompt,
  }

  await addImageArtifact(newArtifact);

  return artifact;
};

/**
 * Stop an ongoing image generation
 */
export async function stopGeneration(payload: { serviceId: string }): Promise<any> {
  const { serviceId } = payload;
  const services = await getServices();
  const service = services.find(s => s.id === serviceId);
  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  const connector = await connectorManager.getConnector(service) as ImageGenConnector;
  if (connector && typeof connector.stopGeneration === 'function') {
    return connector.stopGeneration();
  }
  
  return { success: true, message: "Stop generation is not supported for this service." };
};

export async function deleteImageArtifact(payload: { id: string }): Promise<void> {
  if (!payload.id) {
    throw new Error("Artifact ID is required");
  }

  try {
    await deleteArtifactFromStorage(payload.id);
  } catch (error) {
    console.error("Error deleting image artifact:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to delete image artifact: ${errorMessage}`);
  }
};

/**
 * Get available LoRAs for a service
 */
export async function getLoras(payload: { serviceId: string }): Promise<ImageModel[]> {
  const { serviceId } = payload;
  if (!serviceId) {
    throw new Error("Invalid request: serviceId is required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = await connectorManager.getConnector(service) as ImageGenConnector;
    if (connector && typeof connector.getLoras === 'function') {
      return connector.getLoras();
    }

    return [];
  } catch (error) {
    console.error(`Error getting LoRAs for service ${serviceId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get LoRAs: ${errorMessage}`);
  }
};

/**
 * Get available embeddings for a service
 */
export async function getEmbeddings(payload: { serviceId: string }): Promise<ImageModel[]> {
  const { serviceId } = payload;
  if (!serviceId) {
    throw new Error("Invalid request: serviceId is required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = await connectorManager.getConnector(service) as ImageGenConnector;
    if (connector && typeof connector.getEmbeddings === 'function') {
      return connector.getEmbeddings();
    }

    return [];
  } catch (error) {
    console.error(`Error getting embeddings for service ${serviceId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get embeddings: ${errorMessage}`);
  }
};

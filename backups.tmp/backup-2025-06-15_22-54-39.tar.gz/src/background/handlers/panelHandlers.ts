import { storageManager } from "@/storage/storageManager";
import type { Service } from '@/config/types';

/**
 * Sets the active service in storage. This determines which service the panel will display.
 * After setting, it broadcasts a message to notify other parts of the extension.
 */
export async function setActiveService(payload: { serviceId: string }): Promise<void> {
  const services = await storageManager.get<Service[]>('services', []);
  const serviceToActivate = services.find(s => s.id === payload.serviceId);
  await storageManager.set('activeService', serviceToActivate || null);
  chrome.runtime.sendMessage({ action: 'activeServiceChanged', payload: serviceToActivate });
};

/**
 * Gets the currently active service from storage.
 */
export async function getActiveService(): Promise<Service | null> {
  return await storageManager.get<Service | null>('activeService', null);
};

/**
 * Opens the extension's options page.
 */
export async function openOptionsPage(): Promise<void> {
  chrome.runtime.openOptionsPage();
};

/**
 * Opens a service's URL in a new tab, loading the extension's tab UI.
 */
export async function openServiceInTab(payload: { serviceId: string }): Promise<void> {
  const services = await storageManager.get<Service[]>('services', []);
  const service = services.find((s) => s.id === payload.serviceId);
  if (service) {
    const tabUrl = chrome.runtime.getURL(`src/tab/index.html?serviceId=${payload.serviceId}`);
    chrome.tabs.create({ url: tabUrl });
  } else {
    throw new Error(`Service with id ${payload.serviceId} or its URL not found.`);
  }
};

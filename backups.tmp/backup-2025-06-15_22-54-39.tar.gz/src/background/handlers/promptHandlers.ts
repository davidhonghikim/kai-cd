import { storageManager } from '@/storage/storageManager';
import type { Prompt } from '@/config/types';

/**
 * Get all prompts
 */
export async function getPrompts(): Promise<Prompt[]> {
  return await storageManager.get<Prompt[]>('prompts', []);
};

/**
 * Save a new prompt
 */
export async function savePrompt(promptData: Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>): Promise<Prompt> {
  const prompts = await getPrompts();
  const newPrompt: Prompt = {
    ...promptData,
    id: `prompt-${Date.now()}`,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  const updatedPrompts = [...prompts, newPrompt];
  await storageManager.set('prompts', updatedPrompts);
  return newPrompt;
};

/**
 * Delete a prompt
 */
export async function deletePrompt(payload: { promptId: string }): Promise<Prompt[]> {
  const prompts = await getPrompts();
  const updatedPrompts = prompts.filter((p) => p.id !== payload.promptId);
  await storageManager.set('prompts', updatedPrompts);
  return updatedPrompts;
};

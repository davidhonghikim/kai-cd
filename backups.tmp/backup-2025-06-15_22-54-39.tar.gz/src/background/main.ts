import { storageManager } from '@/storage/storageManager';
import { connectorManager } from './connectors';
import * as serviceHandlers from './handlers/serviceHandlers';
import * as panelHandlers from './handlers/panelHandlers';
import * as chatHandlers from './handlers/chatHandlers';
import * as imageHandlers from './handlers/imageHandlers';
import * as promptHandlers from './handlers/promptHandlers';
import { setupKeepAliveListener } from '@/utils/keepAlive';
import { Service } from '@/config/types';

// Initialize the extension
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    // Perform initial setup
    console.log('ChatDemon extension installed!');
  }
});

// Always initialize services on startup
initializeServices();

async function initializeServices() {
  const services = await storageManager.get<Service[]>('services');
  if (!services || services.length === 0) {
    // If no services are stored, you might want to add some defaults here
    // For now, we'll just log a message
    console.log('No services found. Please configure services in the options page.');
  }
}

// Keep the service worker alive
setupKeepAliveListener();

// Define all message handlers
const handlers = {
  ...serviceHandlers,
  ...panelHandlers,
  ...chatHandlers,
  ...imageHandlers,
  ...promptHandlers,
};

// Listen for messages from other parts of the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const handler = handlers[request.action as keyof typeof handlers];
  if (handler) {
    (handler as Function)(request.payload)
      .then(sendResponse)
      .catch((error: Error) => {
        console.error(`Error handling action ${request.action}:`, error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Indicates that the response is sent asynchronously
  } else {
    console.warn(`No handler found for action: ${request.action}`);
    sendResponse({ success: false, error: `No handler for action: ${request.action}` });
  }
  return false;
});

// Clean up connectors when the extension is about to be unloaded
chrome.runtime.onSuspend.addListener(() => {
  connectorManager.clearConnectors();
});

console.log('Background script initialized.');
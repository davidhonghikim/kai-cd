import React from 'react';
import styles from './App.module.css';

const App: React.FC = () => {
  return (
    <div className={styles.app}>
      <header className={styles.header}>
        <h1>ChatDemon</h1>
        <select>
          <option>Select a Service</option>
        </select>
      </header>
      <main className={styles.mainContent}>
        <div className={styles.chatWindow}>
          <p>Chat history will appear here...</p>
        </div>
        <div className={styles.tabs}>
          <button>OpenWebUI</button>
          <button>ComfyUI</button>
        </div>
      </main>
      <footer className={styles.footer}>
        <input type="text" placeholder="Enter a prompt..." />
        <button>Send</button>
      </footer>
    </div>
  );
};

export default App; 
import React from 'react';
import styles from './Options.module.css';

const Options: React.FC = () => {
  return (
    <div className={styles.options}>
      <header className={styles.header}>
        <h1>ChatDemon Settings</h1>
      </header>
      <main className={styles.mainContent}>
        <h2>Service Connections</h2>
        <div className={styles.serviceList}>
          {/* Service items will be listed here */}
          <div className={styles.serviceItem}>
            <span>My OpenWebUI (OpenWebUI)</span>
            <div>
              <button>Edit</button>
              <button className={styles.deleteButton}>Remove</button>
            </div>
          </div>
        </div>
        <div className={styles.formContainer}>
          <h3>Add/Edit Service</h3>
          <form className={styles.form}>
            <input type="text" placeholder="Service Name" />
            <select>
              <option>OpenWebUI</option>
              <option>A1111</option>
              <option>ComfyUI</option>
            </select>
            <input type="text" placeholder="URL" />
            <input type="text" placeholder="API Key (optional)" />
            <button type="submit">Save Service</button>
          </form>
        </div>
      </main>
    </div>
  );
};

export default Options; 
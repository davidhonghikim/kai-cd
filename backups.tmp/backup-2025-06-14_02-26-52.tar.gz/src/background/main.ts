import { storageManager } from '../storage/storageManager';

console.log('Background script loaded.');

// Listener for messages from the UI
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getServices') {
    storageManager.get('services', []).then(sendResponse);
    return true; // Indicates that the response is asynchronous
  }

  if (request.action === 'addService') {
    storageManager.get('services', []).then((services) => {
      const newServices = [...services, request.config];
      storageManager.set('services', newServices).then(() => {
        sendResponse({ success: true, services: newServices });
      });
    });
    return true;
  }

  if (request.action === 'updateService') {
    storageManager.get('services', []).then((services) => {
      const newServices = services.map((s: any) =>
        s.id === request.id ? request.config : s
      );
      storageManager.set('services', newServices).then(() => {
        sendResponse({ success: true, services: newServices });
      });
    });
    return true;
  }

  if (request.action === 'removeService') {
    storageManager.get('services', []).then((services) => {
      const newServices = services.filter((s: any) => s.id !== request.id);
      storageManager.set('services', newServices).then(() => {
        sendResponse({ success: true, services: newServices });
      });
    });
    return true;
  }
}); 
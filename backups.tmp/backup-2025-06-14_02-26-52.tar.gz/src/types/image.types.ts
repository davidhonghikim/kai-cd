export interface ImageGenModel {
  id: string;
  name: string;
}

export interface ImageGenSettings {
  url: string;
  apiKey?: string;
  model?: string;
  sampler?: string;
  steps?: number;
  cfgScale?: number;
  width?: number;
  height?: number;
}

export interface GenerationProgress {
  step: number;
  totalSteps: number;
  previewImage?: string;
}

export interface ImageGenConnector {
  connect(): Promise<boolean>;
  disconnect(): Promise<void>;
  isConnected(): boolean;
  getModels(): Promise<ImageGenModel[]>;
  generateImage(prompt: string, model: ImageGenModel, options?: any): Promise<string>;
  streamGeneration(prompt: string, model: ImageGenModel, options?: any): AsyncGenerator<GenerationProgress>;
  cancelGeneration(): void;
  getSettings(): Promise<ImageGenSettings>;
  updateSettings(settings: ImageGenSettings): Promise<void>;
  getErrorMessage(): string | null;
} 
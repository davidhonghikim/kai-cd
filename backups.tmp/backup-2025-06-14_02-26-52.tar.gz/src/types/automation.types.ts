export interface Workflow {
  id: string;
  name: string;
  description: string;
}

export interface ExecutionResult {
  status: string;
  data: any;
}

export interface AutomationSettings {
  url: string;
  apiKey?: string;
}

export interface AutomationConnector {
  connect(): Promise<boolean>;
  disconnect(): Promise<void>;
  isConnected(): boolean;
  getWorkflows(): Promise<Workflow[]>;
  executeWorkflow(workflowId: string, data: any): Promise<ExecutionResult>;
  getSettings(): Promise<AutomationSettings>;
  updateSettings(settings: AutomationSettings): Promise<void>;
  getErrorMessage(): string | null;
} 
/**
 * A wrapper for the chrome.storage.local API.
 */
export const storageManager = {
  /**
   * Retrieves an item from storage.
   * @param key The key of the item to retrieve.
   * @param defaultValue The default value to return if the key is not found.
   * @returns The retrieved item or the default value.
   */
  get: async (key: string, defaultValue: any = null): Promise<any> => {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => {
        resolve(result[key] === undefined ? defaultValue : result[key]);
      });
    });
  },

  /**
   * Sets an item in storage.
   * @param key The key of the item to set.
   * @param value The value to set.
   */
  set: async (key: string, value: any): Promise<void> => {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, () => {
        resolve();
      });
    });
  },

  /**
   * Removes an item from storage.
   * @param key The key of the item to remove.
   */
  remove: async (key: string): Promise<void> => {
    return new Promise((resolve) => {
      chrome.storage.local.remove(key, () => {
        resolve();
      });
    });
  },
}; 
import { LLMConnector, LLMModel, LLMSettings } from '../../types/llm.types';

export class OpenWebUIConnector implements LLMConnector {
  private settings: LLMSettings;
  private connected = false;
  private errorMessage: string | null = null;

  constructor(settings: LLMSettings) {
    this.settings = settings;
  }

  async connect(): Promise<boolean> {
    // For OpenWebUI, connection is managed via iframe, so this is a placeholder.
    // A health check endpoint could be added here in the future.
    this.connected = true;
    return Promise.resolve(true);
  }

  async disconnect(): Promise<void> {
    this.connected = false;
    return Promise.resolve();
  }

  isConnected(): boolean {
    return this.connected;
  }

  async getModels(): Promise<LLMModel[]> {
    // This would need an API endpoint from OpenWebUI.
    // Returning a default model for now.
    return Promise.resolve([{ id: 'default', name: 'Default Model' }]);
  }

  async sendMessage(prompt: string, model: LLMModel): Promise<string> {
    console.log(`Sending message to OpenWebUI (model: ${model.id}): ${prompt}`);
    // Actual implementation would involve postMessage to the iframe.
    return Promise.resolve('Response from OpenWebUI');
  }

  async *streamMessage(prompt: string, model: LLMModel): AsyncGenerator<string> {
    console.log(`Streaming message to OpenWebUI (model: ${model.id}): ${prompt}`);
    yield 'Streaming response chunk 1';
    yield 'Streaming response chunk 2';
  }

  cancelStream(): void {
    console.log('Cancelling stream...');
  }

  async getSettings(): Promise<LLMSettings> {
    return Promise.resolve(this.settings);
  }

  async updateSettings(settings: LLMSettings): Promise<void> {
    this.settings = settings;
    return Promise.resolve();
  }

  getErrorMessage(): string | null {
    return this.errorMessage;
  }
} 
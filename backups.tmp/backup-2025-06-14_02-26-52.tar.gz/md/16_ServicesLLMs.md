# 16_ServicesLLMs.md
# ChatDemon Service Integration Guide - LLMs
**Title:** Service Integration Guide - LLMs

**Overview:** This guide details the integration of various Large Language Model (LLM) services into the ChatDemon extension.

**Goal:** To provide a unified interface for interacting with LLMs from various providers.

**Supported Services:**

*   OpenWebUI (Remote UI): Leverages the existing OpenWebUI interface.
*   Ollama (API): Directly connects to the Ollama API.
*   OpenAI (API): Utilizes the OpenAI API.
*   Other LLM APIs (e.g., Anthropic Claude, Google Gemini, LocalAI): Add connectors as needed.

**Connector Implementation:**

```typescript
interface LLMConnector {
    connect(): Promise<boolean>; // Returns true on successful connection
    disconnect(): Promise<void>;
    isConnected(): boolean;
    getModels(): Promise<LLMModel[]>; // Array of available models
    sendMessage(prompt: string, model: LLMModel, options?: any): Promise<string>; // Returns LLM response
    streamMessage(prompt: string, model: LLMModel, options?: any): AsyncGenerator<string>; // Streams responses
    cancelStream(): void; // Cancels a streaming operation
    getSettings(): Promise<LLMSettings>;  // Returns service settings
    updateSettings(settings: LLMSettings): Promise<void>; // Updates service settings
    getErrorMessage(): string | null;  // Returns the latest error message, if any
}

interface LLMModel {
    id: string;  // Model identifier (e.g., "gpt-3.5-turbo")
    name: string; // User-friendly model name
}

interface LLMSettings {
    url: string; // Base URL (if applicable)
    apiKey?: string; // API key (if required)
    model?: string; // Default model selection
    temperature?: number; // Temperature setting
    maxTokens?: number;  // Maximum token limit
}

Implementation Details:
OpenWebUI Connector:
Connects to a running OpenWebUI instance.
Communicates with the OpenWebUI API (if available) or uses iframe communication to send prompts and retrieve responses.
Manages session state and authentication.
Ollama Connector:
Connects to the local Ollama API.
Provides access to locally running models.
Manages model selection and settings.
OpenAI Connector:
Uses the OpenAI API.
Requires an API key.
Supports model selection, temperature, and other OpenAI API options.
Default Configurations (Crucially Important):
OpenWebUI:
ID: openwebui
Name: OpenWebUI Server
URL: http://localhost:3000 (default)
API Key: (Not typically required, but can be added if needed)
Active: true
Endpoints (Example): Models: /api/models, Chat: /api/chat , Healthcheck: /api/health (Adapt to actual OpenWebUI API)
Ollama:
ID: ollama
Name: Local Ollama
URL: http://localhost:11434 (default)
API Key: None
Active: false
Endpoints (Example): Models: /api/tags, Generate: /api/generate , Healthcheck: /api/version (Adapt to Ollama API)
OpenAI:
ID: openai
Name: OpenAI
URL: https://api.openai.com/v1
API Key: Required
Active: false
Endpoints: Chat: /chat/completions (Adapt to OpenAI API)
Workflow for Sending Prompts (for Coding Agent):
The user enters a prompt in the ChatDemon side panel.
The UI sends the prompt, along with the selected LLM service ID and model ID, to the background script.
The background script retrieves the appropriate LLM connector.
The connector sends the prompt to the LLM service's API (or communicates with the OpenWebUI iframe).
The LLM service processes the prompt and returns a response.
The connector receives the response and returns it to the background script.
The background script updates the UI with the response.
Error Handling:
Implement robust error handling to catch connection errors, API errors, and other issues.
Display informative error messages to the user.
Implement retry logic for transient errors.
Security Considerations:
Store API keys securely using browser extension storage APIs and encryption.
Validate all input to prevent security vulnerabilities.
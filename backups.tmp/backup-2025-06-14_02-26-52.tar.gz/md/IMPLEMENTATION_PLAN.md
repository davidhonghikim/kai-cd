# ChatDemon Implementation Plan

This document outlines the step-by-step implementation plan for the ChatDemon project. Each phase is broken down into manageable tasks to ensure clarity and consistency, especially for a distributed team of developers or agents.

## Phase 1: Core Project Setup & Foundation

### Task 1.1: Initialize Project Structure
- **Description**: Create the directory structure as defined in `PROJECT_STRUCTURE.md`.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to set up the initial directory structure for the ChatDemon project.

  **Instructions**:
  1.  Load and review the `md/PROJECT_STRUCTURE.md` file to understand the required directory layout.
  2.  Create the following directories at the root of the project:
      - `src/background`
      - `src/content`
      - `src/popup`
      - `src/options`
      - `src/services/llm`
      - `src/services/image`
      - `src/services/automation`
      - `src/services/vector`
      - `src/utils`
      - `src/storage`
      - `src/types`
      - `src/constants`
      - `public/icons`
      - `public/assets`
      - `tests/unit`
      - `tests/integration`
      - `tests/e2e`
      - `docs/api`
      - `docs/guides`
      - `docs/development`
      - `config`
  3.  Confirm that all directories are created successfully.
  ```

### Task 1.2: Setup Build Tools & Dependencies
- **Description**: Configure Vite/Webpack, TypeScript, ESLint, and Prettier.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to configure the build and development tools for the ChatDemon project.

  **Instructions**:
  1.  Initialize a `package.json` file: `npm init -y`.
  2.  Install development dependencies:
      - `npm install --save-dev typescript vite @vitejs/plugin-react eslint prettier eslint-config-prettier eslint-plugin-prettier eslint-plugin-react @typescript-eslint/parser @typescript-eslint/eslint-plugin`
  3.  Install React dependencies: `npm install react react-dom`
  4.  Create `vite.config.ts` with basic configuration for a browser extension.
  5.  Create `tsconfig.json` with strict settings for React and DOM.
  6.  Create `.eslintrc.cjs` with rules for TypeScript, React, and Prettier.
  7.  Create `.prettierrc` with standard formatting rules.
  8.  Add scripts to `package.json`: `dev`, `build`, `lint`, `format`.
  ```

### Task 1.3: Create manifest.json
- **Description**: Create the manifest file for the browser extension.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to create the `manifest.json` file for the ChatDemon browser extension.

  **Instructions**:
  1.  Create a `manifest.json` file in the `public/` directory.
  2.  Define the manifest version, name, description, and version.
  3.  Specify permissions: `storage`, `activeTab`.
  4.  Define the background script entry point.
  5.  Define the browser action (popup) with a default icon and HTML file.
  6.  Set the icons for the extension.
  ```

## Phase 2: Core Extension UI

### Task 2.1: Implement Popup UI Shell
- **Description**: Create the main React component for the popup.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to create the basic UI shell for the ChatDemon popup.

  **Instructions**:
  1.  Create `src/popup/index.html` to host the React app.
  2.  Create `src/popup/main.tsx` as the entry point for the React app.
  3.  Create a main `App.tsx` component in `src/popup/`.
  4.  The `App` component should have a basic layout with placeholders for:
      - Header
      - Service selection dropdown
      - Chat window
      - Prompt input area
      - Tabbed interface for full UIs
  5.  Style the component using CSS modules (`App.module.css`).
  ```

### Task 2.2: Implement Options Page Shell
- **Description**: Create the UI for the extension's options page.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to create the UI for the ChatDemon options page.

  **Instructions**:
  1.  Create `src/options/index.html`.
  2.  Create `src/options/main.tsx`.
  3.  Create an `Options.tsx` component in `src/options/`.
  4.  The `Options` component should have a layout for:
      - A list of configured services.
      - Buttons to "Add", "Edit", and "Remove" services.
      - A form for adding/editing a service with fields for Name, URL, API Key, etc.
  5.  Add the options page to `manifest.json`.
  ```

## Phase 3: Storage and Service Management

### Task 3.1: Implement Storage Manager
- **Description**: Create a utility for managing data in `chrome.storage`.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to create a storage manager for ChatDemon.

  **Instructions**:
  1.  Create `src/storage/storageManager.ts`.
  2.  Implement functions to interact with `chrome.storage.local`.
      - `set(key, value): Promise<void>`
      - `get(key, defaultValue): Promise<any>`
      - `remove(key): Promise<void>`
  3.  Ensure all functions are asynchronous and handle potential errors.
  ```

### Task 3.2: Implement Service Management in Background Script
- **Description**: Add logic to the background script to manage service configurations.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to implement service management logic in the background script.

  **Instructions**:
  1.  Create `src/background/main.ts`.
  2.  Use the `storageManager` to store service configurations.
  3.  Implement message listeners for actions from the options page:
      - `addService(config)`
      - `updateService(id, config)`
      - `removeService(id)`
      - `getServices()`
  4.  The services should be stored as an array of objects in storage.
  ```

## Phase 4: Service Connector Interfaces and LLM Integration

### Task 4.1: Define Service Connector Types
- **Description**: Create TypeScript interfaces for all service connector types.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to define the TypeScript interfaces for service connectors.

  **Instructions**:
  1.  Go to the `src/types/` directory.
  2.  Based on `16_ServicesLLMs.md`, `17_ServicesImageGen.md`, etc., create the following interface files:
      - `llm.types.ts` (with `LLMConnector`, `LLMModel`, `LLMSettings`)
      - `image.types.ts` (with `ImageGenConnector`, `ImageGenModel`, etc.)
      - `automation.types.ts`
      - `vector.types.ts`
  3.  Ensure the interfaces match the specifications in the documentation.
  ```

### Task 4.2: Implement OpenWebUI Connector
- **Description**: Create the first LLM service connector for OpenWebUI.
- **Agent Prompt**:
  ```
  As a coding agent, your task is to implement the OpenWebUI connector.

  **Instructions**:
  1.  Create `src/services/llm/openWebUIConnector.ts`.
  2.  Implement the `LLMConnector` interface from `src/types/llm.types.ts`.
  3.  The connector will primarily be a wrapper around the iframe for now. Focus on the connection status and settings management.
  4.  The `sendMessage` function can be a placeholder or log a message, as direct API communication may be added later.
  5.  Use the default configuration from `16_ServicesLLMs.md`.
  ```
---

This plan will be expanded with more phases and tasks as the project progresses. 
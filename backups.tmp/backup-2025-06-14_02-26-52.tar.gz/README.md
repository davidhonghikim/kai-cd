# ChatDemon

ChatDemon is a browser extension that streamlines the management and integration of AI services, enabling efficient cross-model communication and artifact management within a unified environment.

## Project Documentation

This project is organized into a series of documents that outline the architecture, implementation plan, and development guidelines. All documentation is located in the `md/` directory.

- **[Project Overview](md/README.md)**: High-level vision, goals, and features of ChatDemon.
- **[Project Structure](md/PROJECT_STRUCTURE.md)**: The directory layout and component organization.
- **[Implementation Plan](md/IMPLEMENTATION_PLAN.md)**: A detailed, phased plan for building the extension.

## Development

To get started with development, please refer to the following guides:

- **[Development and Testing](md/03_DevelopmentTesting.md)**: Instructions on setting up the development environment, running tests, and more.
- **[Agent Protocol](md/05_AgentProtocol.md)**: Commands and protocols for automated development agents.

## Quick Start

1.  **Clone the repository:**
    ```bash
    git clone <repository_url>
    ```
2.  **Install dependencies:**
    ```bash
    npm install
    ```
3.  **Start the development server:**
    ```bash
    npm run dev
    ```
4.  **Load the extension:**
    - Open Chrome/Edge and navigate to `chrome://extensions`.
    - Enable "Developer mode".
    - Click "Load unpacked" and select the `dist` directory. 
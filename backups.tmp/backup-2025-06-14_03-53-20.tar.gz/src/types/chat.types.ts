export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
}

export interface Conversation {
  id: string;
  timestamp: number;
  serviceId: string;
  messages: ChatMessage[];
} 
export interface Prompt {
  id: string;
  name: string;
  text: string;
} 
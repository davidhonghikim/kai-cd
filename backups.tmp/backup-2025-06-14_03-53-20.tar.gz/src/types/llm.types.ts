export interface LLMModel {
  id: string;
  name: string;
}

export interface LLMSettings {
  url: string;
  apiKey?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface LLMConnector {
  connect(): Promise<boolean>;
  disconnect(): Promise<void>;
  isConnected(): boolean;
  getModels(): Promise<LLMModel[]>;
  sendMessage(prompt: string, model: LLMModel, options?: any): Promise<string>;
  streamMessage(prompt: string, model: LLMModel, options?: any): AsyncGenerator<string>;
  cancelStream(): void;
  getSettings(): Promise<LLMSettings>;
  updateSettings(settings: LLMSettings): Promise<void>;
  getErrorMessage(): string | null;
} 
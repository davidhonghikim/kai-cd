export interface SearchResult {
  id: string;
  score: number;
  payload?: any;
}

export interface VectorSearchSettings {
  url: string;
  apiKey?: string;
}

export interface VectorSearchConnector {
  connect(): Promise<boolean>;
  disconnect(): Promise<void>;
  isConnected(): boolean;
  createCollection(name: string, dimension: number): Promise<void>;
  search(collectionName: string, queryVector: number[], topK: number): Promise<SearchResult[]>;
  getSettings(): Promise<VectorSearchSettings>;
  updateSettings(settings: VectorSearchSettings): Promise<void>;
  getErrorMessage(): string | null;
} 
export type ServiceType =
  | 'open-webui'
  | 'a1111'
  | 'comfy-ui'
  | 'ollama';

export interface Service {
  id: string;
  name: string;
  type: ServiceType;
  url: string;
  apiKey?: string;
} 
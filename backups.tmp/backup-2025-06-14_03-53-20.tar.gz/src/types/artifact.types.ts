export interface ImageArtifact {
  id: string;
  timestamp: number;
  serviceId: string;
  prompt: string;
  imageUrl: string;
} 
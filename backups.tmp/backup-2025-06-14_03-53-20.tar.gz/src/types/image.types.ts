export interface ImageGenModel {
  id: string;
  name: string;
}

export interface ImageGenOptions {
  width?: number;
  height?: number;
  steps?: number;
  cfgScale?: number;
  seed?: number;
}

export interface ImageGenSettings {
  url: string;
  apiKey?: string;
  model?: string;
  sampler?: string;
  steps?: number;
  cfgScale?: number;
  width?: number;
  height?: number;
}

export interface GenerationProgress {
  step: number;
  totalSteps: number;
  previewImage?: string;
}

export interface ImageGenConnector {
  getModels(): Promise<ImageGenModel[]>;
  generateImage(prompt: string, model: ImageGenModel, options?: ImageGenOptions): Promise<string>; // Returns image URL or base64 string
} 
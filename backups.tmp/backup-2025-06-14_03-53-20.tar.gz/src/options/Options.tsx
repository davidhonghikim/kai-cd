import React, { useState, useEffect } from 'react';
import styles from './Options.module.css';
import { Service, ServiceType } from '../types/service.types';
import { sendMessage } from '../utils/chrome';

type ServiceStatus = 'unknown' | 'online' | 'offline' | 'checking';

const emptyService: Omit<Service, 'id'> = {
  name: '',
  type: 'open-webui',
  url: '',
  apiKey: '',
};

const Options: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [formState, setFormState] = useState<Omit<Service, 'id'>>(emptyService);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [statuses, setStatuses] = useState<Record<string, ServiceStatus>>({});

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    const response = await sendMessage({ action: 'getServices' });
    setServices(response || []);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormState((prev: Omit<Service, 'id'>) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.url) {
      alert('Service Name and URL are required.');
      return;
    }

    if (editingId) {
      await sendMessage({
        action: 'updateService',
        payload: { ...formState, id: editingId },
      });
    } else {
      await sendMessage({ action: 'addService', payload: formState });
    }

    setFormState(emptyService);
    setEditingId(null);
    fetchServices();
  };

  const handleEdit = (service: Service) => {
    setEditingId(service.id);
    setFormState({
      name: service.name,
      type: service.type,
      url: service.url,
      apiKey: service.apiKey,
    });
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this service?')) {
      await sendMessage({ action: 'removeService', payload: { id } });
      fetchServices();
    }
  };

  const handleCancelEdit = () => {
    setFormState(emptyService);
    setEditingId(null);
  }

  const handleCheckStatus = async (serviceId: string) => {
    setStatuses((prev: Record<string, ServiceStatus>) => ({ ...prev, [serviceId]: 'checking' }));
    const response = await sendMessage({
      action: 'checkStatus',
      payload: { serviceId },
    });
    setStatuses((prev: Record<string, ServiceStatus>) => ({ ...prev, [serviceId]: response.status }));
  };

  const handleExport = async () => {
    const servicesToExport = await sendMessage({ action: 'getServices' });
    const dataStr = JSON.stringify(servicesToExport, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `chatdemon-services-backup-${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const servicesToImport = JSON.parse(e.target?.result as string);
        // Basic validation
        if (Array.isArray(servicesToImport)) {
          await sendMessage({ action: 'importServices', payload: servicesToImport });
          fetchServices(); // Refresh the list
          alert('Services imported successfully!');
        } else {
          throw new Error('Invalid file format.');
        }
      } catch (error: any) {
        alert(`Error importing services: ${error.message}`);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className={styles.options}>
      <header className={styles.header}>
        <h1>ChatDemon Settings</h1>
        <div className={styles.headerActions}>
          <button onClick={handleExport}>Export Config</button>
          <label className={styles.importButton}>
            Import Config
            <input type="file" accept=".json" onChange={handleImport} style={{ display: 'none' }} />
          </label>
        </div>
      </header>
      <main className={styles.mainContent}>
        <h2>Service Connections</h2>
        <div className={styles.serviceList}>
          {services.length > 0 ? (
            services.map((service) => (
              <div key={service.id} className={styles.serviceItem}>
                <span className={`${styles.statusIndicator} ${styles[statuses[service.id] || 'unknown']}`}>
                  ●
                </span>
                <span>
                  {service.name} ({service.type})
                </span>
                <div>
                  <button onClick={() => handleCheckStatus(service.id)}>Check Status</button>
                  <button onClick={() => handleEdit(service)}>Edit</button>
                  <button
                    onClick={() => handleDelete(service.id)}
                    className={styles.deleteButton}
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p>No services configured.</p>
          )}
        </div>
        <div className={styles.formContainer}>
          <h3>{editingId ? 'Edit Service' : 'Add New Service'}</h3>
          <form className={styles.form} onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Service Name"
              value={formState.name}
              onChange={handleInputChange}
              required
            />
            <select
              name="type"
              value={formState.type}
              onChange={handleInputChange}
            >
              <option value="open-webui">OpenWebUI</option>
              <option value="a1111">A1111</option>
              <option value="comfy-ui">ComfyUI</option>
              <option value="ollama">Ollama</option>
            </select>
            <input
              type="text"
              name="url"
              placeholder="URL (e.g., http://localhost:8080)"
              value={formState.url}
              onChange={handleInputChange}
              required
            />
            <input
              type="password"
              name="apiKey"
              placeholder="API Key (optional)"
              value={formState.apiKey}
              onChange={handleInputChange}
            />
            <div className={styles.formActions}>
              <button type="submit">{editingId ? 'Save Changes' : 'Add Service'}</button>
              {editingId && <button type="button" onClick={handleCancelEdit}>Cancel</button>}
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};

export default Options; 
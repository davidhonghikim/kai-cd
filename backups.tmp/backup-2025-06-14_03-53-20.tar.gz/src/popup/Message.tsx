import React from 'react';
import { ChatMessage } from '../types/chat.types';
import styles from './Message.module.css';

interface MessageProps {
  message: ChatMessage;
  onGenerateImage: (prompt: string) => void;
}

const Message: React.FC<MessageProps> = ({ message, onGenerateImage }) => {
  return (
    <div className={`${styles.message} ${styles[message.sender]}`}>
      <p>{message.text}</p>
      {message.sender === 'user' && (
        <div className={styles.actions}>
          <button onClick={() => onGenerateImage(message.text)}>
            🎨 Generate Image
          </button>
        </div>
      )}
    </div>
  );
};

export default Message; 
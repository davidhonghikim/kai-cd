import React from 'react';
import styles from './ArtifactGallery.module.css';
import { ImageArtifact } from '../types/artifact.types';

interface ArtifactGalleryProps {
  isOpen: boolean;
  onClose: () => void;
  artifacts: ImageArtifact[];
  onDelete: (artifactId: string) => void;
}

const ArtifactGallery: React.FC<ArtifactGalleryProps> = ({
  isOpen,
  onClose,
  artifacts,
  onDelete,
}) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className={styles.overlay}>
      <div className={styles.panel}>
        <header className={styles.header}>
          <h2>Artifact Gallery</h2>
          <button onClick={onClose} className={styles.closeButton}>
            &times;
          </button>
        </header>
        <div className={styles.content}>
          {artifacts.length > 0 ? (
            <div className={styles.grid}>
              {artifacts.map((artifact) => (
                <div key={artifact.id} className={styles.gridItem}>
                  <img src={artifact.imageUrl} alt={artifact.prompt} />
                  <div className={styles.itemOverlay}>
                    <p>{artifact.prompt}</p>
                    <button
                      onClick={() => onDelete(artifact.id)}
                      className={styles.deleteButton}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>No image artifacts saved yet.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ArtifactGallery; 
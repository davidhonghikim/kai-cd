import React, { useState, useEffect } from 'react';
import styles from './App.module.css';
import { Service } from '../types/service.types';
import { sendMessage } from '../utils/chrome';
import { ChatMessage, Conversation } from '../types/chat.types';
import { Prompt } from '../types/prompt.types';
import AdvancedSettings from './AdvancedSettings';
import Message from './Message';
import HistoryViewer from './HistoryViewer';
import PromptManager from './PromptManager';
import ArtifactGallery from './ArtifactGallery';
import { ImageArtifact } from '../types/artifact.types';

const App: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [selectedService, setSelectedService] = useState<string>('');
  const [llmServices, setLlmServices] = useState<Service[]>([]);
  const [activeView, setActiveView] = useState<string>('chat'); // 'chat' or a service ID
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isPromptsOpen, setIsPromptsOpen] = useState(false);
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [artifacts, setArtifacts] = useState<ImageArtifact[]>([]);

  const fetchHistory = async () => {
    const history = (await sendMessage({ action: 'getChatHistory' })) || [];
    setConversations(history);
    return history;
  };

  const fetchPrompts = async () => {
    const fetchedPrompts = (await sendMessage({ action: 'getPrompts' })) || [];
    setPrompts(fetchedPrompts);
  };

  const fetchArtifacts = async () => {
    const fetchedArtifacts = (await sendMessage({ action: 'getArtifacts' })) || [];
    setArtifacts(fetchedArtifacts);
  };

  useEffect(() => {
    const loadData = async () => {
      // Fetch services
      const allServices: Service[] = (await sendMessage({ action: 'getServices' })) || [];
      setServices(allServices);

      const filteredLlmServices = allServices.filter(
        (s) => s.type === 'open-webui' || s.type === 'ollama'
      );
      setLlmServices(filteredLlmServices);

      if (filteredLlmServices.length > 0) {
        setSelectedService(filteredLlmServices[0].id);
      }

      // Fetch chat history
      const history = await fetchHistory();
      if (history.length > 0) {
        setMessages(history[history.length - 1].messages);
      }

      fetchPrompts();
      fetchArtifacts();
    };

    loadData();
  }, []);

  const uiServices = services.filter(
    (s) => s.type === 'open-webui' || s.type === 'a1111' || s.type === 'comfy-ui'
  );

  const activeService = services.find(s => s.id === activeView);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || !selectedService) return;

    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender: 'user',
      text: prompt,
    };
    setMessages((prev) => [...prev, userMessage]);
    setPrompt('');

    const response = await sendMessage({
      action: 'sendMessage',
      payload: {
        serviceId: selectedService,
        prompt: prompt,
      },
    });

    if (response && response.success) {
      // The AI message object is now sent back directly
      setMessages((prev) => [...prev, response.message]);
      fetchHistory(); // Refresh history after sending a message
    }
  };

  const handleGenerateImage = async (prompt: string) => {
    const imageServices = services.filter(
      (s) => s.type === 'a1111' || s.type === 'comfy-ui'
    );
    if (imageServices.length === 0) {
      alert('No image generation services configured.');
      return;
    }

    // Simple prompt for service selection
    const serviceNames = imageServices.map(s => s.name).join(', ');
    const selectedServiceName = window.prompt(
      `Enter the name of the image service to use:\n(${serviceNames})`
    );
    const selectedImageService = imageServices.find(
      (s) => s.name === selectedServiceName
    );

    if (selectedImageService) {
      console.log(`Sending prompt to image service: ${selectedImageService.name}`);
      const response = await sendMessage({
        action: 'generateImage',
        payload: {
          serviceId: selectedImageService.id,
          prompt,
        },
      });
      // For now, just log the result. In the future, this would display the image.
      console.log('Image generation response:', response);
    } else {
      alert('Invalid image service name.');
    }
  };

  const handleDeleteConversation = async (conversationId: string) => {
    if (window.confirm('Are you sure you want to delete this conversation?')) {
      await sendMessage({
        action: 'deleteConversation',
        payload: { conversationId },
      });
      fetchHistory(); // Refresh history
    }
  };

  const handleLoadConversation = (conversationId: string) => {
    const conversation = conversations.find(c => c.id === conversationId);
    if (conversation) {
      setMessages(conversation.messages);
      setSelectedService(conversation.serviceId);
      setIsHistoryOpen(false); // Close viewer after loading
    }
  };

  const handleDeleteArtifact = async (artifactId: string) => {
    if (window.confirm('Are you sure you want to delete this artifact?')) {
      await sendMessage({ action: 'deleteArtifact', payload: { artifactId } });
      fetchArtifacts(); // Refresh
    }
  };

  const handleSavePrompt = async (prompt: Omit<Prompt, 'id'>) => {
    await sendMessage({ action: 'savePrompt', payload: prompt });
    fetchPrompts(); // Refresh
  };

  const handleDeletePrompt = async (promptId: string) => {
    await sendMessage({ action: 'deletePrompt', payload: { promptId } });
    fetchPrompts(); // Refresh
  };

  const handleUsePrompt = (promptText: string) => {
    setPrompt(promptText);
    setIsPromptsOpen(false);
  };

  return (
    <div className={styles.app}>
      <header className={styles.header}>
        <h1>ChatDemon</h1>
        <div className={styles.headerControls}>
          <select
            value={selectedService}
            onChange={(e) => setSelectedService(e.target.value)}
            disabled={llmServices.length === 0}
          >
            {llmServices.length > 0 ? (
              llmServices.map((service) => (
                <option key={service.id} value={service.id}>
                  {service.name}
                </option>
              ))
            ) : (
              <option>No LLM services configured</option>
            )}
          </select>
          <button onClick={() => setIsSettingsOpen(true)} className={styles.settingsButton}>
            ⚙️
          </button>
          <button onClick={() => setIsHistoryOpen(true)} className={styles.historyButton}>
            📜
          </button>
          <button onClick={() => setIsGalleryOpen(true)} className={styles.galleryButton}>
            🖼️
          </button>
          <button onClick={() => setIsPromptsOpen(true)} className={styles.promptButton}>
            💡
          </button>
        </div>
      </header>
      <main className={styles.mainContent}>
        {activeView === 'chat' ? (
          <div className={styles.chatWindow}>
            {messages.length > 0 ? (
              messages.map((msg) => (
                <Message
                  key={msg.id}
                  message={msg}
                  onGenerateImage={handleGenerateImage}
                />
              ))
            ) : (
              <p>Chat history will appear here...</p>
            )}
          </div>
        ) : (
          <iframe
            src={activeService?.url}
            className={styles.iframe}
            title={activeService?.name}
          />
        )}
        <div className={styles.tabs}>
          <button 
            onClick={() => setActiveView('chat')}
            className={activeView === 'chat' ? styles.activeTab : ''}
          >
            Chat
          </button>
          {uiServices.map(service => (
            <button 
              key={service.id}
              onClick={() => setActiveView(service.id)}
              className={activeView === service.id ? styles.activeTab : ''}
            >
              {service.name}
            </button>
          ))}
        </div>
      </main>
      <footer className={styles.footer}>
        <form onSubmit={handleSendMessage} className={styles.promptForm}>
          <input
            type="text"
            placeholder="Enter a prompt..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <button type="submit">Send</button>
        </form>
      </footer>
      <AdvancedSettings
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
      <HistoryViewer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        conversations={conversations}
        onDelete={handleDeleteConversation}
        onLoad={handleLoadConversation}
        onImport={fetchHistory}
      />
      <ArtifactGallery
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        artifacts={artifacts}
        onDelete={handleDeleteArtifact}
      />
      <PromptManager
        isOpen={isPromptsOpen}
        onClose={() => setIsPromptsOpen(false)}
        prompts={prompts}
        onSave={handleSavePrompt}
        onDelete={handleDeletePrompt}
        onUse={handleUsePrompt}
      />
    </div>
  );
};

export default App; 
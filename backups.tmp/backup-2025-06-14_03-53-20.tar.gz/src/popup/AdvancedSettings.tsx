import React from 'react';
import styles from './AdvancedSettings.module.css';

interface AdvancedSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

const AdvancedSettings: React.FC<AdvancedSettingsProps> = ({ isOpen, onClose }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className={styles.overlay}>
      <div className={styles.panel}>
        <header className={styles.header}>
          <h2>Advanced Settings</h2>
          <button onClick={onClose} className={styles.closeButton}>
            &times;
          </button>
        </header>
        <div className={styles.content}>
          <p>Advanced settings will go here.</p>
          <p>For example, temperature, max tokens, etc.</p>
        </div>
      </div>
    </div>
  );
};

export default AdvancedSettings; 
import { storageManager } from '../storage/storageManager';
import { Service, ServiceType } from '../types/service.types';
import { LLMConnector } from '../types/llm.types';
import { OpenWebUIConnector } from '../services/llm/openWebUIConnector';
import { OllamaConnector } from '../services/llm/ollamaConnector';
import { ImageGenConnector } from '../types/image.types';
import { A1111Connector } from '../services/image/a1111Connector';
import { ComfyUIConnector } from '../services/image/comfyUIConnector';
import { ChatMessage, Conversation } from '../types/chat.types';
import { Prompt } from '../types/prompt.types';
import { ImageArtifact } from '../types/artifact.types';

console.log('Background script loaded and running.');

function getConnector(service: Service): LLMConnector | ImageGenConnector | null {
  switch (service.type) {
    case 'open-webui':
      return new OpenWebUIConnector(service);
    case 'ollama':
      return new OllamaConnector(service);
    case 'a1111':
      return new A1111Connector(service);
    case 'comfy-ui':
      return new ComfyUIConnector(service);
    default:
      console.warn(`No connector available for service type: ${service.type}`);
      return null;
  }
}

async function saveMessageToHistory(serviceId: string, userMessage: ChatMessage, aiMessage: ChatMessage) {
  const history: Conversation[] = await storageManager.get('chatHistory', []);
  
  // For simplicity, we'll just create a new conversation for each exchange.
  // A more advanced implementation would group them by session.
  const newConversation: Conversation = {
    id: `conv_${Date.now()}`,
    timestamp: Date.now(),
    serviceId: serviceId,
    messages: [userMessage, aiMessage],
  };

  history.push(newConversation);
  await storageManager.set('chatHistory', history);
}

async function saveImageArtifact(serviceId: string, prompt: string, imageUrl: string) {
  const artifacts: ImageArtifact[] = await storageManager.get('imageArtifacts', []);
  const newArtifact: ImageArtifact = {
    id: `artifact_${Date.now()}`,
    timestamp: Date.now(),
    serviceId,
    prompt,
    imageUrl,
  };
  artifacts.push(newArtifact);
  await storageManager.set('imageArtifacts', artifacts);
}

// Listener for messages from the UI
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Received message:', request);

  const { action, payload } = request;

  if (action === 'getServices') {
    storageManager.get('services', []).then(sendResponse);
    return true; // Indicates that the response is asynchronous
  }

  if (action === 'addService') {
    storageManager.get('services', []).then((services: Service[]) => {
      // Generate a unique ID for the new service
      const newService: Service = { ...payload, id: `service_${Date.now()}` };
      const newServices = [...services, newService];
      storageManager.set('services', newServices).then(() => {
        sendResponse({ success: true, services: newServices });
      });
    });
    return true;
  }

  if (action === 'updateService') {
    storageManager.get('services', []).then((services: Service[]) => {
      const newServices = services.map((s) =>
        s.id === payload.id ? payload : s
      );
      storageManager.set('services', newServices).then(() => {
        sendResponse({ success: true, services: newServices });
      });
    });
    return true;
  }

  if (action === 'removeService') {
    storageManager.get('services', []).then((services: Service[]) => {
      const newServices = services.filter((s) => s.id !== payload.id);
      storageManager.set('services', newServices).then(() => {
        sendResponse({ success: true, services: newServices });
      });
    });
    return true;
  }

  if (action === 'sendMessage') {
    const { serviceId, prompt } = payload;
    storageManager.get('services', []).then(async (services: Service[]) => {
      const service = services.find((s: Service) => s.id === serviceId);
      if (service) {
        const connector = getConnector(service) as LLMConnector;
        if (connector) {
          try {
            await connector.connect();
            // For now, we'll just use the first model as a default.
            const models = await connector.getModels();
            if (models.length > 0) {
              const responseText = await connector.sendMessage(prompt, models[0]);
              
              const userMessage: ChatMessage = { id: `msg_${Date.now()}`, sender: 'user', text: prompt };
              const aiMessage: ChatMessage = { id: `msg_${Date.now() + 1}`, sender: 'ai', text: responseText };
              
              await saveMessageToHistory(serviceId, userMessage, aiMessage);

              sendResponse({ success: true, message: aiMessage });
            } else {
              sendResponse({ success: false, error: 'No models found for this service.' });
            }
          } catch (error: any) {
            console.error('Error handling message:', error);
            sendResponse({ success: false, error: error.message });
          } finally {
            await connector.disconnect();
          }
        } else {
          sendResponse({ success: false, error: 'No valid connector for this service type.' });
        }
      } else {
        console.error(`Service with ID ${serviceId} not found.`);
        sendResponse({ success: false, error: 'Service not found' });
      }
    });
    return true;
  }

  if (action === 'generateImage') {
    const { serviceId, prompt } = payload;
    storageManager.get('services', []).then(async (services: Service[]) => {
      const service = services.find((s: Service) => s.id === serviceId);
      if (service) {
        const connector = getConnector(service) as ImageGenConnector;
        if (connector) {
          try {
            const models = await connector.getModels();
            if (models.length > 0) {
              const imageUrl = await connector.generateImage(prompt, models[0]);
              await saveImageArtifact(serviceId, prompt, imageUrl);
              sendResponse({ success: true, imageUrl });
            } else {
              sendResponse({ success: false, error: 'No models found for this service.' });
            }
          } catch (error: any) {
            console.error('Error generating image:', error);
            sendResponse({ success: false, error: error.message });
          }
        } else {
          sendResponse({ success: false, error: 'No valid connector for this service type.' });
        }
      } else {
        sendResponse({ success: false, error: 'Service not found' });
      }
    });
    return true;
  }

  if (action === 'checkStatus') {
    const { serviceId } = payload;
    storageManager.get('services', []).then(async (services: Service[]) => {
      const service = services.find((s: Service) => s.id === serviceId);
      if (service) {
        const connector = getConnector(service);
        if (connector) {
          try {
            // A simple status check can be to try fetching models
            if ('getModels' in connector) {
              await (connector as any).getModels();
              sendResponse({ success: true, status: 'online' });
            } else {
              // Or for LLM connectors, try to connect
              await (connector as LLMConnector).connect();
              await (connector as LLMConnector).disconnect();
              sendResponse({ success: true, status: 'online' });
            }
          } catch (error) {
            sendResponse({ success: false, status: 'offline' });
          }
        } else {
          sendResponse({ success: false, status: 'error', message: 'No connector found' });
        }
      } else {
        sendResponse({ success: false, status: 'error', message: 'Service not found' });
      }
    });
    return true;
  }

  if (action === 'getChatHistory') {
    storageManager.get('chatHistory', []).then(sendResponse);
    return true;
  }

  if (action === 'deleteConversation') {
    const { conversationId } = payload;
    storageManager.get('chatHistory', []).then(async (history: Conversation[]) => {
      const newHistory = history.filter(c => c.id !== conversationId);
      await storageManager.set('chatHistory', newHistory);
      sendResponse({ success: true });
    });
    return true;
  }

  if (action === 'importChatHistory') {
    const importedHistory = payload;
    if (Array.isArray(importedHistory)) {
      storageManager.set('chatHistory', importedHistory).then(() => {
        sendResponse({ success: true });
      });
    } else {
      sendResponse({ success: false, error: 'Invalid data format.' });
    }
    return true;
  }

  if (action === 'importServices') {
    const importedServices = payload;
    // Potentially add more robust validation here in the future
    if (Array.isArray(importedServices)) {
      storageManager.set('services', importedServices).then(() => {
        sendResponse({ success: true });
      });
    } else {
      sendResponse({ success: false, error: 'Invalid data format.' });
    }
    return true;
  }

  if (action === 'getPrompts') {
    storageManager.get('prompts', []).then(sendResponse);
    return true;
  }

  if (action === 'savePrompt') {
    storageManager.get('prompts', []).then(async (prompts: Prompt[]) => {
      const newPrompt: Prompt = { ...payload, id: `prompt_${Date.now()}` };
      const newPrompts = [...prompts, newPrompt];
      await storageManager.set('prompts', newPrompts);
      sendResponse({ success: true });
    });
    return true;
  }

  if (action === 'deletePrompt') {
    const { promptId } = payload;
    storageManager.get('prompts', []).then(async (prompts: Prompt[]) => {
      const newPrompts = prompts.filter(p => p.id !== promptId);
      await storageManager.set('prompts', newPrompts);
      sendResponse({ success: true });
    });
    return true;
  }

  if (action === 'getArtifacts') {
    storageManager.get('imageArtifacts', []).then(sendResponse);
    return true;
  }

  if (action === 'deleteArtifact') {
    const { artifactId } = payload;
    storageManager.get('imageArtifacts', []).then(async (artifacts: ImageArtifact[]) => {
      const newArtifacts = artifacts.filter(a => a.id !== artifactId);
      await storageManager.set('imageArtifacts', newArtifacts);
      sendResponse({ success: true });
    });
    return true;
  }

  // Optional: default response for unhandled actions
  console.warn('Unhandled action:', action);
  sendResponse({ success: false, error: 'Unknown action' });
  return false;
}); 
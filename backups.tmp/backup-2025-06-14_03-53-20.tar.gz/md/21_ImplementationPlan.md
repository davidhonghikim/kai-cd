# ChatDemon Implementation Plan

This document outlines the step-by-step implementation plan for the ChatDemon project. The plan is designed to be executed by a team of human and AI developers, ensuring clarity on completed, ongoing, and future tasks.

---

## Phase 1: Core Project Setup & Foundation

- **Status**: `[✅ Done]`
- **Description**: Configure the foundational elements of the project, including the directory structure, build tools, dependencies, and the core extension manifest.
- **Tasks**:
  - `[✅ Done]` **1.1: Initialize Project Structure**: Create directories as defined in `md/20_ProjectStructure.md`.
  - `[✅ Done]` **1.2: Setup Build Tools & Dependencies**: Configure Vite, TypeScript, ESLint, and Prettier.
  - `[✅ Done]` **1.3: Create manifest.json**: Define the core extension manifest.

## Phase 2: Core UI Shells

- **Status**: `[✅ Done]`
- **Description**: Create the basic React components and layouts for the primary user interfaces.
- **Tasks**:
  - `[✅ Done]` **2.1: Implement Popup UI Shell**: Build the main popup component with placeholders.
  - `[✅ Done]` **2.2: Implement Options Page Shell**: Build the options page UI for service configuration.

## Phase 3: Core Backend & Storage

- **Status**: `[✅ Done]`
- **Description**: Implement the foundational logic for data storage and background service management.
- **Tasks**:
  - `[✅ Done]` **3.1: Implement Storage Manager**: Create a utility for managing data in `chrome.storage.local`.
  - `[✅ Done]` **3.2: Implement Service Management in Background**: Add listeners to the background script to handle CRUD operations for services.

## Phase 4: Service Connector Interfaces

- **Status**: `[✅ Done]`
- **Description**: Define the TypeScript interfaces and types for all service connectors.
- **Tasks**:
  - `[✅ Done]` **4.1: Define Service Connector Types**: Create interfaces for LLM, Image, Automation, and Vector services.
  - `[✅ Done]` **4.2: Implement OpenWebUI Connector**: Create the initial LLM connector for OpenWebUI as a reference.

---

## Phase 5: MVP - UI & Backend Integration

- **Status**: `[▶️ In Progress]`
- **Description**: Connect the UI components to the background script to create a functional MVP. This is the current focus.
- **Tasks**:
  - `[▶️ In Progress]` **5.1: Connect Options Page to Background Script**: Wire up the Options page UI to allow adding, editing, and deleting services. This is the **current task**.
  - `[⬜ To Do]` **5.2: Populate Service Selector in Popup**: Fetch and display configured LLM services in the popup's dropdown menu.

## Phase 6: MVP - Iframe Tabbed Views

- **Status**: `[⬜ To Do]`
- **Description**: Implement the core feature of displaying services like OpenWebUI, A1111, and ComfyUI within iframes inside the popup.
- **Tasks**:
  - `[⬜ To Do]` **6.1: Service Tabs UI**: Dynamically render a tab for each configured service that has a web UI.
  - `[⬜ To Do]` **6.2: Iframe View**: Display the selected service's URL in an iframe.
  - `[⬜ To Do]` **6.3: View Toggling**: Ensure a clean switch between the Chat UI and the Iframe Tab views.

## Phase 7: MVP - Core Chat Functionality

- **Status**: `[⬜ To Do]`
- **Description**: Implement the end-to-end chat functionality.
- **Tasks**:
  - `[⬜ To Do]` **7.1: Send Chat Messages to Background**: Send user prompts from the popup to the background script.
  - `[⬜ To Do]` **7.2: Route Chat Messages to Connector**: The background script will route the message to the appropriate, selected LLM connector.
  - `[⬜ To Do]` **7.3: Display Chat History**: Render the conversation (user prompts and LLM responses) in the popup UI.

## Phase 8: Advanced UI & Features

- **Status**: `[⬜ To Do]`
- **Description**: Enhance the UI with advanced features for better usability.
- **Tasks**:
  - `[⬜ To Do]` **8.1: Collapsible Advanced Settings**: Implement a popout/collapsible menu for advanced settings within the main popup view.
  - `[⬜ To Do]` **8.2: Implement Ollama Connector**: Create a specific connector for Ollama to manage local models.
  - `[⬜ To Do]` **8.3: Implement A1111/ComfyUI Connectors**: Build connectors for image generation services.
  - `[⬜ To Do]` **8.4: Model Bridging UI**: Add UI elements to send chat prompts to image generation services.

## Phase 9: Server & Configuration Management

- **Status**: `[⬜ To Do]`
- **Description**: Build robust features for managing server connections and configurations.
- **Tasks**:
  - `[⬜ To Do]` **9.1: Server Status Indicators**: Show the connection status of each configured service.
  - `[⬜ To Do]` **9.2: Easy Server Switching**: Implement a seamless way to switch between active services.
  - `[⬜ To Do]` **9.3: Configuration Import/Export**: Allow users to back up and restore their service configurations to a JSON file.

## Phase 10: Chat & Prompt Management

- **Status**: `[⬜ To Do]`
- **Description**: Implement features for managing chat history and reusable prompts.
- **Tasks**:
  - `[⬜ To Do]` **10.1: Persistent Chat History**: Save all chat conversations to storage.
  - `[⬜ To Do]` **10.2: View/Delete Old Chats**: Create a UI to browse and delete previous conversations.
  - `[⬜ To Do]` **10.3: Import/Export Chats**: Allow single conversations or all history to be exported and imported.
  - `[⬜ To Do]` **10.4: Prompt Manager**: Create a UI to save, edit, and reuse frequently used prompts.

## Phase 11: Artifacts & Git Integration

- **Status**: `[⬜ To Do]`
- **Description**: Manage generated artifacts and integrate with Git for versioning.
- **Tasks**:
  - `[⬜ To Do]` **11.1: Artifact Gallery**: Create a view to browse, search, and manage generated images.
  - `[⬜ To Do]` **11.2: Automated Git Commits**: After significant, error-free changes, automatically commit the work with a descriptive message.
  - `[⬜ To Do]` **11.3: Source File Backups**: Implement a script to automatically back up the `/src` directory.

---

This plan will be updated as the project progresses.
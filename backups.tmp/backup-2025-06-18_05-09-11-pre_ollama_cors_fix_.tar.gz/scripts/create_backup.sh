#!/bin/bash
# ChatDemon Project Backup Script
# Usage: ./scripts/create_backup.sh [optional_tag]

# Get the current timestamp
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")

# Sanitize and process the tag
TAG_RAW=${1:-}
if [ -n "$TAG_RAW" ]; then
  # Lowercase, replace spaces and special chars with underscores
  TAG=$(echo "$TAG_RAW" | tr '[:upper:]' '[:lower:]' | tr -cs 'a-z0-9_' '_')
  BACKUP_FILE="backups/backup-${TIMESTAMP}-${TAG}.tar.gz"
else
  TAG="none"
  BACKUP_FILE="backups/backup-${TIMESTAMP}.tar.gz"
fi

# Create backup directory if it doesn't exist
mkdir -p "backups"

# Create the backup using tar with gzip compression
# Exclude common large or unnecessary dirs/files
# (same as before)
tar --exclude="node_modules" \
    --exclude=".git" \
    --exclude="dist" \
    --exclude="*.zip" \
    --exclude="*.tar.gz" \
    --exclude="backups" \
    --exclude="backups/*" \
    --exclude="*.log" \
    -zcvf "$BACKUP_FILE" ./

# Calculate size
SIZE=$(du -sh "$BACKUP_FILE" | cut -f1)

echo "====================================================="
echo "✅ Backup created at $BACKUP_FILE"
echo "📦 Backup size: $SIZE"
echo "====================================================="

# Append to backups.md
README_FILE="backups/backups.md"
echo "# Backup: $(date)" >> "$README_FILE"
echo "- **File**: $BACKUP_FILE" >> "$README_FILE"
echo "- **Size**: $SIZE" >> "$README_FILE"
echo "- **Tag**: $TAG_RAW" >> "$README_FILE"
echo "" >> "$README_FILE"

# Add current git commit if available
if command -v git &> /dev/null && git rev-parse --git-dir > /dev/null 2>&1; then
  COMMIT=$(git rev-parse HEAD)
  BRANCH=$(git rev-parse --abbrev-ref HEAD)
  echo "- **Commit**: $COMMIT" >> "$README_FILE"
  echo "- **Branch**: $BRANCH" >> "$README_FILE"
  echo "" >> "$README_FILE"
fi

echo "✅ Backup information appended to $README_FILE" 
import { SERVICE_TYPES, SERVICE_CATEGORIES } from './constants';
import type { Service } from '@/types';

export const DEFAULT_SERVICES: Service[] = [
  {
    id: 'default_ollama_1',
    name: 'Ollama Server',
    type: SERVICE_TYPES.OLLAMA,
    url: 'http://localhost:11434',
    enabled: true,
    status: 'active',
    category: SERVICE_CATEGORIES.LLM,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: true
  },
  {
    id: 'default_openwebui_1',
    name: 'Open WebUI Server',
    type: SERVICE_TYPES.OPEN_WEBUI,
    url: 'http://localhost:3000',
    enabled: true,
    status: 'inactive',
    category: SERVICE_CATEGORIES.LLM,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_a1111_1',
    name: 'A1111 Server',
    type: SERVICE_TYPES.A1111,
    url: 'http://localhost:7860',
    enabled: true,
    status: 'inactive',
    category: SERVICE_CATEGORIES.IMAGE_GENERATION,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_comfyui_1',
    name: 'ComfyUI Server',
    type: SERVICE_TYPES.COMFY_UI,
    url: 'http://localhost:8188',
    enabled: true,
    status: 'inactive',
    category: SERVICE_CATEGORIES.IMAGE_GENERATION,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  }
]; 
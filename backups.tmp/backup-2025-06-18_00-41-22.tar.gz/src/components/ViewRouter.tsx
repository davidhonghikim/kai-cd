import React, { useState } from 'react';
import { Service } from '@/types';
import { SERVICE_CATEGORIES, SERVICE_TYPES } from '@/config/constants';
import { IframeView } from './IframeView';
import A1111View from '@/views/A1111View';
import ComfyUIView from '@/views/ComfyUIView';
import ChatView from '@/views/ChatView';
import styles from '@/styles/components/ViewRouter.module.css';

export interface ViewRouterProps {
  service: Service;
  onClose: () => void;
}

export const ViewRouter: React.FC<ViewRouterProps> = ({ service, onClose }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Detect if we are in a tab context
  const isTab = typeof window !== 'undefined' && window.location.pathname.includes('/tab/');

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const handleRefresh = () => {
    // Implement refresh logic if needed
    window.location.reload();
  };

  const renderView = () => {
    const category = service.category;
    
    // Debug logging
    console.log('ViewRouter - Service:', {
      name: service.name,
      type: service.type,
      category: category,
      url: service.url
    });

    if (category === SERVICE_CATEGORIES.IMAGE_GENERATION) {
      if (service.type === SERVICE_TYPES.A1111) {
        return <A1111View service={service} isTab={isTab} />;
      } else if (service.type === SERVICE_TYPES.COMFY_UI) {
        return <ComfyUIView service={service} isTab={isTab} />;
      }
    }

    // Always use IframeView for Open WebUI
    if (service.type === SERVICE_TYPES.OPEN_WEBUI) {
      return (
        <IframeView
          url={service.url}
          onClose={onClose}
          onFullscreen={handleFullscreen}
          onRefresh={handleRefresh}
          isFullscreen={isFullscreen}
        />
      );
    }

    if (category === SERVICE_CATEGORIES.LLM) {
      console.log('Routing to ChatView for LLM service:', service.name);
      return <ChatView service={service} isTab={isTab} />;
    }

    // Also check by service type for LLM services as fallback
    if (service.type === SERVICE_TYPES.OLLAMA || 
        service.type === SERVICE_TYPES.OPENAI_COMPATIBLE) {
      console.log('Routing to ChatView for LLM service type:', service.type);
      return <ChatView service={service} isTab={isTab} />;
    }

    console.log('Falling back to IframeView for service:', service.name);
    // Fallback to iframe for other service types
    return (
      <IframeView
        url={service.url}
        onClose={onClose}
        onFullscreen={handleFullscreen}
        onRefresh={handleRefresh}
        isFullscreen={isFullscreen}
      />
    );
  };

  return (
    <div className={styles.container}>
      {renderView()}
    </div>
  );
};

export default ViewRouter;

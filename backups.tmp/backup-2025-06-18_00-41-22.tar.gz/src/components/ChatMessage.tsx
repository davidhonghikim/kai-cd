import React, { useState } from 'react';
import { ChatMessage as ChatMessageType } from '@/types';
import styles from '@/styles/components/ChatMessage.module.css';

interface ChatMessageProps {
  message: ChatMessageType;
  onEdit?: (messageId: string, newContent: string) => void;
  onCopy?: (content: string) => void;
  onContinue?: (messageId: string) => void;
  onRegenerate?: (messageId: string) => void;
  onRate?: (messageId: string, rating: 'good' | 'bad') => void;
  onGenerateImage?: (prompt: string) => void;
  onReadAloud?: (content: string) => void;
  onDelete?: (messageId: string) => void;
  showActions?: boolean;
  isLastMessage?: boolean;
}

const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  onEdit,
  onCopy,
  onContinue,
  onRegenerate,
  onRate,
  onGenerateImage,
  onReadAloud,
  onDelete,
  showActions = true,
  isLastMessage = false
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    onCopy?.(message.content);
  };

  const handleEdit = () => {
    if (isEditing) {
      onEdit?.(message.id, editContent);
      setIsEditing(false);
    } else {
      setIsEditing(true);
    }
  };

  const handleContinue = () => {
    onContinue?.(message.id);
  };

  const handleRegenerate = () => {
    onRegenerate?.(message.id);
  };

  const handleRate = (rating: 'good' | 'bad') => {
    onRate?.(message.id, rating);
  };

  const handleGenerateImage = () => {
    onGenerateImage?.(message.content);
  };

  const handleReadAloud = () => {
    onReadAloud?.(message.content);
  };

  const handleDelete = () => {
    onDelete?.(message.id);
  };

  if (message.role === 'user') {
    return (
      <div className={`${styles.messageContainer} ${styles.userMessageContainer} group`}>
        <div className={styles.messageContent}>
          {isEditing ? (
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className={styles.editTextarea}
              autoFocus
            />
          ) : (
            <div className={styles.messageText}>{message.content}</div>
          )}
        </div>
        
        {showActions && (
          <div className={styles.messageActions}>
            {onEdit && (
              <button 
                onClick={handleEdit} 
                className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
                title="Edit"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125"></path>
                </svg>
              </button>
            )}
            
            <button 
              onClick={handleCopy} 
              className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
              title="Copy"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184"></path>
              </svg>
            </button>
            
            {onDelete && (
              <button 
                onClick={handleDelete} 
                className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
                title="Delete"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"></path>
                </svg>
              </button>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`${styles.messageContainer} ${styles.assistantMessageContainer} group`}>
      <div className={styles.messageContent}>
        <div className={styles.messageText}>{message.content}</div>
      </div>
      
      {showActions && (
        <div className={styles.messageActions}>
          {onEdit && (
            <button 
              onClick={handleEdit} 
              className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
              title="Edit"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125"></path>
              </svg>
            </button>
          )}
          
          <button 
            onClick={handleCopy} 
            className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
            title="Copy"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184"></path>
            </svg>
          </button>
          
          {onReadAloud && (
            <button 
              onClick={handleReadAloud} 
              className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
              title="Read Aloud"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z"></path>
              </svg>
            </button>
          )}
          
          {onGenerateImage && (
            <button 
              onClick={handleGenerateImage} 
              className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
              title="Generate Image"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/>
              </svg>
            </button>
          )}
          
          {onRate && (
            <>
              <button 
                onClick={() => handleRate('good')} 
                className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
                title="Good Response"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path>
                </svg>
              </button>
              
              <button 
                onClick={() => handleRate('bad')} 
                className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
                title="Bad Response"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"></path>
                </svg>
              </button>
            </>
          )}
          
          {onContinue && isLastMessage && (
            <button 
              onClick={handleContinue} 
              className={`${styles.actionButton} ${styles.visible}`} 
              title="Continue Response"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"></path>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.91 11.672a.375.375 0 0 1 0 .656l-5.603 3.113a.375.375 0 0 1-.557-.328V8.887c0-.286.307-.466.557-.327l5.603 3.112Z"></path>
              </svg>
            </button>
          )}
          
          {onRegenerate && (
            <button 
              onClick={handleRegenerate} 
              className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
              title="Regenerate"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"></path>
              </svg>
            </button>
          )}
          
          {onDelete && (
            <button 
              onClick={handleDelete} 
              className={`${styles.actionButton} ${isLastMessage ? styles.visible : styles.hidden}`} 
              title="Delete"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"></path>
              </svg>
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default ChatMessage;

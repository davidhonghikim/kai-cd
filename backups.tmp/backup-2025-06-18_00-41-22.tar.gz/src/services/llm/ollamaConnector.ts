import { LLMConnector } from './LLMConnector';
import type { Service, ChatMessage, ChatCompletionRequest, CompletionRequest, EmbeddingRequest, ChatCompletionResponse, CompletionResponse, EmbeddingResponse, LLMModel, GenerationParams } from '@/types';

interface OllamaModel {
  name: string;
  modified_at: string;
  size: number;
}

export class OllamaConnector extends LLMConnector {
  constructor(service: Service) {
    super(service as any);
  }

  async connect(): Promise<boolean> {
    // Try to fetch models as a connectivity check
    try {
      await this.getModels();
      return true;
    } catch {
      return false;
    }
  }

  async disconnect(): Promise<void> {
    // Disconnect implementation
  }

  async checkStatus(): Promise<{ isOnline: boolean; details?: any; error?: string }> {
    try {
      await this.getModels();
      return { isOnline: true, details: this.service };
    } catch (error) {
      return { isOnline: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  private async fetchWithAuth(path: string, options: RequestInit = {}): Promise<Response> {
    const url = `${this.service.url}${path}`;
    const headers = {
      'Content-Type': 'application/json',
      ...(this.service.apiKey ? { 'Authorization': `Bearer ${this.service.apiKey}` } : {})
    };
    
    // Create new AbortController for this request
    this.abortController = new AbortController();
    
    return fetch(url, { 
      ...options, 
      headers,
      signal: this.abortController.signal
    });
  }

  public abortRequest(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }

  async validateConfig(): Promise<{ isValid: boolean; errors?: string[]; warnings?: string[] }> {
    try {
      const response = await this.fetchWithAuth('/api/tags');
      return { isValid: response.ok };
    } catch (error) {
      return { isValid: false, errors: ['Failed to connect to Ollama service'] };
    }
  }

  async getModelStatus(): Promise<Record<string, boolean>> {
    try {
      const response = await this.fetchWithAuth('/api/tags');
      const data = await response.json();
      const models = data.models || [];
      const status: Record<string, boolean> = {};
      models.forEach((model: OllamaModel) => {
        status[model.name] = true;
      });
      return status;
    } catch (error) {
      return {};
    }
  }

  public async getModels(): Promise<LLMModel[]> {
    try {
      console.log('[OllamaConnector] Fetching models from:', `${this.service.url}/api/tags`);
      const response = await this.fetchWithAuth('/api/tags');
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('[OllamaConnector] HTTP error fetching models:', errorText);
        throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
      }
      
      const data = await response.json();
      console.log('[OllamaConnector] Raw models response:', data);
      
      const models = data.models || [];
      console.log('[OllamaConnector] Found models:', models);
      
      const mappedModels = models.map((model: OllamaModel) => ({
        id: model.name,
        name: model.name,
        provider: 'ollama',
        contextLength: 4096,
        parameters: model.size
      }));
      
      console.log('[OllamaConnector] Mapped models:', mappedModels);
      return mappedModels;
    } catch (error) {
      console.error('[OllamaConnector] Error fetching models:', error);
      console.error('[OllamaConnector] Error stack:', error instanceof Error ? error.stack : 'No stack');
      return [];
    }
  }

  public async chat(messages: ChatMessage[], model: string, options: GenerationParams = {}): Promise<ChatMessage> {
    const request: ChatCompletionRequest = {
      model: model || 'gemma3:1b',
      messages,
      options: {
        temperature: options.temperature || 0.7,
        top_p: options.topP || 0.9,
        top_k: options.topK || 40,
        max_tokens: options.maxTokens || 2048, // Increased default
        stop: options.stopSequences || []
      }
    };

    console.log('[OllamaConnector] Chat request:', JSON.stringify(request, null, 2));

    try {
      const response = await this.fetchWithAuth('/api/chat', {
        method: 'POST',
        body: JSON.stringify(request)
      });
      
      console.log('[OllamaConnector] Response status:', response.status);
      console.log('[OllamaConnector] Response headers:', Object.fromEntries(response.headers.entries()));
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('[OllamaConnector] HTTP error response:', errorText);
        throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
      }
      
      const responseText = await response.text();
      console.log('[OllamaConnector] Raw response text (first 500 chars):', responseText.substring(0, 500));
      console.log('[OllamaConnector] Raw response text length:', responseText.length);
      
      // Parse only the JSON part, ignoring any trailing content
      let jsonText = responseText;
      
      // Find the complete JSON object by counting braces
      let braceCount = 0;
      let jsonEndIndex = -1;
      let inString = false;
      let escapeNext = false;
      
      console.log('[OllamaConnector] Starting JSON extraction...');
      
      for (let i = 0; i < responseText.length; i++) {
        const char = responseText[i];
        
        if (escapeNext) {
          escapeNext = false;
          continue;
        }
        
        if (char === '\\') {
          escapeNext = true;
          continue;
        }
        
        if (char === '"' && !escapeNext) {
          inString = !inString;
          continue;
        }
        
        if (!inString) {
          if (char === '{') {
            braceCount++;
            if (braceCount === 1) {
              console.log('[OllamaConnector] Found start of JSON at position:', i);
            }
          } else if (char === '}') {
            braceCount--;
            console.log('[OllamaConnector] Found closing brace at position:', i, 'braceCount:', braceCount);
            if (braceCount === 0) {
              jsonEndIndex = i;
              console.log('[OllamaConnector] Found end of JSON at position:', i);
              break;
            }
          }
        }
      }
      
      console.log('[OllamaConnector] JSON extraction result - jsonEndIndex:', jsonEndIndex, 'responseText.length:', responseText.length);
      
      if (jsonEndIndex !== -1 && jsonEndIndex < responseText.length - 1) {
        const extraContent = responseText.substring(jsonEndIndex + 1);
        console.warn('[OllamaConnector] Extra content after JSON:', extraContent);
        jsonText = responseText.substring(0, jsonEndIndex + 1);
        console.log('[OllamaConnector] Extracted JSON text (first 500 chars):', jsonText.substring(0, 500));
      } else {
        console.log('[OllamaConnector] No extra content found, using full response text');
      }
      
      console.log('[OllamaConnector] About to parse JSON, length:', jsonText.length);
      console.log('[OllamaConnector] JSON text ends with:', jsonText.substring(Math.max(0, jsonText.length - 50)));
      
      const data: ChatCompletionResponse = JSON.parse(jsonText);
      console.log('[OllamaConnector] Parsed response data:', data);
      console.log('[OllamaConnector] Response data keys:', Object.keys(data));
      console.log('[OllamaConnector] Message object:', data.message);
      console.log('[OllamaConnector] Message content type:', typeof data.message?.content);
      console.log('[OllamaConnector] Message content length:', data.message?.content?.length);
      
      const result = data.message?.content || '';
      console.log('[OllamaConnector] Final result (first 200 chars):', result.substring(0, 200));
      console.log('[OllamaConnector] Final result length:', result.length);
      
      // Debug: Log the full result
      console.log('[OllamaConnector] FULL RESULT:', result);
      console.log('[OllamaConnector] FULL RESULT JSON:', JSON.stringify(result));
      
      // Return full ChatMessage object
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: result,
        timestamp: Date.now()
      };
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        console.log('[OllamaConnector] Request was aborted');
        throw new Error('Request was cancelled');
      }
      console.error('[OllamaConnector] Error in chat completion:', error);
      throw error;
    } finally {
      this.abortController = null;
    }
  }

  public async completion(prompt: string, model: string, options: GenerationParams = {}): Promise<string> {
    const request: CompletionRequest = {
      model: model || 'gemma3:1b',
      prompt,
      options: {
        temperature: options.temperature || 0.7,
        top_p: options.topP || 0.9,
        top_k: options.topK || 40,
        max_tokens: options.maxTokens || 2048,
        stop: options.stopSequences || []
      }
    };

    try {
      const response = await this.fetchWithAuth('/api/generate', {
        method: 'POST',
        body: JSON.stringify(request)
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: CompletionResponse = await response.json();
      return data.response || '';
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        console.log('[OllamaConnector] Request was aborted');
        throw new Error('Request was cancelled');
      }
      console.error('Error in completion:', error);
      throw error;
    }
  }

  public async embedding(text: string): Promise<number[]> {
    const model = 'gemma3:1b';
    const request: EmbeddingRequest = {
      model,
      input: text
    };

    try {
      const response = await this.fetchWithAuth('/api/embeddings', {
        method: 'POST',
        body: JSON.stringify(request)
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: EmbeddingResponse = await response.json();
      return data.embedding || [];
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        console.log('[OllamaConnector] Request was aborted');
        throw new Error('Request was cancelled');
      }
      console.error('Error in embedding:', error);
      throw error;
    }
  }

  public async tokenize(_text: string): Promise<number[]> {
    // Placeholder implementation
    return [];
  }

  public async detokenize(_tokens: number[]): Promise<string> {
    // Placeholder implementation
    return '';
  }
} 

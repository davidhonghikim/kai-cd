// Chrome extension messaging utility
interface MessageResponse {
  success: boolean;
  data?: any;
  error?: string;
  status?: string;
  services?: any[];
}

export const sendMessage = async (action: string, data: any): Promise<MessageResponse> => {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action, payload: data }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Chrome runtime error:', chrome.runtime.lastError);
        resolve({
          success: false,
          error: chrome.runtime.lastError.message || 'Failed to send message'
        });
      } else {
        resolve(response || { success: false, error: 'No response received' });
      }
    });
  });
};

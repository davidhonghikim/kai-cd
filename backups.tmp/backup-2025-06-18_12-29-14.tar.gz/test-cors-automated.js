#!/usr/bin/env node

/**
 * Automated CORS Test for ChatDemon Extension
 * Tests remote Ollama connection with various configurations
 */

const https = require('https');
const http = require('http');

// Test configuration
const TEST_CONFIG = {
  remoteUrl: 'http://192.168.1.180:11434',
  model: 'gemma3:1b',
  testMessage: 'tell a joke',
  timeout: 10000,
  extensionId: 'test-extension-id' // Mock extension ID for testing
};

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function logHeader(message) {
  log(`\n${'='.repeat(60)}`, 'cyan');
  log(`  ${message}`, 'bright');
  log(`${'='.repeat(60)}`, 'cyan');
}

function logTest(testName, status, details = '') {
  const statusIcon = status === 'PASS' ? '✅' : status === 'FAIL' ? '❌' : '⚠️';
  const statusColor = status === 'PASS' ? 'green' : status === 'FAIL' ? 'red' : 'yellow';
  
  log(`${statusIcon} ${testName}: ${status}`, statusColor);
  if (details) {
    log(`   ${details}`, 'yellow');
  }
}

// Test 1: Basic connectivity test
async function testBasicConnectivity() {
  logHeader('Test 1: Basic Connectivity');
  
  return new Promise((resolve) => {
    const url = new URL(`${TEST_CONFIG.remoteUrl}/api/tags`);
    const req = http.request(url, { timeout: TEST_CONFIG.timeout }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            const models = JSON.parse(data);
            logTest('Basic Connectivity', 'PASS', `Found ${models.models?.length || 0} models`);
            resolve(true);
          } catch (e) {
            logTest('Basic Connectivity', 'FAIL', 'Invalid JSON response');
            resolve(false);
          }
        } else {
          logTest('Basic Connectivity', 'FAIL', `HTTP ${res.statusCode}: ${res.statusMessage}`);
          resolve(false);
        }
      });
    });
    
    req.on('error', (err) => {
      logTest('Basic Connectivity', 'FAIL', err.message);
      resolve(false);
    });
    
    req.on('timeout', () => {
      logTest('Basic Connectivity', 'FAIL', 'Request timeout');
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

// Test 2: CORS preflight test
async function testCORSPreflight() {
  logHeader('Test 2: CORS Preflight');
  
  return new Promise((resolve) => {
    const url = new URL(`${TEST_CONFIG.remoteUrl}/api/chat`);
    const req = http.request(url, {
      method: 'OPTIONS',
      headers: {
        'Origin': `chrome-extension://${TEST_CONFIG.extensionId}`,
        'Access-Control-Request-Method': 'POST',
        'Access-Control-Request-Headers': 'Content-Type, User-Agent, Accept, Accept-Language'
      },
      timeout: TEST_CONFIG.timeout
    }, (res) => {
      const corsHeaders = {
        'Access-Control-Allow-Origin': res.headers['access-control-allow-origin'],
        'Access-Control-Allow-Methods': res.headers['access-control-allow-methods'],
        'Access-Control-Allow-Headers': res.headers['access-control-allow-headers']
      };
      
      if (res.statusCode === 204 || res.statusCode === 200) {
        if (corsHeaders['Access-Control-Allow-Origin']) {
          logTest('CORS Preflight', 'PASS', `Origin: ${corsHeaders['Access-Control-Allow-Origin']}`);
          resolve(true);
        } else {
          logTest('CORS Preflight', 'FAIL', 'Missing Access-Control-Allow-Origin header');
          resolve(false);
        }
      } else {
        logTest('CORS Preflight', 'FAIL', `HTTP ${res.statusCode}: ${res.statusMessage}`);
        resolve(false);
      }
    });
    
    req.on('error', (err) => {
      logTest('CORS Preflight', 'FAIL', err.message);
      resolve(false);
    });
    
    req.on('timeout', () => {
      logTest('CORS Preflight', 'FAIL', 'Request timeout');
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

// Test 3: Extension-style request test (WITH Origin header)
async function testExtensionRequestWithOrigin() {
  logHeader('Test 3: Extension Request with Origin Header');
  
  return new Promise((resolve) => {
    const url = new URL(`${TEST_CONFIG.remoteUrl}/api/chat`);
    const requestBody = JSON.stringify({
      model: TEST_CONFIG.model,
      messages: [{ role: 'user', content: TEST_CONFIG.testMessage }],
      options: {
        temperature: 0.7,
        top_p: 0.9,
        top_k: 40,
        max_tokens: 2048,
        stop: []
      }
    });
    
    const req = http.request(url, {
      method: 'POST',
      headers: {
        'User-Agent': 'ChatDemon-Extension/1.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json',
        'Origin': `chrome-extension://${TEST_CONFIG.extensionId}`,
        'Content-Length': Buffer.byteLength(requestBody)
      },
      timeout: TEST_CONFIG.timeout
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            const response = JSON.parse(data);
            if (response.message && response.message.content) {
              logTest('Extension Request with Origin', 'PASS', `Response: "${response.message.content.substring(0, 50)}..."`);
              resolve(true);
            } else {
              logTest('Extension Request with Origin', 'FAIL', 'Invalid response format');
              resolve(false);
            }
          } catch (e) {
            logTest('Extension Request with Origin', 'FAIL', 'Invalid JSON response');
            resolve(false);
          }
        } else {
          logTest('Extension Request with Origin', 'FAIL', `HTTP ${res.statusCode}: ${res.statusMessage}`);
          if (data) {
            log(`   Response body: ${data}`, 'yellow');
          }
          resolve(false);
        }
      });
    });
    
    req.on('error', (err) => {
      logTest('Extension Request with Origin', 'FAIL', err.message);
      resolve(false);
    });
    
    req.on('timeout', () => {
      logTest('Extension Request with Origin', 'FAIL', 'Request timeout');
      req.destroy();
      resolve(false);
    });
    
    req.write(requestBody);
    req.end();
  });
}

// Test 4: Extension-style request test (WITHOUT Origin header - for comparison)
async function testExtensionRequestWithoutOrigin() {
  logHeader('Test 4: Extension Request without Origin Header');
  
  return new Promise((resolve) => {
    const url = new URL(`${TEST_CONFIG.remoteUrl}/api/chat`);
    const requestBody = JSON.stringify({
      model: TEST_CONFIG.model,
      messages: [{ role: 'user', content: TEST_CONFIG.testMessage }],
      options: {
        temperature: 0.7,
        top_p: 0.9,
        top_k: 40,
        max_tokens: 2048,
        stop: []
      }
    });
    
    const req = http.request(url, {
      method: 'POST',
      headers: {
        'User-Agent': 'ChatDemon-Extension/1.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(requestBody)
      },
      timeout: TEST_CONFIG.timeout
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            const response = JSON.parse(data);
            if (response.message && response.message.content) {
              logTest('Extension Request without Origin', 'PASS', `Response: "${response.message.content.substring(0, 50)}..."`);
              resolve(true);
            } else {
              logTest('Extension Request without Origin', 'FAIL', 'Invalid response format');
              resolve(false);
            }
          } catch (e) {
            logTest('Extension Request without Origin', 'FAIL', 'Invalid JSON response');
            resolve(false);
          }
        } else {
          logTest('Extension Request without Origin', 'FAIL', `HTTP ${res.statusCode}: ${res.statusMessage}`);
          if (data) {
            log(`   Response body: ${data}`, 'yellow');
          }
          resolve(false);
        }
      });
    });
    
    req.on('error', (err) => {
      logTest('Extension Request without Origin', 'FAIL', err.message);
      resolve(false);
    });
    
    req.on('timeout', () => {
      logTest('Extension Request without Origin', 'FAIL', 'Request timeout');
      req.destroy();
      resolve(false);
    });
    
    req.write(requestBody);
    req.end();
  });
}

// Test 5: CORS headers validation
async function testCORSHeaders() {
  logHeader('Test 5: CORS Headers Validation');
  
  return new Promise((resolve) => {
    const url = new URL(`${TEST_CONFIG.remoteUrl}/api/chat`);
    const req = http.request(url, {
      method: 'POST',
      headers: {
        'User-Agent': 'ChatDemon-Extension/1.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json',
        'Origin': `chrome-extension://${TEST_CONFIG.extensionId}`
      },
      timeout: TEST_CONFIG.timeout
    }, (res) => {
      const corsHeaders = {
        'Access-Control-Allow-Origin': res.headers['access-control-allow-origin'],
        'Access-Control-Allow-Methods': res.headers['access-control-allow-methods'],
        'Access-Control-Allow-Headers': res.headers['access-control-allow-headers']
      };
      
      log('CORS Headers Found:', 'blue');
      Object.entries(corsHeaders).forEach(([key, value]) => {
        if (value) {
          log(`   ${key}: ${value}`, 'green');
        } else {
          log(`   ${key}: MISSING`, 'red');
        }
      });
      
      if (corsHeaders['Access-Control-Allow-Origin']) {
        logTest('CORS Headers', 'PASS', 'Required headers present');
        resolve(true);
      } else {
        logTest('CORS Headers', 'FAIL', 'Missing required CORS headers');
        resolve(false);
      }
    });
    
    req.on('error', (err) => {
      logTest('CORS Headers', 'FAIL', err.message);
      resolve(false);
    });
    
    req.on('timeout', () => {
      logTest('CORS Headers', 'FAIL', 'Request timeout');
      req.destroy();
      resolve(false);
    });
    
    req.write(JSON.stringify({
      model: TEST_CONFIG.model,
      messages: [{ role: 'user', content: 'test' }],
      options: { temperature: 0.7 }
    }));
    req.end();
  });
}

// Main test runner
async function runAllTests() {
  logHeader('ChatDemon Extension CORS Automated Test Suite');
  log(`Target Server: ${TEST_CONFIG.remoteUrl}`, 'blue');
  log(`Test Model: ${TEST_CONFIG.model}`, 'blue');
  log(`Extension ID: ${TEST_CONFIG.extensionId}`, 'blue');
  log(`Timeout: ${TEST_CONFIG.timeout}ms`, 'blue');
  
  const results = {
    connectivity: await testBasicConnectivity(),
    corsPreflight: await testCORSPreflight(),
    extensionRequestWithOrigin: await testExtensionRequestWithOrigin(),
    extensionRequestWithoutOrigin: await testExtensionRequestWithoutOrigin(),
    corsHeaders: await testCORSHeaders()
  };
  
  logHeader('Test Summary');
  const passed = Object.values(results).filter(Boolean).length;
  const total = Object.keys(results).length;
  
  Object.entries(results).forEach(([test, result]) => {
    const status = result ? 'PASS' : 'FAIL';
    const color = result ? 'green' : 'red';
    log(`${result ? '✅' : '❌'} ${test}: ${status}`, color);
  });
  
  log(`\nOverall Result: ${passed}/${total} tests passed`, passed === total ? 'green' : 'red');
  
  // Special analysis for Origin header test
  if (results.extensionRequestWithOrigin && !results.extensionRequestWithoutOrigin) {
    log('\n🎯 ORIGIN HEADER FIX CONFIRMED!', 'green');
    log('   The Origin header resolved the CORS issue.', 'green');
  } else if (!results.extensionRequestWithOrigin && !results.extensionRequestWithoutOrigin) {
    log('\n⚠️  Origin header did not resolve the issue.', 'yellow');
    log('   Server-side CORS configuration is still required.', 'yellow');
  } else if (results.extensionRequestWithOrigin && results.extensionRequestWithoutOrigin) {
    log('\nℹ️  Both requests work - Origin header not the issue.', 'blue');
  }
  
  if (passed === total) {
    log('\n🎉 All tests passed! The remote Ollama server should work with the extension.', 'green');
  } else {
    log('\n⚠️  Some tests failed. Check the server configuration and CORS headers.', 'yellow');
    log('   Refer to the CORS_CSPIssue.md document for troubleshooting steps.', 'yellow');
  }
  
  return results;
}

// Run tests if this script is executed directly
if (require.main === module) {
  runAllTests().catch(err => {
    log(`\n❌ Test suite failed with error: ${err.message}`, 'red');
    process.exit(1);
  });
}

module.exports = { 
  runAllTests, 
  testBasicConnectivity, 
  testCORSPreflight, 
  testExtensionRequestWithOrigin,
  testExtensionRequestWithoutOrigin,
  testCORSHeaders 
}; 
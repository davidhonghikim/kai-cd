import React from 'react';
import styles from '@/styles/components/ChatInput.module.css';
import Button from './common/Button';

interface ChatInputProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  isLoading: boolean;
  onSendMessage: () => void;
  onStopGeneration: () => void;
}

const ChatInput: React.FC<ChatInputProps> = ({
  prompt,
  setPrompt,
  isLoading,
  onSendMessage,
  onStopGeneration,
}) => {
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSendMessage();
    }
  };

  return (
    <div className={styles.inputArea}>
      <textarea
        className={styles.promptInput}
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder="Type your message here..."
        rows={3}
        disabled={isLoading}
      />
      {isLoading ? (
        <Button onClick={onStopGeneration} variant="danger">
          Stop
        </Button>
      ) : (
        <Button onClick={onSendMessage} disabled={!prompt.trim()}>
          Send
        </Button>
      )}
    </div>
  );
};

export default ChatInput; 
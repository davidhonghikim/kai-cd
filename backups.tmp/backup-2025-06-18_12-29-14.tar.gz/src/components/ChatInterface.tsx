import React, { useState, useEffect, useRef } from 'react';
import { Service, LLMModel } from '@/types';
import { sendMessage } from '@/utils/chrome';
import styles from '@/styles/components/ChatInterface.module.css';
import { v4 as uuidv4 } from 'uuid';
import { useChatSession } from '@/hooks/useChatSession';
import type { ChatMessage } from '@/types';
import ChatMessageComponent from './ChatMessage';
import SessionList from './SessionList';
import ChatInput from './ChatInput';
import MessageList from './MessageList';
import Button from './common/Button';

interface ChatInterfaceProps {
  service: Service;
  generationOptions?: {
    temperature: number;
    maxTokens: number;
    tools: {
      webSearch: boolean;
      codeInterpreter: boolean;
      fileUpload: boolean;
    };
  };
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ service, generationOptions }) => {
  const [models, setModels] = useState<LLMModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [sendOnlyPrompt, setSendOnlyPrompt] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [modelsLoading, setModelsLoading] = useState(true);
  const [modelsError, setModelsError] = useState<string | null>(null);
  
  const {
    sessions,
    messages,
    setMessages,
    newChat,
    deleteSession,
    selectSession,
    currentSessionId,
  } = useChatSession(service.id);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const fetchModels = async () => {
      setModelsLoading(true);
      setModelsError(null);
      if (service) {
        try {
          console.log('[ChatInterface] Fetching models for service:', service.id, service.name);
          const fetchedModels = await sendMessage<LLMModel[]>('getModels', { serviceId: service.id });
          console.log('[ChatInterface] Received models:', fetchedModels);
          setModels(fetchedModels || []);
          
          // Check for saved model first
          const key = `lastModel_${service.id}`;
          const savedModel = localStorage.getItem(key);
          console.log('[ChatInterface] Saved model from localStorage:', savedModel);
          
          if (savedModel && fetchedModels?.some(model => model.id === savedModel)) {
            console.log('[ChatInterface] Using saved model:', savedModel);
            setSelectedModel(savedModel);
          } else if (fetchedModels && fetchedModels.length > 0) {
            console.log('[ChatInterface] No saved model found, using first model:', fetchedModels[0].id);
            setSelectedModel(fetchedModels[0].id);
          } else {
            console.log('[ChatInterface] No models available');
            setSelectedModel('');
          }
        } catch (error) {
          console.error('[ChatInterface] Error fetching models:', error);
          setModelsError("Failed to fetch models");
          setModels([]);
        } finally {
          setModelsLoading(false);
        }
      }
    };
    fetchModels();
  }, [service]);

  const handleModelChange = (modelId: string) => {
    console.log('[ChatInterface] Model changed to:', modelId);
    setSelectedModel(modelId);
    if (service) {
      const key = `lastModel_${service.id}`;
      localStorage.setItem(key, modelId);
      console.log('[ChatInterface] Saved model to localStorage:', key, modelId);
      // Insert a system message noting the model switch
      const newMessages = [
        ...messages,
        {
          id: uuidv4(),
          role: 'system' as const,
          content: `Model switched to: ${modelId}`,
          timestamp: Date.now()
        }
      ];
      setMessages(newMessages);
    }
  };

  const handleNewChat = () => {
    newChat();
  };

  const handleStopGeneration = async () => {
    try {
      await sendMessage('abortRequest', { serviceId: service.id });
      setIsLoading(false);
    } catch (error) {
      // Do not log or append any error if abort fails
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!prompt.trim() || isLoading) return;
    
    setIsLoading(true);
    
    const newMessage: ChatMessage = {
      id: uuidv4(),
      role: 'user',
      content: prompt,
      timestamp: Date.now()
    };
    
    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages); // This now saves the session
    setPrompt('');
    
    try {
      const toSend = sendOnlyPrompt ? [newMessage] : updatedMessages;
      
      const responseMessage = await sendMessage<ChatMessage>('streamMessage', {
        serviceId: service.id,
        messages: toSend,
        model: selectedModel,
        options: generationOptions
      });
      
      // The streaming response will be handled by a listener in a different part of the app,
      // which will then update the storage, triggering the `onChanged` in our hook.
      // For now, we optimistically add the user message and the backend will add the assistant message.
      // To get the final message, we need to handle the full response from the background script
      
      // Let's assume the background script returns the final assistant message.
      if (responseMessage) {
        const finalMessages = [...updatedMessages, responseMessage];
        setMessages(finalMessages);
      }

    } catch (error) {
      console.error('Error sending message:', error);
      let displayMessage = 'An unknown error occurred.';
      let isCancelled = false;
      if (error instanceof Error) {
        if (error.message.includes('403')) {
          displayMessage = 'Access Denied (Error 403). Please check if an API key is required and correctly configured for this service in the settings.';
        } else if (error.message.includes('cancelled') || error.message.includes('abort')) {
          isCancelled = true;
        } else {
          displayMessage = `Error: ${error.message}`;
        }
      }

      if (!isCancelled) {
        const errorResponseMessage: ChatMessage = {
          id: uuidv4(),
          role: 'assistant',
          content: displayMessage,
          timestamp: Date.now(),
          isError: true
        };
        const finalMessages = [...updatedMessages, errorResponseMessage];
        setMessages(finalMessages);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleEditMessage = (messageId: string, newContent: string) => {
    const updated = messages.map(m => m.id === messageId ? { ...m, content: newContent } : m);
    setMessages(updated);
  };

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
      .then(() => {
        // Add copy feedback
        const notification = document.createElement('div');
        notification.textContent = 'Copied to clipboard!';
        notification.style.cssText = `
          position: fixed;
          top: 20px;
          right: 20px;
          background: var(--accent-color);
          color: white;
          padding: 8px 16px;
          border-radius: 4px;
          z-index: 10000;
          font-size: 14px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
          document.body.removeChild(notification);
        }, 2000);
      })
      .catch(err => console.error('Failed to copy text: ', err));
  };

  const handleContinueResponse = async (messageId: string) => {
    // This logic needs to be adapted for the new hook
    console.log('Continue response for:', messageId);
  };

  const handleRegenerateResponse = async (messageId: string) => {
    // This logic needs to be adapted for the new hook
    console.log('Regenerate response for:', messageId);
  };

  const handleRateResponse = (messageId: string, rating: 'good' | 'bad') => {
    console.log(`Rated message ${messageId} as ${rating}`);
    // This can be stored in the message object
  };

  const handleGenerateImage = (prompt: string) => {
    console.log(`Generate image for: ${prompt}`);
  };

  const handleReadAloud = (content: string) => {
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(content);
    speechSynthesis.speak(utterance);
  };

  const handleDeleteMessage = (messageId: string) => {
    const updated = messages.filter(m => m.id !== messageId);
    setMessages(updated);
  };

  const handleSessionSelect = (sessionId: string) => {
    selectSession(sessionId);
  };

  const handleSessionDelete = async (sessionId: string) => {
    if (window.confirm('Are you sure you want to delete this session?')) {
      deleteSession(sessionId);
    }
  };

  return (
    <div className={styles.chatContainer}>
      {/* Sidebar with session history */}
      <div className={styles.sidebar}>
        <Button onClick={handleNewChat} variant="secondary">New Chat</Button>
        <SessionList
          sessions={sessions}
          currentSessionId={currentSessionId}
          onSessionSelect={handleSessionSelect}
          onSessionDelete={handleSessionDelete}
        />
      </div>

      {/* Main chat area */}
      <div className={styles.mainContent}>
        {/* Model selector and controls */}
        <div className={styles.chatHeader}>
          <div className={styles.modelSelector}>
            {modelsLoading ? (
              <span className={styles.modelLoading}>Loading models...</span>
            ) : modelsError ? (
              <span className={styles.modelError}>{modelsError}</span>
            ) : (
              <>
                <select
                  className={styles.modelSelect}
                  value={selectedModel}
                  onChange={(e) => handleModelChange(e.target.value)}
                >
                  {models.map((model) => (
                    <option key={model.id} value={model.id}>
                      {model.name}
                    </option>
                  ))}
                </select>
                {selectedModel && (
                  <span className={styles.currentModelLabel}>
                    Model: <b>{selectedModel}</b>
                  </span>
                )}
              </>
            )}
          </div>
        </div>

        {/* Messages area */}
        <div className={styles.messagesContainer}>
          {messages.length === 0 ? (
            <div className={styles.welcomeMessage}>
              <div className={styles.welcomeIcon}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <h2 className={styles.welcomeTitle}>Welcome to {service.name}</h2>
              <p className={styles.welcomeText}>
                Start a conversation with your AI assistant. You can ask questions, get help with tasks, or just chat.
              </p>
            </div>
          ) : (
            <div className={styles.messagesList}>
              {messages.map((msg, index) => (
                <ChatMessageComponent
                  key={msg.id || index}
                  message={msg}
                  onEdit={handleEditMessage}
                  onCopy={handleCopyMessage}
                  onContinue={handleContinueResponse}
                  onRegenerate={handleRegenerateResponse}
                  onRate={handleRateResponse}
                  onGenerateImage={handleGenerateImage}
                  onReadAloud={handleReadAloud}
                  onDelete={handleDeleteMessage}
                  showActions={true}
                  isLastMessage={msg.role === 'assistant' && index === messages.length - 1}
                />
              ))}
              
              {isLoading && (
                <div className={styles.loadingMessage}>
                  <div className={styles.loadingIndicator}>
                    <div className={styles.loadingDots}>
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    <span>Assistant is typing...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <MessageList
          messages={messages}
          isLoading={isLoading}
          onEdit={handleEditMessage}
          onCopy={handleCopyMessage}
          onContinue={handleContinueResponse}
          onRegenerate={handleRegenerateResponse}
          onRate={handleRateResponse}
          onGenerateImage={handleGenerateImage}
          onReadAloud={handleReadAloud}
          onDelete={handleDeleteMessage}
          onStopGeneration={handleStopGeneration}
        />

        <ChatInput
          prompt={prompt}
          setPrompt={setPrompt}
          isLoading={isLoading}
          onSendMessage={handleSendMessage}
          onStopGeneration={handleStopGeneration}
        />
      </div>
    </div>
  );
};

export default ChatInterface;
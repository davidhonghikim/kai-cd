import React, { useRef, useEffect } from 'react';
import { ChatMessage } from '@/types';
import ChatMessageComponent from './ChatMessage';
import styles from '@/styles/components/MessageList.module.css';
import Button from './common/Button';

interface MessageListProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onEdit: (messageId: string, newContent: string) => void;
  onCopy: (content: string) => void;
  onContinue: (messageId: string) => void;
  onRegenerate: (messageId: string) => void;
  onRate: (messageId: string, rating: 'good' | 'bad') => void;
  onGenerateImage: (prompt: string) => void;
  onReadAloud: (content: string) => void;
  onDelete: (messageId: string) => void;
  onStopGeneration: () => void;
}

const MessageList: React.FC<MessageListProps> = ({
  messages,
  isLoading,
  onEdit,
  onCopy,
  onContinue,
  onRegenerate,
  onRate,
  onGenerateImage,
  onReadAloud,
  onDelete,
  onStopGeneration,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className={styles.messagesList}>
      {messages.map((msg, index) => (
        <ChatMessageComponent
          key={msg.id || index}
          message={msg}
          onEdit={onEdit}
          onCopy={onCopy}
          onContinue={onContinue}
          onRegenerate={onRegenerate}
          onRate={onRate}
          onGenerateImage={onGenerateImage}
          onReadAloud={onReadAloud}
          onDelete={onDelete}
        />
      ))}
      {isLoading && (
        <div className={styles.loadingIndicator}>
          <span>Thinking...</span>
          <Button onClick={onStopGeneration} variant="secondary" size="small">
            Stop
          </Button>
        </div>
      )}
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList; 
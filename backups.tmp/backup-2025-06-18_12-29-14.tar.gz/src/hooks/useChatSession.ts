import { useState, useEffect, useCallback } from 'react';
import { storageManager } from '@/storage/storageManager';
import { ChatSession, ChatMessage } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { generateSessionTitle, sortSessionsByDate, hasValidContent } from '@/utils/chatUtils';

const SESSIONS_KEY_PREFIX = 'chatSessions_';
const CURRENT_SESSION_ID_KEY_PREFIX = 'currentSessionId_';

export function useChatSession(serviceId: string) {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const getSessionsKey = useCallback(() => `${SESSIONS_KEY_PREFIX}${serviceId}`, [serviceId]);
  const getCurrentSessionIdKey = useCallback(() => `${CURRENT_SESSION_ID_KEY_PREFIX}${serviceId}`, [serviceId]);

  // Load initial data from storage
  useEffect(() => {
    const loadData = async () => {
      if (!serviceId) return;

      const allSessions = await storageManager.get<ChatSession[]>(getSessionsKey(), []);
      const validSessions = allSessions.filter(hasValidContent);
      const sorted = sortSessionsByDate(validSessions);
      setSessions(sorted);

      const sessionId = await storageManager.get<string | null>(getCurrentSessionIdKey(), null);
      setCurrentSessionId(sessionId);

      if (sessionId) {
        const currentSession = sorted.find(s => s.id === sessionId);
        setMessages(currentSession?.messages || []);
      } else {
        setMessages([]);
      }
    };
    loadData();
  }, [serviceId, getSessionsKey, getCurrentSessionIdKey]);

  // Listen for storage changes to sync state
  useEffect(() => {
    const unsubscribe = storageManager.onChanged(changes => {
      const sessionsKey = getSessionsKey();
      const currentIdKey = getCurrentSessionIdKey();

      if (changes[sessionsKey]) {
        const newSessions = (changes[sessionsKey].newValue || []).filter(hasValidContent);
        setSessions(sortSessionsByDate(newSessions));
      }

      if (changes[currentIdKey]) {
        const newId = changes[currentIdKey].newValue || null;
        setCurrentSessionId(newId);
        const currentSession = sessions.find(s => s.id === newId);
        setMessages(currentSession?.messages || []);
      }
    });

    return () => unsubscribe();
  }, [getSessionsKey, getCurrentSessionIdKey, sessions]);

  const saveMessages = useCallback(async (newMessages: ChatMessage[]) => {
    if (!serviceId) return;

    let sessionId = currentSessionId;
    if (!sessionId) {
      sessionId = uuidv4();
      setCurrentSessionId(sessionId);
      await storageManager.set(getCurrentSessionIdKey(), sessionId);
    }

    setMessages(newMessages);

    const updatedSession: ChatSession = {
      id: sessionId,
      title: generateSessionTitle(newMessages),
      messages: newMessages,
      createdAt: sessions.find(s => s.id === sessionId)?.createdAt || Date.now(),
      updatedAt: Date.now(),
    };

    const allSessions = await storageManager.get<ChatSession[]>(getSessionsKey(), []);
    const sessionIndex = allSessions.findIndex(s => s.id === sessionId);

    if (sessionIndex > -1) {
      allSessions[sessionIndex] = updatedSession;
    } else {
      allSessions.push(updatedSession);
    }

    await storageManager.set(getSessionsKey(), allSessions);
    setSessions(sortSessionsByDate(allSessions.filter(hasValidContent)));

  }, [currentSessionId, serviceId, sessions, getSessionsKey, getCurrentSessionIdKey]);

  const newChat = useCallback(async () => {
    setCurrentSessionId(null);
    setMessages([]);
    await storageManager.remove(getCurrentSessionIdKey());
  }, [getCurrentSessionIdKey]);

  const deleteSession = useCallback(async (sessionId: string) => {
    const allSessions = await storageManager.get<ChatSession[]>(getSessionsKey(), []);
    const filtered = allSessions.filter(s => s.id !== sessionId);
    await storageManager.set(getSessionsKey(), filtered);
    setSessions(sortSessionsByDate(filtered.filter(hasValidContent)));
    if (currentSessionId === sessionId) {
      await newChat();
    }
  }, [getSessionsKey, currentSessionId, newChat]);
  
  const selectSession = useCallback(async (sessionId: string) => {
    setCurrentSessionId(sessionId);
    await storageManager.set(getCurrentSessionIdKey(), sessionId);
    const session = sessions.find(s => s.id === sessionId);
    setMessages(session?.messages || []);
  }, [getCurrentSessionIdKey, sessions]);


  return {
    sessions,
    currentSessionId,
    messages,
    setMessages: saveMessages,
    newChat,
    deleteSession,
    selectSession,
  };
} 
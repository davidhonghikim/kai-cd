import React, { useEffect, useState } from 'react';
import { SETTINGS_SCHEMA } from '../../../config/settingsSchema';
import { storageManager } from '../../../storage/storageManager';
import { SETTINGS_KEY } from '../../../utils/settingsIO';

const uiSettings = SETTINGS_SCHEMA.filter(s => s.section === 'UI');

const UISettingsSection: React.FC = () => {
  const [values, setValues] = useState<Record<string, any>>({});

  useEffect(() => {
    storageManager.get(SETTINGS_KEY, {}).then(stored => {
      setValues(stored || {});
    });
  }, []);

  const handleChange = (key: string, value: any) => {
    const newValues = { ...values, [key]: value };
    setValues(newValues);
    storageManager.set(SETTINGS_KEY, newValues);
  };

  return (
    <div>
      <h2>UI Settings</h2>
      {uiSettings.map(setting => (
        <div key={setting.key} style={{ marginBottom: 16 }}>
          <label><b>{setting.label}</b></label>
          <div>{setting.description}</div>
          {setting.type === 'select' && setting.options && (
            <select value={values[setting.key] ?? setting.default} onChange={e => handleChange(setting.key, e.target.value)}>
              {setting.options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          )}
          {setting.type === 'string' && (
            <input type="text" value={values[setting.key] ?? setting.default} onChange={e => handleChange(setting.key, e.target.value)} />
          )}
        </div>
      ))}
    </div>
  );
};
export default UISettingsSection; 
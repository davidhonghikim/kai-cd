import React, { useEffect, useState } from 'react';
import { SETTINGS_SCHEMA } from '../../../config/settingsSchema';
import { storageManager } from '../../../storage/storageManager';
import { SETTINGS_KEY } from '../../../utils/settingsIO';

const advancedSettings = SETTINGS_SCHEMA.filter(s => s.section === 'Advanced');

const AdvancedSettingsSection: React.FC = () => {
  const [values, setValues] = useState<Record<string, any>>({});

  useEffect(() => {
    storageManager.get(SETTINGS_KEY, {}).then(stored => {
      setValues(stored || {});
    });
  }, []);

  const handleChange = (key: string, value: any) => {
    const newValues = { ...values, [key]: value };
    setValues(newValues);
    storageManager.set(SETTINGS_KEY, newValues);
  };

  return (
    <div>
      <h2>Advanced Settings</h2>
      {advancedSettings.map(setting => (
        <div key={setting.key} style={{ marginBottom: 16 }}>
          <label><b>{setting.label}</b></label>
          <div>{setting.description}</div>
          {setting.type === 'boolean' && (
            <input type="checkbox" checked={!!(values[setting.key] ?? setting.default)} onChange={e => handleChange(setting.key, e.target.checked)} />
          )}
        </div>
      ))}
    </div>
  );
};
export default AdvancedSettingsSection; 
import React, { Suspense, useState } from 'react';
import { SETTINGS_SCHEMA } from '../../config/settingsSchema';
import { exportAllSettingsAndServers, importAllSettingsAndServers } from '../../utils/settingsIO';

const sectionNames = Array.from(new Set(SETTINGS_SCHEMA.map(s => s.section)));

const sectionComponents: Record<string, React.LazyExoticComponent<any>> = {};
sectionNames.forEach(section => {
  sectionComponents[section] = React.lazy(() => import(`./sections/${section}SettingsSection.tsx`));
});

const AdvancedSettingsModal: React.FC = () => {
  const [activeSection, setActiveSection] = useState(sectionNames[0]);

  const handleImport = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.onchange = async (e: any) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        await importAllSettingsAndServers(file);
        alert('Settings and servers imported successfully!');
      } catch (err) {
        alert('Import failed: ' + (err instanceof Error ? err.message : err));
      }
    };
    input.click();
  };
  const handleExport = () => {
    exportAllSettingsAndServers();
  };

  const SectionComponent = sectionComponents[activeSection];

  return (
    <div className="advanced-settings-modal">
      <div className="settings-sidebar">
        {sectionNames.map(section => (
          <button key={section} onClick={() => setActiveSection(section)}>{section}</button>
        ))}
        <hr />
        <button onClick={handleImport}>Import Settings</button>
        <button onClick={handleExport}>Export Settings</button>
      </div>
      <div className="settings-content">
        <Suspense fallback={<div>Loading...</div>}>
          {SectionComponent ? <SectionComponent /> : <div>No section selected</div>}
        </Suspense>
      </div>
    </div>
  );
};

export default AdvancedSettingsModal; 
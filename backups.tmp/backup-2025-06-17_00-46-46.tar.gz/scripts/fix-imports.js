const fs = require('fs');
const path = require('path');

// Define the project root directory
const projectRoot = path.resolve(__dirname, '..');
const srcDir = path.join(projectRoot, 'src');

// Map of old import paths to new ones
const pathMappings = {
  // Update CSS imports
  "from '../../styles/global.css'": "from '../../../styles/global.css'",
  "from '../../styles/vendors/tab.css'": "from '../../../styles/vendors/tab.css'",
  "from '../../styles/vendors/options.css'": "from '../../../styles/vendors/options.css'",
  "from '../../styles/vendors/popup.css'": "from '../../../styles/vendors/popup.css'",
  
  // Update module CSS imports
  "from '../../styles/components/tab/ServiceTab.module.css'": "from '../../../styles/components/tab/ServiceTab.module.css'",
  "from '../../styles/components/sidepanel/SidePanel.module.css'": "from '../../../styles/components/sidepanel/SidePanel.module.css'",
  "from '../../styles/components/sidepanel/ChatMessage.module.css'": "from '../../../styles/components/sidepanel/ChatMessage.module.css'",
  "from '../../styles/components/sidepanel/A1111View.module.css'": "from '../../../styles/components/sidepanel/A1111View.module.css'",
  "from '../../styles/components/sidepanel/ComfyUIView.module.css'": "from '../../../styles/components/sidepanel/ComfyUIView.module.css'",
  "from '../../styles/components/popup/AdvancedSettings.module.css'": "from '../../../styles/components/popup/AdvancedSettings.module.css'",
  "from '../../styles/components/popup/App.module.css'": "from '../../../styles/components/popup/App.module.css'",
  "from '../../styles/components/popup/ArtifactGallery.module.css'": "from '../../../styles/components/popup/ArtifactGallery.module.css'",
  "from '../../styles/components/popup/HistoryViewer.module.css'": "from '../../../styles/components/popup/HistoryViewer.module.css'",
  "from '../../styles/components/popup/Message.module.css'": "from '../../../styles/components/popup/Message.module.css'",
  "from '../../styles/components/popup/PromptManager.module.css'": "from '../../../styles/components/popup/PromptManager.module.css'",
  "from '../../styles/components/options/Options.module.css'": "from '../../../styles/components/options/Options.module.css'",
  
  // Update component imports if needed
  // "from '../../../components/SomeComponent'": "from '../../components/SomeComponent'",
};

// Function to recursively find all TypeScript and JavaScript files
function findFiles(dir, fileList = []) {
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      // Skip node_modules and other non-source directories
      if (!['node_modules', '.git', '.vscode', 'dist', 'build'].includes(file)) {
        findFiles(filePath, fileList);
      }
    } else if (['.ts', '.tsx', '.js', '.jsx'].includes(path.extname(file))) {
      fileList.push(filePath);
    }
  });
  
  return fileList;
}

// Function to update imports in a file
function updateImports(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  let updated = false;
  
  // Apply path mappings
  Object.entries(pathMappings).forEach(([oldPath, newPath]) => {
    if (content.includes(oldPath)) {
      content = content.replace(new RegExp(oldPath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), newPath);
      updated = true;
    }
  });
  
  // Fix relative path depth if needed
  const relativePath = path.relative(path.dirname(filePath), srcDir);
  const pathDepth = relativePath.split(path.sep).filter(Boolean).length;
  
  // This is a simple heuristic - in a real project, you might need more sophisticated logic
  if (pathDepth > 0) {
    // Example: Update '../../components' to '../../../components' if needed
    // This is just an example - adjust based on your project structure
    const oldPath = "from '../../";
    const newPath = `from '${'../'.repeat(pathDepth)}`;
    
    if (content.includes(oldPath)) {
      content = content.replace(new RegExp(oldPath, 'g'), newPath);
      updated = true;
    }
  }
  
  if (updated) {
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Updated imports in ${path.relative(projectRoot, filePath)}`);
  }
}

// Main function
function main() {
  console.log('Scanning for files...');
  const files = findFiles(srcDir);
  console.log(`Found ${files.length} files to check`);
  
  files.forEach(file => {
    updateImports(file);
  });
  
  console.log('Import updates completed!');
}

// Run the script
main();

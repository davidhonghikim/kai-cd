import React, { useState, useEffect } from 'react';
import { Service, ServiceFormData } from '@/types';
import { sendMessage } from '@/utils/chrome';
import styles from './ServerFormModal.module.css';

interface ServerFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (server: Service) => void;
  server?: Service | null;
}

const ServerFormModal: React.FC<ServerFormModalProps> = ({ isOpen, onClose, onSubmit, server }) => {
  const [formData, setFormData] = useState<ServiceFormData>({
    name: '',
    type: 'a1111',
    url: '',
    apiKey: '',
    options: {}
  });
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    if (server) {
      setFormData({
        name: server.name,
        type: server.type,
        url: server.url,
        apiKey: server.apiKey || '',
        options: server.options || {}
      });
    }
  }, [server]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Reset verification when form changes
    setIsVerified(false);
    setVerificationError(null);
  };

  const handleVerify = async () => {
    if (!formData.name || !formData.url || !formData.type) {
      setVerificationError('Please fill in all required fields');
      return;
    }

    setIsVerifying(true);
    setVerificationError(null);

    try {
      const response = await sendMessage('checkServerStatus', { 
        server: {
          ...formData,
          id: server?.id || 'temp',
          status: 'unknown'
        }
      });

      if (response.success) {
        setIsVerified(true);
        setVerificationError(null);
      } else {
        throw new Error(response.error || 'Failed to connect to server');
      }
    } catch (error) {
      setVerificationError(error instanceof Error ? error.message : 'Failed to verify connection');
      setIsVerified(false);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isVerified) {
      setVerificationError('Please verify the connection first');
      return;
    }
    onSubmit({
      ...formData,
      id: server?.id || Date.now().toString(),
      status: 'unknown',
      createdAt: server?.createdAt || Date.now(),
      updatedAt: Date.now()
    });
  };

  if (!isOpen) return null;

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.modal}>
        <h2>{server ? 'Edit Server' : 'Add New Server'}</h2>
        <form onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="type">Type</label>
            <select
              id="type"
              name="type"
              value={formData.type}
              onChange={handleChange}
              required
            >
              <option value="openai">OpenAI</option>
              <option value="anthropic">Anthropic</option>
              <option value="a1111">A1111</option>
              <option value="comfyui">ComfyUI</option>
              <option value="openwebui">OpenWebUI</option>
              <option value="ollama">Ollama</option>
              <option value="local">Local</option>
              <option value="custom">Custom</option>
            </select>
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="url">URL</label>
            <input
              type="url"
              id="url"
              name="url"
              value={formData.url}
              onChange={handleChange}
              required
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="apiKey">API Key (if required)</label>
            <input
              type="password"
              id="apiKey"
              name="apiKey"
              value={formData.apiKey}
              onChange={handleChange}
            />
          </div>

          {verificationError && (
            <div className={styles.error}>
              {verificationError}
            </div>
          )}

          {isVerified && (
            <div className={styles.success}>
              Connection verified successfully!
            </div>
          )}

          <div className={styles.buttonGroup}>
            <button
              type="button"
              onClick={handleVerify}
              disabled={isVerifying}
              className={styles.verifyButton}
            >
              {isVerifying ? 'Verifying...' : 'Verify Connection'}
            </button>
            <button
              type="submit"
              disabled={!isVerified}
              className={styles.submitButton}
            >
              {server ? 'Save Changes' : 'Add Server'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className={styles.cancelButton}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ServerFormModal; 
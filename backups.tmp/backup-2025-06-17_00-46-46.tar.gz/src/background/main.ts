/* global console */
import { storageManager } from '../storage/storageManager';
import { DEFAULT_SERVICES } from '../config/constants';
import { handlers, Action } from './handlers';
import { setupKeepAliveListener } from '@/utils/keepAlive';

// Keep the service worker alive
setupKeepAliveListener();

// Initialize default services on installation
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    console.log('ChatDemon first install, setting up default services...');
    const existingServices = await storageManager.get('services', []);

    if (existingServices.length === 0) {
      const servicesWithIds = DEFAULT_SERVICES.map((service, index) => ({
        ...service,
        id: `default_${index}_${Date.now()}`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        isActive: service.url.includes('localhost'),
      }));

      await storageManager.set('services', servicesWithIds);
      console.log('Default services created.');
    }
  }
});

// Function to check and initialize services if none exist
const ensureServicesExist = async () => {
  const existingServices = await storageManager.get('services', []);

  // If the stored services are empty or incomplete, reset to the default list.
  if (existingServices.length < DEFAULT_SERVICES.length) {
    console.log('Services are missing or empty. Resetting to default services...');
    const servicesWithIds = DEFAULT_SERVICES.map((service, index) => ({
      ...service,
      id: `default_${index}_${Date.now()}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isActive: service.url.includes('localhost'),
    }));

    await storageManager.set('services', servicesWithIds);
    console.log('Default services have been reset.');
  }
};

// Run the check on browser startup
chrome.runtime.onStartup.addListener(ensureServicesExist);

// Also run it once when the script is first loaded
ensureServicesExist();

// Main message listener for all incoming requests from the UI
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const { action, payload } = request;

  if (!action || !handlers[action as Action]) {
    console.error(`No handler found for action: ${action}`);
    sendResponse({
      success: false,
      error: `No handler found for action: ${action}`,
    });
    return true; // Keep the channel open for the response
  }

  (async () => {
    try {
      const handler = handlers[action as Action];
      // @ts-ignore
      const result = await handler(payload, sender);
      sendResponse({ success: true, data: result });
    } catch (error) {
      console.error(`Error handling action: ${action}`, error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      sendResponse({ success: false, error: errorMessage });
    }
  })();

  return true; // Indicates that the response is sent asynchronously
});

console.log('Background script initialized.');
/* global console */
import type { Service, RequestHandler } from '../../config/types';
import { connectorManager } from '../connectors';
import { storageManager } from '../../storage/storageManager';
import { SERVICE_TYPE_TO_CATEGORY, SERVICE_TYPES, HEALTH_CHECK_PATHS } from '../../config/constants';

export async function getServices(): Promise<Service[]> {
  return storageManager.get<Service[]>('services', []);
}

export async function addService(payload: Partial<Service>): Promise<Service> {
  const services = await storageManager.get<Service[]>('services', []);
  const serviceType = payload.type || SERVICE_TYPES.OLLAMA;
  const newService: Service = {
    id: `srv_${Date.now()}`,
    name: payload.name || 'New Service',
    type: serviceType,
    url: payload.url || '',
    apiKey: payload.apiKey,
    model: payload.model,
    category: payload.category || SERVICE_TYPE_TO_CATEGORY[serviceType],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: payload.isActive,
  };

  const updatedServices = [...services, newService];
  await storageManager.set('services', updatedServices);
  return newService;
}

export async function updateService(payload: Service): Promise<Service> {
  const services = await storageManager.get<Service[]>('services', []);
  const index = services.findIndex((s) => s.id === payload.id);

  if (index === -1) {
    throw new Error('Service not found');
  }

  const updatedService: Service = {
    ...services[index],
    ...payload,
    updatedAt: Date.now(),
  };

  const updatedServices = [...services];
  updatedServices[index] = updatedService;

  // Get the connector and update it, instead of just removing it.
  const connector = await connectorManager.getConnector(updatedService);
  if (connector) {
    await connector.updateService(updatedService);
  }

  await storageManager.set('services', updatedServices);
  return updatedService;
}

export async function removeService(payload: { id: string }): Promise<Service[]> {
  const services = await storageManager.get<Service[]>('services', []);
  const updatedServices = services.filter((s) => s.id !== payload.id);

  connectorManager.removeConnector(payload.id);
  await storageManager.set('services', updatedServices);
  return updatedServices;
}

export async function setDefaultModel(payload: { serviceId: string; modelId: string }): Promise<Service> {
  const { serviceId, modelId } = payload;
  const services = await storageManager.get<Service[]>('services', []);
  const index = services.findIndex((s) => s.id === serviceId);

  if (index === -1) {
    throw new Error(`Service not found with id: ${serviceId}`);
  }

  const updatedService: Service = {
    ...services[index],
    model: modelId,
    updatedAt: Date.now(),
  };

  const updatedServices = [...services];
  updatedServices[index] = updatedService;

  await storageManager.set('services', updatedServices);
  return updatedService;
}

/**
 * Checks if a service is online and reachable.
 * It uses a fetch request with a timeout to prevent long hangs.
 * It will also check for a valid response (e.g., 200 OK).
 */
export async function checkStatus(payload: { serviceId: string }): Promise<{
  status: 'online' | 'offline' | 'error';
  message?: string;
  statusCode?: number;
}> {
  const services = await storageManager.get<Service[]>('services', []);
  const service = services.find((s) => s.id === payload.serviceId);

  if (!service || !service.url) {
    return { status: 'error', message: `Service not found or has no URL.` };
  }
  
  const healthCheckPath = HEALTH_CHECK_PATHS[service.type] || '';
  const healthCheckUrl = new URL(healthCheckPath, service.url).toString();

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000); // 5-second timeout

  try {
    const response = await fetch(healthCheckUrl, {
      method: 'GET', // Use GET for broader compatibility, HEAD is not always supported.
      signal: controller.signal,
      mode: 'cors',
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      return { status: 'online', statusCode: response.status };
    } else {
      return {
        status: 'offline',
        message: `Service returned non-OK status: ${response.status}`,
        statusCode: response.status,
      };
    }
  } catch (error) {
    clearTimeout(timeoutId);
    if (error instanceof Error && error.name === 'AbortError') {
      return { status: 'offline', message: 'Connection timed out after 5 seconds.' };
    }
    return { status: 'offline', message: 'Failed to connect. The server may be offline or unreachable.' };
  }
}

export const getModels = async (payload: { serviceId: string }) => {
  const { serviceId } = payload;
  if (!serviceId) throw new Error('Service ID is required to fetch models.');

  const services = await storageManager.get<Service[]>('services', []);
  const service = services.find(s => s.id === serviceId);

  if (!service) throw new Error(`Service with ID "${serviceId}" not found.`);

  // For now, only handle Ollama. This will be expanded.
  if (service.type !== SERVICE_TYPES.OLLAMA) {
    console.log(`Model fetching not supported for service type: ${service.type}`);
    return [];
  }

  try {
    // Ollama's API endpoint for listing models is /api/tags
    const url = new URL('/api/tags', service.url).toString();
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch models from ${service.name}. Status: ${response.status}`);
    }
    const data = await response.json();
    
    // The response has a "models" array with model objects
    return data.models.map((model: any) => ({
      id: model.name,
      name: model.name,
      details: model,
    }));
  } catch (error) {
    console.error(`Error fetching models for ${service.name}:`, error);
    throw error;
  }
};

/**
 * Exports selected services to a JSON file.
 */
export const exportServices: RequestHandler<{ serviceIds: string[] }, void> = async ({ serviceIds }) => {
  const allServices = await getServices();
  const servicesToExport = allServices.filter(s => serviceIds.includes(s.id));
  
  const content = JSON.stringify(servicesToExport, null, 2);
  const blob = new Blob([content], { type: 'application/json' });
  const url = self.URL.createObjectURL(blob);

  chrome.downloads.download({
    url: url,
    filename: `chatdemon-services-backup-${Date.now()}.json`,
    saveAs: true
  }, () => {
    self.URL.revokeObjectURL(url); // Clean up the object URL
  });
};

/**
 * Imports services from a JSON file, avoiding duplicates.
 */
export const importServices: RequestHandler<{ services: Service[] }, void> = async ({ services: servicesToImport }) => {
  const existingServices = await getServices();
  const existingUrls = new Set(existingServices.map(s => s.url));

  const newServices = servicesToImport.filter(s => !existingUrls.has(s.url));

  if (newServices.length > 0) {
    const updatedServices = [...existingServices, ...newServices];
    await storageManager.set('services', updatedServices);
  }
  
  console.log(`${newServices.length} new services imported. ${servicesToImport.length - newServices.length} duplicates were skipped.`);
};

/**
 * Updates the order of all services.
 */
export const updateServicesOrder: RequestHandler<{ orderedIds: string[] }, void> = async ({ orderedIds }) => {
  const allServices = await getServices();
  const serviceMap = new Map(allServices.map(s => [s.id, s]));
  const reorderedServices = orderedIds.map(id => serviceMap.get(id)).filter(Boolean) as Service[];
  
  await storageManager.set('services', reorderedServices);
};

export type ServiceType = 'openai' | 'anthropic' | 'custom' | 'a1111' | 'comfyui' | 'openwebui' | 'ollama' | 'local';
export type ServiceStatus = 'online' | 'offline' | 'checking' | 'unknown' | 'error';

export interface Service {
  id: string;
  name: string;
  type: ServiceType;
  url: string;
  apiKey?: string;
  status?: ServiceStatus;
  endpoints?: {
    chat?: string;
    completion?: string;
    embedding?: string;
  } | string[];
  options?: Record<string, any>;
  createdAt?: number;
  updatedAt?: number;
  isConnected?: boolean;
  isLoading?: boolean;
  error?: string;
}

export interface ServiceFormData {
  name: string;
  type: ServiceType;
  url: string;
  endpoints?: {
    chat?: string;
    completion?: string;
    embedding?: string;
  } | string[];
  status?: ServiceStatus;
  apiKey?: string;
  options?: Record<string, any>;
} 
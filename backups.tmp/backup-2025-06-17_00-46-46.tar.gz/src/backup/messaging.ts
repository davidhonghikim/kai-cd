// Minimal messaging utility for background/extension messaging
interface MessageResponse {
  success: boolean;
  status?: string;
  error?: string;
}

export async function sendMessage(action: string, data: any): Promise<MessageResponse> {
  try {
    // For now, we'll just simulate a response
    // In a real implementation, this would communicate with the backend
    if (action === 'checkServerStatus') {
      const { server } = data;
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulate random status
      const statuses = ['connected', 'disconnected', 'unknown'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      
      return {
        success: true,
        status: randomStatus
      };
    }
    
    return {
      success: false,
      error: 'Unknown action'
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
} 
import { Service, LLMModel, ChatMessage } from "@/config/types";
import { LLMConnector } from './LLMConnector';

// Define StreamChunk interface locally since it's not exported from types
export interface StreamChunk {
  content?: string;
  isComplete: boolean;
  error?: string;
  metadata?: Record<string, any>;
}

// OpenAI API response types
interface OpenAIModel {
  id: string;
  object: string;
  created: number;
  owned_by: string;
  root?: string;
  parent?: string;
  permission?: Array<{
    id: string;
    object: string;
    created: number;
    allow_create_engine: boolean;
    allow_sampling: boolean;
    allow_logprobs: boolean;
    allow_search_indices: boolean;
    allow_view: boolean;
    allow_fine_tuning: boolean;
    organization: string;
    group?: string;
    is_blocking: boolean;
  }>;
}

interface OpenAIChatCompletion {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: 'assistant' | 'user' | 'system' | 'function';
      content: string;
      function_call?: {
        name: string;
        arguments: string;
      };
    };
    finish_reason: 'stop' | 'length' | 'function_call' | 'content_filter' | null;
  }>;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

interface OpenAIEmbedding {
  object: 'embedding';
  index: number;
  embedding: number[];
}

interface OpenAIEmbeddingResponse {
  object: 'list';
  data: OpenAIEmbedding[];
  model: string;
  usage: {
    prompt_tokens: number;
    total_tokens: number;
  };
}

interface OpenAITokenizeResponse {
  tokens: number[];
}

interface OpenAIDetokenizeResponse {
  text: string;
}

/**
 * Connector for services that implement the OpenAI-compatible API
 */
export class OpenAICompatibleConnector extends LLMConnector {
  protected _service: Service;
  protected _isConnected: boolean = false;
  private defaultHeaders: Record<string, string> = {};
  protected abortController: AbortController | null = null;

  constructor(service: Service) {
    super(service);
    this._service = { ...service };
    this.defaultHeaders = this.getDefaultHeaders();
  }

  // Implement the abstract fetch method from BaseConnector
  protected async fetch<T>(
    url: string,
    options: RequestInit = {}
  ): Promise<{ data?: T; error?: string; response?: Response }> {
    try {
      this.abortController = new AbortController();
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...this.defaultHeaders,
          ...(options.headers || {})
        },
        signal: this.abortController.signal
      });

      if (!response.ok) {
        const errorText = await response.text().catch(() => 'Unknown error');
        throw new Error(`HTTP error! status: ${response.status}, ${errorText}`);
      }

      const data = await response.json().catch(() => ({}));
      return { data, response };
    } catch (error) {
      return {
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    } finally {
      this.abortController = null;
    }
  }

  /**
   * Connect to the service
   */
  public async connect(): Promise<boolean> {
    try {
      await this.getModels(); // Test connection by fetching models
      this._isConnected = true;
      return true;
    } catch (error) {
      console.error('Failed to connect to OpenAI-compatible service:', error);
      this._isConnected = false;
      return false;
    }
  }

  /**
   * Disconnect from the service
   */
  public async disconnect(): Promise<void> {
    this.cancelStream(); // Cancel any ongoing requests
    this._isConnected = false;
  }

  /**
   * Check if the service is connected
   */
  public isConnected(): boolean {
    return this._isConnected;
  }

  /**
   * Get the service category
   */
  public getCategory(): string {
    return 'OpenAI Compatible';
  }

  /**
   * Get the default headers for API requests
   */
  private getDefaultHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this._service.apiKey) {
      headers['Authorization'] = `Bearer ${this._service.apiKey}`;
    }

    return headers;
  }

  /**
   * Update headers when service configuration changes
   */
  public async updateService(service: Partial<Service>): Promise<void> {
    this._service = {
      ...this._service,
      ...service,
      id: this._service.id,
      type: service.type || this._service.type,
    };
    this.defaultHeaders = this.getDefaultHeaders();
    if (service.url || service.apiKey) {
      if (this._isConnected) {
        await this.disconnect();
        await this.connect();
      }
    }
  }

  /**
   * Check if the service is reachable and return status information
   */
  public async checkStatus() {
    try {
      const url = new URL('/v1/models', this._service.url).toString();
      const response = await this.fetch<{ data: OpenAIModel[] }>(url, {
        method: 'GET',
        headers: this.defaultHeaders
      });
      
      if (!response.data) {
        throw new Error('No data received from models endpoint');
      }
      
      const models = await this.getModels();
      
      // Return the service with updated models and model count
      return {
        isOnline: true,
        details: {
          ...this._service,
          models,
          modelCount: models.length
        }
      };
    } catch (error) {
      return {
        isOnline: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Get list of available models
   */
  public async getModels(): Promise<LLMModel[]> {
    const url = new URL('/v1/models', this._service.url).toString();
    const response = await this.fetch<{ data: OpenAIModel[] }>(url, {
      method: 'GET',
      headers: this.defaultHeaders
    });
    
    if (!response.data) {
      throw new Error('No data received from models endpoint');
    }
    
    return response.data.data.map(model => ({
      id: model.id,
      name: model.id,
      created: model.created,
      owned_by: model.owned_by,
      contextWindow: this.estimateContextWindow(model.id),
      parameters: this.estimateParameters(model.id)
    }));
  }

  /**
   * Estimate context window size based on model ID
   */
  private estimateContextWindow(modelId: string): number {
    // This is a rough estimate based on common model families
    const lowerModelId = modelId.toLowerCase();
    
    if (lowerModelId.includes('gpt-4-32k')) return 32768;
    if (lowerModelId.includes('gpt-4')) return 8192;
    if (lowerModelId.includes('gpt-3.5-turbo-16k')) return 16384;
    if (lowerModelId.includes('gpt-3.5-turbo')) return 4096;
    if (lowerModelId.includes('text-davinci-003')) return 4097;
    if (lowerModelId.includes('text-embedding-ada-002')) return 8191;
    
    // Default to a reasonable value
    return 2048;
  }
  
  /**
   * Estimate number of parameters based on model ID
   */
  private estimateParameters(modelId: string): number | undefined {
    // This is a rough estimate based on common model families
    const lowerModelId = modelId.toLowerCase();
    
    if (lowerModelId.includes('gpt-4-32k')) return 1.8 * 1e12; // 1.8T parameters
    if (lowerModelId.includes('gpt-4')) return 1.8 * 1e12; // 1.8T parameters
    if (lowerModelId.includes('gpt-3.5-turbo')) return 175 * 1e9; // 175B parameters
    if (lowerModelId.includes('davinci')) return 175 * 1e9; // 175B parameters
    if (lowerModelId.includes('curie')) return 6.7 * 1e9; // 6.7B parameters
    if (lowerModelId.includes('babbage')) return 1.3 * 1e9; // 1.3B parameters
    if (lowerModelId.includes('ada')) return 350 * 1e6; // 350M parameters
    
    return undefined;
  }

  /**
   * Send a chat message and get a response
   */
  public async chat(
    messages: Array<{
      role: 'user' | 'assistant' | 'system' | 'function';
      content: string;
      name?: string;
      function_call?: {
        name: string;
        arguments: string;
      };
    }>,
    model: string,
    options: {
      temperature?: number;
      maxTokens?: number;
      topP?: number;
      frequencyPenalty?: number;
      presencePenalty?: number;
      stop?: string[];
      stream?: boolean;
      onChunk?: (chunk: StreamChunk) => void;
    } = {}
  ): Promise<ChatMessage> {
    const { stream = false, onChunk, ...restOptions } = options;
    const url = new URL('/v1/chat/completions', this._service.url).toString();

    if (stream) {
      if (!onChunk) {
        throw new Error('onChunk is required for streaming');
      }
      return this.streamChatResponse(messages, model, restOptions, onChunk);
    }

    // Standard non-streaming request
    const response = await this.fetch<OpenAIChatCompletion>(url, {
      method: 'POST',
      headers: this.defaultHeaders,
      body: JSON.stringify({
        model,
        messages,
        temperature: restOptions.temperature,
        max_tokens: restOptions.maxTokens,
        top_p: restOptions.topP,
        frequency_penalty: restOptions.frequencyPenalty,
        presence_penalty: restOptions.presencePenalty,
        stop: restOptions.stop?.length ? restOptions.stop : undefined,
        stream: false,
      }),
    });

    if (!response.data) {
      throw new Error(response.error || 'Failed to get chat completion');
    }

    const choice = response.data.choices[0];
    if (!choice) {
      throw new Error('No response from model');
    }

    const responseMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      role: 'assistant',
      content: choice.message.content,
      timestamp: Date.now(),
    };
    return responseMessage;
  }

  private async streamChatResponse(
    messages: Array<{
      role: 'user' | 'assistant' | 'system' | 'function';
      content: string;
      name?: string;
      function_call?: {
        name: string;
        arguments: string;
      };
    }>,
    model: string,
    options: {
      temperature?: number;
      maxTokens?: number;
      topP?: number;
      frequencyPenalty?: number;
      presencePenalty?: number;
      stop?: string[];
    },
    onChunk?: (chunk: StreamChunk) => void
  ): Promise<ChatMessage> {
    const url = new URL('/v1/chat/completions', this._service.url).toString();
    
    // Create a new AbortController for this request
    this.abortController = new AbortController();
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: this.defaultHeaders,
        body: JSON.stringify({
          model,
          messages,
          temperature: options.temperature,
          max_tokens: options.maxTokens,
          top_p: options.topP,
          frequency_penalty: options.frequencyPenalty,
          presence_penalty: options.presencePenalty,
          stop: options.stop?.length ? options.stop : undefined,
          stream: true,
        }),
        signal: this.abortController.signal,
      });

      if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`API error: ${response.status} ${response.statusText}\n${errorBody}`);
      }

      if (!response.body) {
        throw new Error('No response body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let content = '';
      let isComplete = false;

      while (!isComplete) {
        const { done, value } = await reader.read();
        
        if (done) {
          isComplete = true;
          if (onChunk) {
            onChunk({ isComplete: true });
          }
          break;
        }

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n').filter(line => line.trim() !== '');

        for (const line of lines) {
          if (line === 'data: [DONE]') {
            isComplete = true;
            if (onChunk) {
              onChunk({ isComplete: true });
            }
            continue;
          }

          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6)); // Remove 'data: ' prefix
              
              if (data.choices?.[0]?.delta?.content) {
                const chunkContent = data.choices[0].delta.content;
                content += chunkContent;
                
                if (onChunk) {
                  onChunk({
                    content: chunkContent,
                    isComplete: false,
                    metadata: {
                      ...data,
                      choices: undefined, // Remove large data
                    },
                  });
                }
              }
              
              // Check if this is the final chunk
              if (data.choices?.[0]?.finish_reason) {
                isComplete = true;
                if (onChunk) {
                  onChunk({ isComplete: true });
                }
              }
            } catch (error) {
              console.error('Error parsing stream chunk:', error);
              if (onChunk) {
                onChunk({
                  isComplete: true,
                  error: error instanceof Error ? error.message : 'Error parsing stream',
                });
              }
              throw error;
            }
          }
        }
      }

      const responseMessage: ChatMessage = {
        id: `msg_${Date.now()}`,
        role: 'assistant',
        content,
        timestamp: Date.now(),
      };
      return responseMessage;
    } finally {
      this.abortController = null;
    }
  }

  /**
   * Cancel the current streaming request
   */
  public cancelStream(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }

  /**
   * Generate embeddings for a list of texts
   */
  public async embed(
    texts: string[],
    model: string = 'text-embedding-ada-002'
  ): Promise<number[][]> {
    const url = new URL('/v1/embeddings', this._service.url).toString();
    
    const response = await this.fetch<OpenAIEmbeddingResponse>(url, {
      method: 'POST',
      headers: this.defaultHeaders,
      body: JSON.stringify({
        input: texts.length === 1 ? texts[0] : texts,
        model,
      }),
    });

    if (!response.data) {
      throw new Error(response.error || 'Failed to generate embeddings');
    }

    // Sort embeddings by index to ensure correct order
    return response.data.data
      .sort((a, b) => a.index - b.index)
      .map(item => item.embedding);
  }

  /**
   * Tokenize text
   */
  public async tokenize(text: string, model: string): Promise<number[]> {
    // Note: The standard OpenAI API doesn't have a direct tokenization endpoint
    // This is a best-effort implementation that might need to be adjusted
    // based on the specific API implementation
    const url = new URL('/v1/tokenize', this._service.url).toString();
    
    const response = await this.fetch<OpenAITokenizeResponse>(url, {
      method: 'POST',
      headers: this.defaultHeaders,
      body: JSON.stringify({
        text,
        model,
      }),
    });

    if (!response.data) {
      // Fallback to approximate tokenization if the endpoint is not available
      return this.approximateTokenization(text);
    }

    return response.data.tokens;
  }

  /**
   * Approximate tokenization when the API doesn't provide a tokenize endpoint
   */
  private approximateTokenization(text: string): number[] {
    // This is a very rough approximation
    // In a real implementation, you might want to use a proper tokenizer
    const tokens: number[] = [];
    for (let i = 0; i < text.length; i++) {
      tokens.push(text.charCodeAt(i));
    }
    return tokens;
  }

  /**
   * Detokenize tokens back to text
   */
  public async detokenize(tokens: number[], model: string): Promise<string> {
    // Note: The standard OpenAI API doesn't have a direct detokenization endpoint
    // This is a best-effort implementation that might need to be adjusted
    const url = new URL('/v1/detokenize', this._service.url).toString();
    
    const response = await this.fetch<OpenAIDetokenizeResponse>(url, {
      method: 'POST',
      headers: this.defaultHeaders,
      body: JSON.stringify({
        tokens,
        model,
      }),
    });

    if (!response.data) {
      // Fallback to approximate detokenization if the endpoint is not available
      return this.approximateDetokenization(tokens);
    }

    return response.data.text;
  }

  /**
   * Approximate detokenization when the API doesn't provide a detokenize endpoint
   */
  private approximateDetokenization(tokens: number[]): string {
    // This is a very rough approximation
    return String.fromCharCode(...tokens);
  }

  /**
   * Count tokens in a message or text
   */
  public async countTokens(
    input: string | { role: string; content: string; name?: string } | Array<{ role: string; content: string; name?: string }>,
    model: string
  ): Promise<number> {
    try {
      // Try to use the API's token count endpoint if available
      const url = new URL('/v1/token/count', this._service.url).toString();
      
      const response = await this.fetch<{ tokens: number } | undefined>(url, {
        method: 'POST',
        headers: this.defaultHeaders,
        body: JSON.stringify({
          input,
          model,
        }),
      });

      if (response.data) {
        return response.data.tokens;
      }
    } catch (error) {
      console.warn('Failed to get token count from API, falling back to estimation', error);
    }

    // Fall back to the base class implementation if the API doesn't support token counting
    return super.countTokens(typeof input === 'string' ? input : JSON.stringify(input), model);
  }

  /**
   * Get the context window size for a model
   */
  public async getContextSize(model: string): Promise<number> {
    // Try to get the context size from the model info
    try {
      const modelInfo = await this.getModel(model);
      if (modelInfo?.contextWindow) {
        return modelInfo.contextWindow;
      }
    } catch (error) {
      console.warn('Failed to get model info, using default context size', error);
    }

    // Default context size if model info is not available
    return 4096; // Default context size for most OpenAI models
  }
}
import { LLMConnector } from './LLMConnector';
import type { Service } from '@/config/types';
import { LLMModel, ChatMessage } from "@/config/types";

// Define StreamChunk interface locally since it's not exported from types
interface StreamChunk {
  content?: string;
  isComplete: boolean;
  error?: string;
  metadata?: Record<string, any>;
}

// Ollama API returns models in this format
interface OllamaTag {
  name: string;
  model: string;
  modified_at: string;
  size: number;
  digest: string;
  details: {
    format: string;
    family: string;
    families: string[] | null;
    parameter_size: string;
    quantization_level: string;
  };
}

export class OllamaConnector extends LLMConnector {
  protected defaultHeaders: Record<string, string>;
  
  constructor(service: Service) {
    super(service);
    this.defaultHeaders = this.getDefaultHeaders();
  }
  
  // Get the default headers for API requests
  protected getDefaultHeaders(): Record<string, string> {
    // Ollama does not use API keys by default.
    // The Authorization header is removed to prevent CORS preflight issues
    // when a key is mistakenly entered in the service settings.
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    return headers;
  }
  
  // Get the service category
  public getCategory(): string {
    return 'llm';
  }
  
  /**
   * Overrides the base fetch method to ensure the Authorization header is never sent.
   * Ollama does not use API keys, and sending an Authorization header can cause
   * CORS preflight requests to fail with a 403 Forbidden error.
   */
  protected async fetch<T = any>(
    url: string,
    options: RequestInit = {}
  ): Promise<{
    data?: T;
    error?: string;
    response?: Response;
  }> {
    try {
      const requestHeaders: Record<string, string> = {
        'Content-Type': 'application/json',
        ...options.headers as Record<string, string>,
      };

      // This is the key change: Unlike the BaseConnector, we DO NOT add an
      // Authorization header here, even if an apiKey is saved on the service.
      
      const response = await fetch(url, {
        ...options,
        headers: requestHeaders,
        credentials: 'omit', // Do not send cookies or other credentials
      });
      
      if (!response.ok) {
        let errorMessage = `HTTP error ${response.status}`;
        try {
          const text = await response.text();
          try {
            const errorData = JSON.parse(text);
            errorMessage = errorData.error?.message || errorData.message || errorMessage;
          } catch (e) {
            errorMessage = text.substring(0, 500);
          }
        } catch (e) {
          // Ignore if reading text fails
        }
        return { error: errorMessage, response };
      }
      
      if (response.status === 204) {
        return { data: {} as T, response };
      }
      
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const data = await response.json();
        return { data, response };
      } else {
        const text = await response.text();
        return { error: `Expected JSON response, but got '${contentType}'.`, response };
      }
    } catch (error) {
      return { 
        error: error instanceof Error ? error.message : 'Unknown fetch error occurred',
      };
    }
  }
  
  // Connect to the service
  public async connect(): Promise<boolean> {
    try {
      await this.checkConnection();
      this._isConnected = true;
      return true;
    } catch (error) {
      console.error('Failed to connect to Ollama service:', error);
      this._isConnected = false;
      return false;
    }
  }

  // Disconnect from the service
  public async disconnect(): Promise<void> {
    this.cancelStream();
    this._isConnected = false;
  }

  // Check if the service is connected
  public isConnected(): boolean {
    return this._isConnected;
  }

  private async checkConnection(): Promise<boolean> {
    try {
      // A simple GET to the version endpoint is the most reliable check.
      const url = new URL('/api/version', this.service.url).toString();
      const response = await this.fetch<{ version: string }>(
        url,
        { method: 'GET' }
      );
      return response.data && response.data.version ? true : false;
    } catch (error) {
      console.error(`Ollama connection check failed for ${this.service.name}:`, error);
      throw error; // Re-throw to be handled by connect()
    }
  }

  // Check the status of the Ollama service
  public async checkStatus() {
    try {
      const models = await this.getModels();
      // Return the service with updated models
      return {
        isOnline: true,
        details: {
          ...this.service,
          models: models,
          modelCount: models.length
        }
      };
    } catch (error) {
      return {
        isOnline: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        details: undefined
      };
    }
  }

  // Get list of available models
  public async getModels(): Promise<LLMModel[]> {
    try {
      const url = new URL('/api/tags', this.service.url).toString();
      const response = await this.fetch<{ models: OllamaTag[] }>(
        url,
        { method: 'GET' }
      );
      
      if (!response.data) {
        throw new Error(response.error || 'Failed to fetch models');
      }
      
      return response.data.models.map(model => ({
        id: model.name,
        name: model.name, // Use model ID as name for consistency
        description: `${model.details.family || 'Unknown'} (${model.details.parameter_size})`,
        contextWindow: this.estimateContextWindow(model.details.parameter_size),
        parameters: this.estimateParameters(model.details.parameter_size),
        supportsChat: true,
        supportsCompletion: true,
        supportsEmbedding: false, // Ollama doesn't support embeddings by default
        createdAt: new Date(model.modified_at).getTime(),
      }));
    } catch (error) {
      console.error(`Ollama getModels failed:`, error);
      throw error;
    }
  }
  
  // Estimate context window based on model parameters
  private estimateContextWindow(parameterSize: string): number {
    // This is a rough estimate based on common model families
    if (parameterSize.includes('70b')) return 8192;
    if (parameterSize.includes('34b')) return 8192;
    if (parameterSize.includes('13b')) return 4096;
    if (parameterSize.includes('7b')) return 4096;
    // Default to a reasonable value
    return 2048;
  }
  
  // Estimate number of parameters based on model size
  private estimateParameters(parameterSize: string): number | undefined {
    // This is a rough estimate based on the parameter size string
    if (parameterSize.includes('70b')) return 70 * 1e9;
    if (parameterSize.includes('34b')) return 34 * 1e9;
    if (parameterSize.includes('13b')) return 13 * 1e9;
    if (parameterSize.includes('7b')) return 7 * 1e9;
    return undefined;
  }

  // Send a chat message and get a response
  public async chat(
    messages: Array<{
      role: 'user' | 'assistant' | 'system' | 'function';
      content: string;
      name?: string;
      function_call?: {
        name: string;
        arguments: string;
      };
    }>,
    model: string,
    options: {
      temperature?: number;
      maxTokens?: number;
      topP?: number;
      frequencyPenalty?: number;
      presencePenalty?: number;
      stop?: string[];
      stream?: boolean;
      onChunk?: (chunk: StreamChunk) => void;
    } = {}
  ): Promise<ChatMessage> {
    const url = new URL('/api/chat', this.service.url).toString();
    const {
      temperature = 0.7,
      maxTokens = 2048,
      topP = 1.0,
      stream = false,
      onChunk,
    } = options;

    // If streaming is requested, handle the streaming response
    if (stream && onChunk) {
      return this.streamChatResponse(
        messages,
        model,
        {
          temperature,
          max_tokens: maxTokens,
          top_p: topP,
        },
        onChunk
      );
    }

    // Standard non-streaming request
    const response = await this.fetch<any>(url, {
      method: 'POST',
      headers: this.defaultHeaders,
      body: JSON.stringify({
        model,
        messages,
        stream: false,
        options: {
          temperature: temperature,
          top_p: topP,
          num_predict: maxTokens,
        },
      }),
    });

    if (!response.data) {
      throw new Error(response.error || 'Failed to get chat completion');
    }

    const choice = response.data.message;
    if (!choice) {
      throw new Error('No response from model');
    }

    return {
      id: `msg_${Date.now()}`,
      role: 'assistant',
      content: choice.content,
      timestamp: Date.now(),
    };
  }

  protected async streamChatResponse(
    messages: Array<{
      role: 'user' | 'assistant' | 'system' | 'function';
      content: string;
      name?: string;
      function_call?: {
        name: string;
        arguments: string;
      };
    }>,
    model: string,
    options: {
      temperature?: number;
      max_tokens?: number;
      top_p?: number;
    },
    onChunk?: (chunk: StreamChunk) => void
  ): Promise<ChatMessage> {
    if (!onChunk) {
      throw new Error('onChunk is required for streaming');
    }

    this.abortController = new AbortController();
    const { signal } = this.abortController;

    try {
      const url = new URL('/api/chat', this.service.url).toString();
      const response = await fetch(url, {
        method: 'POST',
        headers: this.defaultHeaders,
        body: JSON.stringify({ model, messages, stream: true, options: { temperature: options.temperature, top_p: options.top_p, num_predict: options.max_tokens } }),
        signal,
        credentials: 'omit',
      });

      if (!response.ok || !response.body) {
        const errorText = await response.text();
        throw new Error(`Failed to stream chat: ${response.status} ${errorText}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let content = '';
      let accumulatedJson = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          if (onChunk) onChunk({ isComplete: true });
          break;
        }

        accumulatedJson += decoder.decode(value, { stream: true });
        const lines = accumulatedJson.split('\n');
        accumulatedJson = lines.pop() || ''; // Keep the last, possibly incomplete, line

        for (const line of lines) {
          if (line.trim() === '') continue;
          try {
            const data = JSON.parse(line);
            let chunkContent = '';

            if (data.message?.content) {
              chunkContent = data.message.content;
              content += chunkContent;
            }

            if (onChunk) {
              onChunk({
                content: chunkContent,
                isComplete: data.done,
                metadata: data,
              });
            }

            if (data.done) {
              reader.releaseLock();
              return {
                id: `msg_${Date.now()}`,
                role: 'assistant',
                content,
                timestamp: Date.now(),
                metadata: data,
              };
            }
          } catch (error) {
            console.error('Error parsing Ollama stream chunk:', line, error);
            // Continue to next line, as stream might have intermittent non-JSON data
          }
        }
      }

      return {
        id: `msg_${Date.now()}`,
        role: 'assistant',
        content,
        timestamp: Date.now(),
      };
    } catch (error) {
      if (onChunk) {
        onChunk({
          isComplete: true,
          error: error instanceof Error ? error.message : 'Streaming failed',
        });
      }
      throw error;
    } finally {
      this.abortController = null;
    }
  }

  // Cancel the current streaming request
  public cancelStream(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }
  
  // Generate embeddings for a list of texts
  public async embed(
    texts: string[],
    model: string = 'gemma3:1b' // Default to gemma3 if no specific model is provided
  ): Promise<number[][]> {
    const url = new URL('/api/embeddings', this.service.url).toString();
    const embeddings: number[][] = [];
    for (const text of texts) {
      const response = await this.fetch<{ embedding: number[] }>(url, {
        method: 'POST',
        headers: this.defaultHeaders,
        body: JSON.stringify({
          text,
          model,
        }),
      });

      if (!response.data) {
        throw new Error(response.error || 'Failed to get embedding');
      }

      embeddings.push(response.data.embedding);
    }
    return embeddings;
  }
  
  // Tokenize text
  public async tokenize(text: string, model: string): Promise<number[]> {
    throw new Error('Tokenization is not directly supported by Ollama');
  }
  
  // Detokenize tokens back to text
  public async detokenize(tokens: number[], model: string): Promise<string> {
    throw new Error('Detokenization is not directly supported by Ollama');
  }
  
  // Count tokens in a message or text
  public async countTokens(
    input: string | { role: string; content: string; name?: string } | Array<{ role: string; content: string; name?: string }>,
    model: string
  ): Promise<number> {
    // Fall back to the base class implementation
    return super.countTokens(typeof input === 'string' ? input : JSON.stringify(input), model);
  }
  
  // Get the context window size for a model
  public async getContextSize(model: string): Promise<number> {
    // Try to get the context size from the model info
    try {
      const modelInfo = await this.getModel(model);
      if (modelInfo?.contextWindow) {
        return modelInfo.contextWindow;
      }
    } catch (error) {
      console.warn('Failed to get model info, using default context size', error);
    }

    // Default context size if model info is not available
    return 2048; // Default context size for most models
  }
} 
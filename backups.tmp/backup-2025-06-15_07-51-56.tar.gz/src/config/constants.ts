// Special service types that aren't in the main service types
const SPECIAL_SERVICE_TYPES = {
  UI_SERVICE: 'ui-service',
  IMAGE_GEN: 'image-gen'
} as const;

// Service Types
export const SERVICE_TYPES = {
  OLLAMA: 'ollama',
  OPEN_WEBUI: 'open-webui',
  A1111: 'a1111',
  COMFY_UI: 'comfy-ui',
  LLAMA_CPP: 'llama-cpp',
  VLLM: 'vllm',
  LLM_STUDIO: 'llm-studio',
  OPENAI_COMPATIBLE: 'openai-compatible',
  N8N: 'n8n',
  TAILSCALE: 'tailscale',
  ...SPECIAL_SERVICE_TYPES
} as const;

export type ServiceType = typeof SERVICE_TYPES[keyof typeof SERVICE_TYPES];

// Service Categories
export const SERVICE_CATEGORIES = {
  LLM: 'llm',
  IMAGE: 'image',
  UI: 'ui',
  AUTOMATION: 'automation',
  NETWORK: 'network'
} as const;



// Service Type to Category Mapping
export const SERVICE_TYPE_TO_CATEGORY = {
  [SERVICE_TYPES.OLLAMA]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.OPEN_WEBUI]: SERVICE_CATEGORIES.UI,
  [SERVICE_TYPES.A1111]: SERVICE_CATEGORIES.IMAGE,
  [SERVICE_TYPES.COMFY_UI]: SERVICE_CATEGORIES.IMAGE,
  [SERVICE_TYPES.LLAMA_CPP]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.VLLM]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.LLM_STUDIO]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.OPENAI_COMPATIBLE]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.N8N]: SERVICE_CATEGORIES.AUTOMATION,
  [SERVICE_TYPES.TAILSCALE]: SERVICE_CATEGORIES.NETWORK,
  [SERVICE_TYPES.UI_SERVICE]: SERVICE_CATEGORIES.UI,
  [SERVICE_TYPES.IMAGE_GEN]: SERVICE_CATEGORIES.IMAGE
} as const satisfies Record<ServiceType, ServiceCategory>;

export type ServiceCategory = typeof SERVICE_CATEGORIES[keyof typeof SERVICE_CATEGORIES];

// Default Ports
export const DEFAULT_PORTS = {
  [SERVICE_TYPES.OLLAMA]: 11434,
  [SERVICE_TYPES.OPEN_WEBUI]: 3000,
  [SERVICE_TYPES.A1111]: 7860,
  [SERVICE_TYPES.COMFY_UI]: 8188,
  [SERVICE_TYPES.LLAMA_CPP]: 8080,
  [SERVICE_TYPES.VLLM]: 8000,
  [SERVICE_TYPES.LLM_STUDIO]: 1234,
  [SERVICE_TYPES.OPENAI_COMPATIBLE]: 443,
  [SERVICE_TYPES.N8N]: 5678,
  [SERVICE_TYPES.TAILSCALE]: 8080,
  [SERVICE_TYPES.UI_SERVICE]: 0,
  [SERVICE_TYPES.IMAGE_GEN]: 0
} as const;

// Default Base Paths
export const DEFAULT_PATHS = {
  [SERVICE_TYPES.OLLAMA]: '',
  [SERVICE_TYPES.OPEN_WEBUI]: '',
  [SERVICE_TYPES.A1111]: '',
  [SERVICE_TYPES.COMFY_UI]: '',
  [SERVICE_TYPES.LLAMA_CPP]: '/v1',
  [SERVICE_TYPES.VLLM]: '/v1',
  [SERVICE_TYPES.LLM_STUDIO]: '/v1',
  [SERVICE_TYPES.OPENAI_COMPATIBLE]: '/v1',
  [SERVICE_TYPES.N8N]: '',
  [SERVICE_TYPES.TAILSCALE]: '/api/v2',
  [SERVICE_TYPES.UI_SERVICE]: '',
  [SERVICE_TYPES.IMAGE_GEN]: ''
} as const;

// Service Display Names
export const SERVICE_DISPLAY_NAMES = {
  [SERVICE_TYPES.OLLAMA]: 'Ollama',
  [SERVICE_TYPES.N8N]: 'n8n',
  [SERVICE_TYPES.TAILSCALE]: 'Tailscale',
  [SERVICE_TYPES.OPEN_WEBUI]: 'Open WebUI',
  [SERVICE_TYPES.A1111]: 'Automatic1111',
  [SERVICE_TYPES.COMFY_UI]: 'ComfyUI',
  [SERVICE_TYPES.LLAMA_CPP]: 'Llama.cpp',
  [SERVICE_TYPES.VLLM]: 'vLLM',
  [SERVICE_TYPES.LLM_STUDIO]: 'LLM Studio',
  [SERVICE_TYPES.OPENAI_COMPATIBLE]: 'OpenAI Compatible'
} as const;

// Service Icons
export const SERVICE_ICONS = {
  [SERVICE_TYPES.OLLAMA]: '🦙',
  [SERVICE_TYPES.OPEN_WEBUI]: '🌐',
  [SERVICE_TYPES.A1111]: '🎨',
  [SERVICE_TYPES.COMFY_UI]: '🎛️',
  [SERVICE_TYPES.LLAMA_CPP]: '🦙',
  [SERVICE_TYPES.VLLM]: '⚡',
  [SERVICE_TYPES.LLM_STUDIO]: '🎓',
  [SERVICE_TYPES.OPENAI_COMPATIBLE]: '🔌',
  [SERVICE_TYPES.N8N]: '🔄',
  [SERVICE_TYPES.TAILSCALE]: '🔒',
  [SERVICE_TYPES.UI_SERVICE]: '💻',
  [SERVICE_TYPES.IMAGE_GEN]: '🎨'
} as const;

// Service Categories Mapping
export const SERVICE_CATEGORY_MAP = {
  [SERVICE_TYPES.OLLAMA]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.OPEN_WEBUI]: SERVICE_CATEGORIES.UI,
  [SERVICE_TYPES.A1111]: SERVICE_CATEGORIES.IMAGE,
  [SERVICE_TYPES.COMFY_UI]: SERVICE_CATEGORIES.IMAGE,
  [SERVICE_TYPES.LLAMA_CPP]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.VLLM]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.LLM_STUDIO]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.OPENAI_COMPATIBLE]: SERVICE_CATEGORIES.LLM,
  [SERVICE_TYPES.N8N]: SERVICE_CATEGORIES.AUTOMATION,
  [SERVICE_TYPES.TAILSCALE]: SERVICE_CATEGORIES.NETWORK,
  [SERVICE_TYPES.UI_SERVICE]: SERVICE_CATEGORIES.UI,
  [SERVICE_TYPES.IMAGE_GEN]: SERVICE_CATEGORIES.IMAGE
} as const satisfies Record<ServiceType, ServiceCategory>;

// Default Service URLs
export const getDefaultServiceUrl = (type: ServiceType, host: string = 'localhost'): string => {
  const port = DEFAULT_PORTS[type];
  const path = DEFAULT_PATHS[type];
  return `http://${host}:${port}${path}`;
};

// Default Services Configuration
export const DEFAULT_SERVICES: Array<{
  name: string;
  type: ServiceType;
  url: string;
  apiKey?: string;
}> = [
  {
    name: 'Ollama (Local)',
    type: SERVICE_TYPES.OLLAMA,
    url: getDefaultServiceUrl(SERVICE_TYPES.OLLAMA)
  },
  {
    name: 'OpenWebUI (Local)',
    type: SERVICE_TYPES.OPEN_WEBUI,
    url: getDefaultServiceUrl(SERVICE_TYPES.OPEN_WEBUI)
  },
  {
    name: 'A1111 (Local)',
    type: SERVICE_TYPES.A1111,
    url: getDefaultServiceUrl(SERVICE_TYPES.A1111)
  },
  {
    name: 'ComfyUI (Local)',
    type: SERVICE_TYPES.COMFY_UI,
    url: getDefaultServiceUrl(SERVICE_TYPES.COMFY_UI)
  },
  {
    name: 'Llama.cpp (Local)',
    type: SERVICE_TYPES.LLAMA_CPP,
    url: getDefaultServiceUrl(SERVICE_TYPES.LLAMA_CPP)
  },
  {
    name: 'vLLM (Local)',
    type: SERVICE_TYPES.VLLM,
    url: getDefaultServiceUrl(SERVICE_TYPES.VLLM)
  },
  {
    name: 'LLM Studio (Local)',
    type: SERVICE_TYPES.LLM_STUDIO,
    url: getDefaultServiceUrl(SERVICE_TYPES.LLM_STUDIO)
  },
  {
    name: 'OpenAI Compatible',
    type: SERVICE_TYPES.OPENAI_COMPATIBLE,
    url: 'https://api.openai.com/v1',
    apiKey: ''
  }
];

import React, { useState, useEffect } from 'react';
import type { Service, LLMModel, ImageModel, ServiceType } from '../config/types';
import { sendMessage } from '../utils/chrome';

interface ServiceDetailsProps {
  service: Service;
  onClose: () => void;
}

const imageGenServiceTypes: ServiceType[] = ['a1111', 'comfy-ui'];

const ServiceDetails: React.FC<ServiceDetailsProps> = ({ service, onClose }) => {
  const [models, setModels] = useState<(LLMModel | ImageModel)[]>([]);
  const [loras, setLoras] = useState<ImageModel[]>([]);
  const [embeddings, setEmbeddings] = useState<ImageModel[]>([]);
  const [defaultModelId, setDefaultModelId] = useState<string | null>(service.model || null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDetails = async () => {
      setIsLoading(true);
      setError(null);
      setModels([]);
      setLoras([]);
      setEmbeddings([]);

      try {
        const fetchedModels = await sendMessage<(LLMModel | ImageModel)[]>('getModels', { serviceId: service.id });
        setModels(fetchedModels || []);

        if (imageGenServiceTypes.includes(service.type)) {
          const [fetchedLoras, fetchedEmbeddings] = await Promise.all([
            sendMessage<ImageModel[]>('getLoras', { serviceId: service.id }),
            sendMessage<ImageModel[]>('getEmbeddings', { serviceId: service.id }),
          ]);
          setLoras(fetchedLoras || []);
          setEmbeddings(fetchedEmbeddings || []);
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch service details.';
        setError(errorMessage);
      }
      setIsLoading(false);
    };

    fetchDetails();
  }, [service]);

  const handleSetDefault = async (modelId: string) => {
    try {
      await sendMessage('setDefaultModel', { serviceId: service.id, modelId });
      setDefaultModelId(modelId);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to set default model.';
      setError(errorMessage);
    }
  };

  return (
    <div className="modalBackdrop">
      <div className="modalContent">
        <h2>Details for {service.name}</h2>
        <p className="serviceUrl">URL: {service.url}</p>
        {isLoading && <p>Loading details...</p>}
        {error && <p className="errorText">Error: {error}</p>}

        <h3>Checkpoints / Models</h3>
        {models.length > 0 ? (
          <ul className="modelList">
            {models.map(model => (
              <li key={model.id}>
                <span>{model.name}</span>
                <button
                  onClick={() => handleSetDefault(model.id)}
                  className={defaultModelId === model.id ? 'defaultButtonActive' : 'defaultButton'}
                  title={defaultModelId === model.id ? 'Current Default' : 'Set as Default'}
                  disabled={defaultModelId === model.id}
                >
                  ⭐
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No models found for this service.</p>
        )}

        {imageGenServiceTypes.includes(service.type) && (
          <>
            <h3>LoRAs</h3>
            {loras.length > 0 ? (
              <ul className="modelList">
                {loras.map(lora => (
                  <li key={lora.id || lora.name}>
                    <span>{lora.name}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p>No LoRAs found.</p>
            )}

            <h3>Embeddings</h3>
            {embeddings.length > 0 ? (
              <ul className="modelList">
                {embeddings.map(embedding => (
                  <li key={embedding.id || embedding.name}>
                    <span>{embedding.name}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p>No embeddings found.</p>
            )}
          </>
        )}

        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default ServiceDetails; 
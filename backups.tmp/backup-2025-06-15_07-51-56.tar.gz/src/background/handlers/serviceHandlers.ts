import type { Service, RequestHandler } from '../../config/types';
import { connectorManager } from '../connectors';
import { storageManager } from '../../storage/storageManager';
import { SERVICE_TYPE_TO_CATEGORY, SERVICE_TYPES } from '../../config/constants';

export async function getServices(): Promise<Service[]> {
  return storageManager.get<Service[]>('services', []);
}

export async function addService(payload: Partial<Service>): Promise<Service> {
  const services = await storageManager.get<Service[]>('services', []);
  const serviceType = payload.type || SERVICE_TYPES.OLLAMA;
  const newService: Service = {
    id: `srv_${Date.now()}`,
    name: payload.name || 'New Service',
    type: serviceType,
    url: payload.url || '',
    apiKey: payload.apiKey,
    model: payload.model,
    category: payload.category || SERVICE_TYPE_TO_CATEGORY[serviceType],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: payload.isActive,
  };

  const updatedServices = [...services, newService];
  await storageManager.set('services', updatedServices);
  return newService;
}

export async function updateService(payload: Service): Promise<Service> {
  const services = await storageManager.get<Service[]>('services', []);
  const index = services.findIndex((s) => s.id === payload.id);

  if (index === -1) {
    throw new Error('Service not found');
  }

  const updatedService: Service = {
    ...services[index],
    ...payload,
    updatedAt: Date.now(),
  };

  const updatedServices = [...services];
  updatedServices[index] = updatedService;

  connectorManager.removeConnector(payload.id);
  await storageManager.set('services', updatedServices);
  return updatedService;
}

export async function removeService(payload: { id: string }): Promise<Service[]> {
  const services = await storageManager.get<Service[]>('services', []);
  const updatedServices = services.filter((s) => s.id !== payload.id);

  connectorManager.removeConnector(payload.id);
  await storageManager.set('services', updatedServices);
  return updatedServices;
}

export async function setDefaultModel(payload: { serviceId: string; modelId: string }): Promise<Service> {
  const { serviceId, modelId } = payload;
  const services = await storageManager.get<Service[]>('services', []);
  const index = services.findIndex((s) => s.id === serviceId);

  if (index === -1) {
    throw new Error(`Service not found with id: ${serviceId}`);
  }

  const updatedService: Service = {
    ...services[index],
    model: modelId,
    updatedAt: Date.now(),
  };

  const updatedServices = [...services];
  updatedServices[index] = updatedService;

  await storageManager.set('services', updatedServices);
  return updatedService;
}

export async function checkStatus(payload: { serviceId: string }) {
  const services = await storageManager.get<Service[]>('services', []);
  const service = services.find((s) => s.id === payload.serviceId);

  if (!service) {
    throw new Error(`Service not found with id: ${payload.serviceId}`);
  }

  const connector = await connectorManager.getConnector(service);
  if (!connector) {
    throw new Error(`Connector could not be created for service: ${service.name}`);
  }

  try {
    return connector.checkStatus();
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to check service status: ${errorMessage}`);
  }
}

/**
 * Get the currently active service
 */
export const getActiveService: RequestHandler<null, Service | null> = async () => {
  const services = await getServices();
  const activeServiceId = await storageManager.get<string>('activeServiceId');
  if (!activeServiceId) {
    // If no active service is set, try to set the first available one as default
    if (services.length > 0) {
      await storageManager.set('activeServiceId', services[0].id);
      return services[0];
    }
    return null;
  }
  return services.find(s => s.id === activeServiceId) || null;
};

/**
 * Set the currently active service
 */
export const setActiveService: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }) => {
  await storageManager.set('activeServiceId', serviceId);
};

/**
 * Get the ID of the currently active service
 */
export const getActiveServiceId: RequestHandler<null, string | null> = async () => {
  const serviceId = await storageManager.get<string>('activeServiceId');
  return serviceId || null;
};

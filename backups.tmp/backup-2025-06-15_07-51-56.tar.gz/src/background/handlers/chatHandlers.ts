import { connectorManager } from "../connectors";
import { getChatHistory as getHistoryFromStorage, saveChatHistory, getServices } from "../utils/storage";
import type { ChatMessage, RequestHandler, ChatConnector, LLMModel, ImageModel, ImageGenConnector } from "../../config/types";

// Constants
const CHAT_HISTORY_LIMIT = 100; // Maximum number of messages to keep in history

interface ChatRequest {
  serviceId: string;
  messages: ChatMessage[];
  model?: string;
  options?: Record<string, unknown>;
}

/**
 * Send a chat message and handle the conversation history
 */
export const sendMessage: RequestHandler<ChatRequest, ChatMessage> = async ({
  serviceId,
  messages,
  model,
  options = {},
}) => {
  if (!serviceId || !messages?.length) {
    throw new Error("Invalid request: serviceId and messages are required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = (await connectorManager.getConnector(service)) as ChatConnector | null;
    if (!connector || typeof connector.chat !== 'function') {
      throw new Error(`Connector for service ${serviceId} does not support chat`);
    }

    const history = await getChatHistory({ serviceId });
    const userMessage = messages[messages.length - 1];

    const updatedHistory: ChatMessage[] = [...history, userMessage];

    if (updatedHistory.length > CHAT_HISTORY_LIMIT) {
      updatedHistory.splice(0, updatedHistory.length - CHAT_HISTORY_LIMIT);
    }

    const response = await connector.chat(updatedHistory, model, options);

    const finalHistory = [...updatedHistory, response];
    await saveChatHistory({ serviceId, messages: finalHistory });

    return response;
  } catch (error) {
    console.error("Error in sendMessage:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to send message: ${errorMessage}`);
  }
};

/**
 * Clear chat history for a service
 */
export const clearChatHistory: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }) => {
  if (!serviceId) {
    throw new Error("serviceId is required");
  }

  try {
    await saveChatHistory({ serviceId, messages: [] });
  } catch (error) {
    console.error("Error clearing chat history:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to clear chat history: ${errorMessage}`);
  }
};

/**
 * Get available models for a service
 */
export const getModels: RequestHandler<{ serviceId: string }, (LLMModel | ImageModel)[]> = async ({ serviceId }) => {
  if (!serviceId) {
    throw new Error("Invalid request: serviceId is required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = await connectorManager.getConnector(service);
    if (!connector) {
      throw new Error(`Connector for service ${serviceId} could not be created`);
    }

    if (typeof (connector as any).getModels === 'function') {
      return (connector as ChatConnector | ImageGenConnector).getModels();
    }

    return [];
  } catch (error) {
    console.error(`Error getting models for service ${serviceId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get models: ${errorMessage}`);
  }
};

/**
 * Get chat history for a service
 */
export const getChatHistory: RequestHandler<{ serviceId: string }, ChatMessage[]> = async ({ serviceId }) => {
  if (!serviceId) {
    throw new Error("serviceId is required");
  }

  try {
    return await getHistoryFromStorage({ serviceId });
  } catch (error) {
    console.error("Error getting chat history:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get chat history: ${errorMessage}`);
  }
};

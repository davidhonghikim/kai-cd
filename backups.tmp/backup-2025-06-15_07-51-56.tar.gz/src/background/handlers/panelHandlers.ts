import { setActiveService } from './serviceHandlers';
import { storageManager } from '../../storage/storageManager';
import type { Service, RequestHandler } from '../../config/types';

/**
 * Hides the side panel for a given tab by disabling it.
 */
export const hideSidePanel: RequestHandler<{ tabId: number }, void> = async ({ tabId }) => {
  if (!tabId) {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab && activeTab.id) {
      tabId = activeTab.id;
    } else {
      throw new Error('Could not determine active tab to hide side panel.');
    }
  }

  await chrome.sidePanel.setOptions({
    tabId,
    enabled: false,
  });
};

/**
 * Opens the extension's options page.
 */
export const openOptionsPage: RequestHandler<null, void> = async () => {
  chrome.runtime.openOptionsPage();
};

/**
 * Opens a service's URL in a new tab.
 */
export const openServiceInTab: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }) => {
  const services = await storageManager.get<Service[]>('services', []);
  const service = services.find((s) => s.id === serviceId);
  if (service && service.url) {
    chrome.tabs.create({ url: service.url });
  } else {
    throw new Error(`Service with id ${serviceId} or its URL not found.`);
  }
};

import { connectorManager } from "../connectors";
import {
  getServices,
  getImageArtifacts as getArtifactsFromStorage,
  addImageArtifact,
  deleteImageArtifact as deleteArtifactFromStorage,
} from "../utils/storage";
import type {
  RequestHandler,
  ImageArtifact,
  ImageGenConnector,
  ImageGenOptions,
  ImageModel,
} from "../../config/types";

interface GenerateImageRequest {
  serviceId: string;
  prompt: string;
  options?: ImageGenOptions;
}

export const generateImage: RequestHandler<GenerateImageRequest, ImageArtifact> = async ({
  serviceId,
  prompt,
  options = {},
}) => {
  if (!serviceId || !prompt) {
    throw new Error("Invalid request: serviceId and prompt are required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  const connector = (await connectorManager.getConnector(service)) as ImageGenConnector | null;
  if (!connector || typeof connector.generateImage !== "function") {
    throw new Error(`Connector for service ${serviceId} does not support image generation`);
  }

  try {
    const result = await connector.generateImage(prompt, options);
    const newArtifact: ImageArtifact = {
      id: result.id || `img_${Date.now()}`,
      serviceId,
      prompt,
      imageUrl: result.imageUrl || "",
      timestamp: Date.now(),
      width: result.width || 512,
      height: result.height || 512,
      steps: result.steps || 30,
      cfgScale: result.cfgScale || 7,
      sampler: result.sampler || "Euler a",
      seed: result.seed || -1,
      ...result,
    };

    await addImageArtifact(newArtifact);
    return newArtifact;
  } catch (error) {
    console.error("Error generating image:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to generate image: ${errorMessage}`);
  }
};

export const getImageArtifacts: RequestHandler<void, ImageArtifact[]> = async () => {
  try {
    return await getArtifactsFromStorage();
  } catch (error) {
    console.error("Error fetching image artifacts:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to fetch image artifacts: ${errorMessage}`);
  }
};

export const deleteImageArtifact: RequestHandler<{ id: string }, void> = async ({ id }) => {
  if (!id) {
    throw new Error("Artifact ID is required");
  }

  try {
    await deleteArtifactFromStorage(id);
  } catch (error) {
    console.error("Error deleting image artifact:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to delete image artifact: ${errorMessage}`);
  }
};

/**
 * Get available LoRAs for a service
 */
export const getLoras: RequestHandler<{ serviceId: string }, ImageModel[]> = async ({ serviceId }) => {
  if (!serviceId) {
    throw new Error("Invalid request: serviceId is required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = await connectorManager.getConnector(service) as ImageGenConnector;
    if (!connector) {
      throw new Error(`Connector for service ${serviceId} could not be created`);
    }

    if (typeof connector.getLoras === 'function') {
      return connector.getLoras();
    }

    return [];
  } catch (error) {
    console.error(`Error getting LoRAs for service ${serviceId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get LoRAs: ${errorMessage}`);
  }
};

/**
 * Get available embeddings for a service
 */
export const getEmbeddings: RequestHandler<{ serviceId: string }, ImageModel[]> = async ({ serviceId }) => {
  if (!serviceId) {
    throw new Error("Invalid request: serviceId is required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = await connectorManager.getConnector(service) as ImageGenConnector;
    if (!connector) {
      throw new Error(`Connector for service ${serviceId} could not be created`);
    }

    if (typeof connector.getEmbeddings === 'function') {
      return connector.getEmbeddings();
    }

    return [];
  } catch (error) {
    console.error(`Error getting embeddings for service ${serviceId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get embeddings: ${errorMessage}`);
  }
};

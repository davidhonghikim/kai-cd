import { storageManager } from "../../storage/storageManager";
import type { Service, ChatMessage, ImageArtifact } from "../../config/types";

// Service Management
export const getServices = async (): Promise<Service[]> => {
  const services = await storageManager.get<Service[]>('services');
  return Array.isArray(services) ? services : [];
};

export const saveServices = async (services: Service[]): Promise<void> => {
  await storageManager.set('services', services);
};

// Chat History
interface GetChatHistoryParams {
  serviceId: string;
}

export const getChatHistory = async ({ serviceId }: GetChatHistoryParams): Promise<ChatMessage[]> => {
  const history = await storageManager.get<Record<string, ChatMessage[]>>('chatHistory');
  if (!history || typeof history !== 'object') {
    return [];
  }
  const messages = history[serviceId];
  return Array.isArray(messages) ? messages : [];
};

interface SaveChatHistoryParams {
  serviceId: string;
  messages: ChatMessage[];
}

export const saveChatHistory = async ({ serviceId, messages }: SaveChatHistoryParams): Promise<void> => {
  if (!Array.isArray(messages)) {
    throw new Error('Messages must be an array');
  }
  const history = await storageManager.get<Record<string, ChatMessage[]>>('chatHistory') || {};
  const updatedHistory = {
    ...history,
    [serviceId]: messages
  };
  await storageManager.set('chatHistory', updatedHistory);
};

// Image Artifacts
export const getImageArtifacts = async (): Promise<ImageArtifact[]> => {
  const artifacts = await storageManager.get<ImageArtifact[]>('imageArtifacts');
  return Array.isArray(artifacts) ? artifacts : [];
};

export const addImageArtifact = async (newArtifact: ImageArtifact): Promise<void> => {
  if (!newArtifact || typeof newArtifact !== 'object') {
    throw new Error('Invalid artifact');
  }
  const artifacts = await getImageArtifacts();
  const updatedArtifacts = [...artifacts, newArtifact];
  await storageManager.set('imageArtifacts', updatedArtifacts);
};

export const deleteImageArtifact = async (id: string): Promise<void> => {
  if (!id) {
    throw new Error('ID is required');
  }
  const artifacts = await getImageArtifacts();
  const filtered = artifacts.filter((a) => a.id !== id);
  await storageManager.set('imageArtifacts', filtered);
};

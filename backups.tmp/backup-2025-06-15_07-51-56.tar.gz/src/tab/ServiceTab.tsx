import React, { useState, useEffect } from 'react';
import { Service, ServiceType } from '@/config/types';
import { storageManager } from "@/storage/storageManager";
import { sendMessage } from '@/utils/chrome';
import A1111View from "@/views/A1111View";
import ComfyUIView from "@/views/ComfyUIView";
import '@/styles/global.css';
import styles from '@/styles/components/tab/ServiceTab.module.css';

const iframeServiceTypes: ServiceType[] = ['open-webui'];

const ServiceTab: React.FC = () => {
    const [service, setService] = useState<Service | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const loadService = async () => {
            const params = new URLSearchParams(window.location.search);
            const serviceId = params.get('serviceId');
            if (!serviceId) {
                setError('No Service ID provided in URL.');
                return;
            }
            
            const allServices: Service[] = (await storageManager.get('services')) || [];
            const activeService = allServices.find(s => s.id === serviceId);

            if (activeService) {
                setService(activeService);
            } else {
                setError(`Service with ID "${serviceId}" not found.`);
            }
        };
        loadService();
    }, []);
    
    const handleSwitchToPanel = async () => {
        if (!service) return;
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.id) {
            // Use the new, robust action to open the panel
            await sendMessage('openSidePanel', { serviceId: service.id, tabId: tab.id });
            // We can close this tab after the panel is shown
            window.close();
        }
    };

    const renderContent = () => {
        if (error) return <div className={styles.container}><h2 className={styles.error}>{error}</h2></div>;
        if (!service) return <div className={styles.container}><h2>Loading...</h2></div>;

        let view;
        switch (service.type) {
            case 'a1111':
                view = <A1111View service={service} />;
                break;
            case 'comfy-ui':
                view = <ComfyUIView service={service} />;
                break;
            default:
                if (iframeServiceTypes.includes(service.type)) {
                    view = <iframe src={service.url} title={service.name} className={styles.iframe} />;
                } else {
                    view = <h2 className={styles.error}>Service type "{service.type}" cannot be opened in a tab.</h2>;
                }
        }
        
        return (
            <div className={styles.container}>
                <header className={styles.header}>
                    <h1>{service.name}</h1>
                    <button onClick={handleSwitchToPanel} className={styles.switchButton}>Switch to Panel</button>
                </header>
                <main className={styles.mainContent}>
                    {view}
                </main>
            </div>
        );
    };

    return renderContent();
};

export default ServiceTab; 
import React from 'react';
import ReactDOM from 'react-dom/client';
import ServiceTab from './ServiceTab';
import '@/styles/vendors/tab.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ServiceTab />
  </React.StrictMode>
);
# ChatDemon Project Structure

## Directory Structure

```
chatdemon/
├── .github/                    # GitHub specific files
│   ├── workflows/             # CI/CD workflows
│   └── ISSUE_TEMPLATE/        # Issue templates
├── src/                       # Source code
│   ├── background/           # Background scripts
│   ├── content/             # Content scripts
│   ├── popup/               # Popup UI
│   ├── options/             # Options page
│   ├── services/            # Service connectors
│   │   ├── llm/            # LLM service connectors
│   │   ├── image/          # Image generation connectors
│   │   ├── automation/     # Automation service connectors
│   │   └── vector/         # Vector search connectors
│   ├── utils/              # Utility functions
│   ├── storage/            # Storage management
│   ├── types/              # TypeScript type definitions
│   └── constants/          # Constants and configuration
├── public/                  # Static assets
│   ├── icons/              # Extension icons
│   └── assets/             # Other static assets
├── tests/                   # Test files
│   ├── unit/               # Unit tests
│   ├── integration/        # Integration tests
│   └── e2e/                # End-to-end tests
├── docs/                    # Documentation
│   ├── api/                # API documentation
│   ├── guides/             # User guides
│   └── development/        # Development guides
├── scripts/                 # Build and utility scripts
├── config/                  # Configuration files
├── .vscode/                 # VS Code settings
└── dist/                    # Build output
```

## Key Components

### 1. Core Extension Components
- **Background Scripts**: Handle extension lifecycle and core functionality
- **Content Scripts**: Manage page interactions and iframe communication
- **Popup UI**: Main extension interface
- **Options Page**: Extension settings and configuration

### 2. Service Connectors
- **LLM Connectors**: Integration with various LLM services
- **Image Generation Connectors**: Integration with image generation services
- **Automation Connectors**: Integration with workflow automation services
- **Vector Search Connectors**: Integration with vector search services

### 3. Utilities and Helpers
- **Storage Management**: Handle data persistence
- **Type Definitions**: TypeScript interfaces and types
- **Constants**: Configuration and constants
- **Utility Functions**: Shared helper functions

### 4. Testing
- **Unit Tests**: Individual component testing
- **Integration Tests**: Component interaction testing
- **E2E Tests**: Full user flow testing

### 5. Documentation
- **API Documentation**: Service connector APIs
- **User Guides**: End-user documentation
- **Development Guides**: Developer documentation

## File Naming Conventions

1. **Component Files**:
   - React components: `PascalCase.tsx`
   - Utility functions: `camelCase.ts`
   - Type definitions: `PascalCase.types.ts`

2. **Test Files**:
   - Unit tests: `*.test.ts`
   - Integration tests: `*.integration.test.ts`
   - E2E tests: `*.e2e.test.ts`

3. **Configuration Files**:
   - Environment: `.env.*`
   - Build config: `*.config.js`
   - TypeScript config: `tsconfig.json`

## Module Organization

1. **Service Connectors**:
   - Each service type has its own directory
   - Common interfaces in `types/`
   - Implementation-specific code in service directories

2. **UI Components**:
   - Organized by feature/functionality
   - Shared components in `components/common/`
   - Feature-specific components in feature directories

3. **Utilities**:
   - Domain-specific utilities in feature directories
   - Shared utilities in `utils/`
   - Type definitions in `types/`

## Build and Development

1. **Development Environment**:
   - Node.js and npm for package management
   - TypeScript for type safety
   - ESLint and Prettier for code quality
   - Jest for testing

2. **Build Process**:
   - Webpack for bundling
   - TypeScript compilation
   - Asset optimization
   - Environment-specific builds

3. **Deployment**:
   - Automated builds via GitHub Actions
   - Version management
   - Release process documentation

## Version Control

1. **Branch Strategy**:
   - `main`: Production-ready code
   - `develop`: Development branch
   - `feature/*`: Feature branches
   - `bugfix/*`: Bug fix branches
   - `release/*`: Release preparation

2. **Commit Guidelines**:
   - Conventional commits
   - Clear commit messages
   - Atomic commits

## Documentation Standards

1. **Code Documentation**:
   - JSDoc comments for functions and classes
   - README files in each major directory
   - Type definitions with descriptions

2. **Project Documentation**:
   - API documentation
   - User guides
   - Development guides
   - Contributing guidelines

## Testing Strategy

1. **Unit Testing**:
   - Component testing
   - Utility function testing
   - Service connector testing

2. **Integration Testing**:
   - Component interaction testing
   - Service integration testing
   - API integration testing

3. **E2E Testing**:
   - User flow testing
   - Cross-browser testing
   - Performance testing 
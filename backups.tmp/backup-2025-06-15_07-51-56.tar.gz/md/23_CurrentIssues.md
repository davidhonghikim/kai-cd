# 23 - Current Issues Log

**Last Updated:** {{current_date}}

This document consolidates all critical bugs and regressions that must be fixed for the application to be considered stable. It serves as the primary checklist for development. No new features should be implemented until every item here is resolved.

---

## Core UI & Functionality Bugs

| ID | Issue | Status | Verification Steps |
|---|---|---|---|
| **BUG-01** | **Cannot Toggle Side Panel:** The "Show/Hide Panel" button in the popup is not working correctly. It may open the panel but not close it, or fail to respond. | **Active** | 1. Open popup. 2. Click "Show Panel". Panel must open. 3. Open popup again. Button must say "Hide Panel". 4. Click "Hide Panel". Panel must close. |
| **BUG-02** | **Wrong View in Panel/Tab:** UI-based services (OpenWebUI, A1111, ComfyUI) are incorrectly showing the custom LLM chat UI instead of their own native UI (as an iframe or dedicated component). This must be fixed for both the panel and the tab view. | **Active** | 1. Open OpenWebUI in the panel. Verify its iframe UI appears. 2. Open A1111 in the panel. Verify the custom A1111 view appears. 3. Open ComfyUI in a tab. Verify the custom ComfyUI view appears. |
| **BUG-03** | **OpenWebUI in LLM list:** OpenWebUI is incorrectly classified as a service compatible with the custom LLM chat UI and its logic. | **Active** | 1. Examine all service type definitions (e.g., `llmServiceTypes` in `SidePanel.tsx`). 2. Ensure `open-webui` is *not* in any list that would route it to the LLM chat logic. |
| **BUG-04** | **Incorrect Tab/Panel Button Logic:** The button in a view should always link to the *other* view. A tab should have a "Switch to Panel" button, not "Open in Tab". | **Active** | 1. Open a service in the side panel. The header button must say "Switch to Tab" (or show an appropriate icon). 2. Open a service in a full tab. The header button must say "Switch to Panel". |

## Service Manager (Options Page) Bugs

| ID | Issue | Status | Verification Steps |
|---|---|---|---|
| **BUG-05** | **No Model List:** The service manager does not display the list of available models for a service when "Details" is clicked. | **Active** | 1. Go to Options > Manage Services. 2. Click "Details" for an online service (e.g., Ollama). 3. A modal/view must appear, listing all models fetched from the service's API. |
| **BUG-06** | **No Default Model Selection:** There is no UI to select a default model for a service from the model list. | **Active** | 1. In the model list view (from BUG-05), there must be a control (e.g., radio button or star icon) to set one model as the default. 2. Verify this selection is saved and used when opening that service's chat panel. |
| **BUG-07** | **Endpoints Not Editable/Visible:** The full endpoint URL for a service is not clearly visible or editable in the "Add/Edit Service" form. The current implementation only shows the base URL. | **Active** | 1. Open the "Edit Service" form for any service. 2. The `URL` field must show the *full* URL, including any specific paths (e.g., `http://host:port/v1/chat/completions`). 3. Verify this full URL is editable and saves correctly. |
| **BUG-08** | **Incorrect Status & Model Count:** Status checking is unreliable. Offline services show "online" or incorrect model counts. Online services sometimes show "offline". | **Active** | 1. Stop a running service (e.g., Ollama). 2. Go to Options and click "Check Status". It must reliably show "Offline". 3. Start the service. Click "Check Status". It must reliably show "Online" and provide an accurate model count if applicable. | 
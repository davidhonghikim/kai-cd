# 10_Shortcuts.md
# ChatDemon Shortcuts
**Title:** Shortcuts

*   *(List of useful keyboard shortcuts within the extension. Add these as you develop the UI).* Example: `Ctrl+Shift+C` - Clear the side panel chat.
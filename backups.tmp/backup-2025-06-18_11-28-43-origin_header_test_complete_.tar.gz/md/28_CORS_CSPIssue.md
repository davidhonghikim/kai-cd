# CORS, CSP, and Related Debug Data for Ollama Remote Integration

**Date:** June 18, 2025  
**Issue:** Remote Ollama 403 CORS Error  
**Status:** 🔧 Debugging in Progress  
**Priority:** HIGH - Immediate Resolution Required

---

## 📋 **Executive Summary**

The ChatDemon browser extension is experiencing 403 errors when connecting to remote Ollama servers, despite successful curl and Node.js requests. This document provides comprehensive debugging data for backend/infrastructure teams to resolve the issue immediately.

---

## 🔧 **1. Extension Configuration (Frontend)**

### **OllamaConnector.ts - Core Logic**
**File:** `src/services/llm/ollamaConnector.ts`

#### **CORS Configuration**
```typescript
const response = await fetch(url, {
  ...options,
  headers,
  signal: this.abortController.signal,
  mode: "cors",           // Enables CORS for cross-origin requests
  credentials: "omit"     // No cookies/credentials (matches curl behavior)
});
```

#### **Message Formatting Logic**
```typescript
// Clean messages to match Ollama API format
const cleanedMessages = messages.map(msg => ({
  role: msg.role,
  content: msg.content
}));

// Remove extension-specific fields (id, timestamp) that cause 403 errors
const request: ChatCompletionRequest = {
  model,
  messages: cleanedMessages as any,  // Type assertion for compatibility
  options: {
    temperature: 0.7,
    top_p: 0.9,
    top_k: 40,
    max_tokens: 2048,
    stop: []
  }
};
```

#### **Request Headers Sent**
```typescript
headers: {
  'User-Agent': 'ChatDemon-Extension/1.0',
  'Accept': 'application/json',
  'Accept-Language': 'en-US,en;q=0.9',
  'Content-Type': 'application/json'
}
```

### **Manifest.json - Permissions**
**File:** `public/manifest.json`

```json
{
  "manifest_version": 3,
  "permissions": [
    "storage",
    "activeTab", 
    "sidePanel",
    "tabs",
    "scripting",
    "downloads",
    "offscreen"
  ],
  "host_permissions": [
    "<all_urls>",
    "http://192.168.1.180:11434/*"
  ]
}
```

**Key Points:**
- ✅ Explicit permission for remote Ollama server
- ✅ `<all_urls>` allows cross-origin requests
- ✅ No custom CSP restrictions

---

## 🛡️ **2. Content Security Policy (CSP)**

### **Current CSP Status**
- **Extension CSP:** No custom CSP set (browser default applies)
- **Default Extension CSP:** Restrictive but allows fetches to `host_permissions`
- **HTML CSP:** No custom CSP in extension HTML files

### **CSP Requirements for Ollama**
```http
Content-Security-Policy: default-src 'self'; connect-src 'self' http://192.168.1.180:11434;
```

---

## 🌐 **3. Ollama Server CORS Requirements (Backend)**

### **Required CORS Headers**
The Ollama server **MUST** send these headers for browser extension requests:

```http
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: Content-Type, User-Agent, Accept, Accept-Language
Access-Control-Max-Age: 86400
```

### **Server Configuration Options**

#### **Option 1: Direct Ollama CORS (if you control the server)**
```bash
# Start Ollama with CORS enabled
ollama serve --cors "*"
```

#### **Option 2: Reverse Proxy Configuration**
**Nginx Example:**
```nginx
location /api/ {
    proxy_pass http://192.168.1.180:11434;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    
    # CORS Headers
    add_header Access-Control-Allow-Origin "*" always;
    add_header Access-Control-Allow-Methods "GET, POST, OPTIONS" always;
    add_header Access-Control-Allow-Headers "Content-Type, User-Agent, Accept, Accept-Language" always;
    
    # Handle preflight requests
    if ($request_method = 'OPTIONS') {
        add_header Access-Control-Allow-Origin "*" always;
        add_header Access-Control-Allow-Methods "GET, POST, OPTIONS" always;
        add_header Access-Control-Allow-Headers "Content-Type, User-Agent, Accept, Accept-Language" always;
        add_header Access-Control-Max-Age 86400;
        return 204;
    }
}
```

**Caddy Example:**
```caddy
192.168.1.180:11434 {
    reverse_proxy localhost:11434
    header {
        Access-Control-Allow-Origin *
        Access-Control-Allow-Methods "GET, POST, OPTIONS"
        Access-Control-Allow-Headers "Content-Type, User-Agent, Accept, Accept-Language"
    }
}
```

---

## 🧪 **4. Test Results & Diagnostics**

### **Working curl Command**
```bash
curl -v -X POST http://192.168.1.180:11434/api/chat \
  -H "User-Agent: ChatDemon-Extension/1.0" \
  -H "Accept: application/json" \
  -H "Accept-Language: en-US,en;q=0.9" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma3:1b",
    "messages": [{"role": "user", "content": "tell a joke"}],
    "options": {
      "temperature": 0.7,
      "top_p": 0.9,
      "top_k": 40,
      "max_tokens": 2048,
      "stop": []
    }
  }'
```

**Expected Response:**
```json
{
  "model": "gemma3:1b",
  "created_at": "2025-06-18T...",
  "message": {
    "role": "assistant",
    "content": "Why did the scarecrow win an award? Because he was outstanding in his field!"
  },
  "done": true
}
```

### **Test Results Summary**
| Test Method | Status | Notes |
|-------------|--------|-------|
| curl | ✅ Works | Server responds correctly |
| Node.js fetch | ✅ Works | No CORS restrictions |
| Browser Extension | ❌ 403 Error | CORS/format issue |

---

## 🔍 **5. Error Analysis**

### **403 Error Details**
```
Error sending message: Error: HTTP error! status: 403, body:
[OllamaConnector] Request URL: http://192.168.1.180:11434/api/chat
[OllamaConnector] Response status: 403
[OllamaConnector] Response status text: Forbidden
```

### **Root Cause Analysis**
1. **Request reaches server** (no network/CORS error)
2. **Server rejects request** (403 Forbidden)
3. **Empty response body** suggests server-side rejection
4. **Extension headers/format** may be causing rejection

---

## 📁 **6. Related Files & Types**

### **TypeScript Interface**
**File:** `src/types/index.ts`
```typescript
export interface ChatMessage {
  id: string;           // ❌ NOT sent to Ollama
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;    // ❌ NOT sent to Ollama
}
```

**Ollama API Expects:**
```json
{
  "role": "user",
  "content": "message content"
}
```

### **Test Files**
- **`test-cors-fix.html`** - Browser CORS testing
- **`test-remote-ollama.js`** - Node.js testing
- **`test-extension-context.js`** - Extension simulation

---

## 🚨 **7. Immediate Action Items for Backend/Infra Team**

### **Priority 1: Verify CORS Headers**
```bash
# Test if CORS headers are present
curl -v -X OPTIONS http://192.168.1.180:11434/api/chat \
  -H "Origin: chrome-extension://YOUR_EXTENSION_ID" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Content-Type"
```

### **Priority 2: Check Server Logs**
```bash
# Check Ollama server logs for rejection reasons
tail -f /var/log/ollama.log
# or
journalctl -u ollama -f
```

### **Priority 3: Test Request Format**
```bash
# Test exact extension request format
curl -v -X POST http://192.168.1.180:11434/api/chat \
  -H "User-Agent: ChatDemon-Extension/1.0" \
  -H "Accept: application/json" \
  -H "Accept-Language: en-US,en;q=0.9" \
  -H "Content-Type: application/json" \
  -H "Origin: chrome-extension://YOUR_EXTENSION_ID" \
  -d '{"model": "gemma3:1b", "messages": [{"role": "user", "content": "test"}], "options": {"temperature": 0.7, "top_p": 0.9, "top_k": 40, "max_tokens": 2048, "stop": []}}'
```

---

## 📞 **8. Communication Protocol**

### **For Backend/Infrastructure Team:**

**If you see CORS errors in browser console:**
- Server must send `Access-Control-Allow-Origin: *` headers
- Add CORS headers to Ollama server or reverse proxy
- Test with OPTIONS preflight request

**If you see 403 errors (no CORS error):**
- Server is rejecting the request format
- Check server logs for rejection reason
- Verify request body matches working curl example
- Check for IP restrictions or authentication requirements

**If using reverse proxy:**
- Add CORS headers at proxy layer
- Ensure proxy forwards all required headers
- Test proxy configuration independently

---

## 🔧 **9. Debugging Tools Provided**

### **Extension ID for Testing**
Replace `YOUR_EXTENSION_ID` in test commands with the actual extension ID from `chrome://extensions/`

### **Test HTML Page**
Open `test-cors-fix.html` in browser to test various CORS configurations

### **Node.js Test Script**
Run `node test-remote-ollama.js` to verify server connectivity

---

## ✅ **10. Success Criteria**

The issue is resolved when:
1. ✅ Browser extension can connect to remote Ollama server
2. ✅ No CORS errors in browser console
3. ✅ No 403 errors in extension logs
4. ✅ Chat messages send and receive successfully
5. ✅ Response format matches expected Ollama API format

---

**📧 Contact:** Provide this document to backend/infrastructure team for immediate resolution.  
**🔄 Status:** Awaiting server-side CORS configuration or request format adjustment.
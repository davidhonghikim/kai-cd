// Test script to simulate extension's request to remote Ollama
const testRemoteOllama = async () => {
  const url = 'http://192.168.1.180:11434';
  
  console.log('Testing remote Ollama connection...');
  console.log('URL:', url);
  
  try {
    // Test 1: Simple fetch with minimal headers
    console.log('\n=== Test 1: Simple fetch ===');
    const response1 = await fetch(`${url}/api/tags`);
    console.log('Status:', response1.status);
    console.log('Headers:', Object.fromEntries(response1.headers.entries()));
    const data1 = await response1.json();
    console.log('Models count:', data1.models?.length || 0);
    
    // Test 2: With extension headers
    console.log('\n=== Test 2: With extension headers ===');
    const response2 = await fetch(`${url}/api/tags`, {
      headers: {
        'User-Agent': 'ChatDemon-Extension/1.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json'
      }
    });
    console.log('Status:', response2.status);
    console.log('Headers:', Object.fromEntries(response2.headers.entries()));
    const data2 = await response2.json();
    console.log('Models count:', data2.models?.length || 0);
    
    // Test 3: Chat request
    console.log('\n=== Test 3: Chat request ===');
    const chatResponse = await fetch(`${url}/api/chat`, {
      method: 'POST',
      headers: {
        'User-Agent': 'ChatDemon-Extension/1.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gemma3:1b',
        messages: [{ role: 'user', content: 'Hello' }],
        stream: false
      })
    });
    console.log('Chat Status:', chatResponse.status);
    console.log('Chat Headers:', Object.fromEntries(chatResponse.headers.entries()));
    const chatData = await chatResponse.json();
    console.log('Chat Response:', chatData.message?.content?.substring(0, 100) + '...');
    
  } catch (error) {
    console.error('Error:', error);
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
  }
};

// Run the test
testRemoteOllama(); 
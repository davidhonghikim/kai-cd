import { storageManager } from '../../storage/storageManager';
import type { Prompt, RequestHandler } from '../../config/types';

/**
 * Get all prompts
 */
export const getPrompts: RequestHandler<null, Prompt[]> = async () => {
  return await storageManager.get<Prompt[]>('prompts', []);
};

/**
 * Save a new prompt
 */
export const savePrompt: RequestHandler<Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>, Prompt> = async (promptData) => {
  const prompts = await getPrompts(null);
  const newPrompt: Prompt = {
    ...promptData,
    id: `prompt-${Date.now()}`,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  const updatedPrompts = [...prompts, newPrompt];
  await storageManager.set('prompts', updatedPrompts);
  return newPrompt;
};

/**
 * Delete a prompt
 */
export const deletePrompt: RequestHandler<{ promptId: string }, Prompt[]> = async ({ promptId }) => {
  const prompts = await getPrompts(null);
  const updatedPrompts = prompts.filter((p) => p.id !== promptId);
  await storageManager.set('prompts', updatedPrompts);
  return updatedPrompts;
};

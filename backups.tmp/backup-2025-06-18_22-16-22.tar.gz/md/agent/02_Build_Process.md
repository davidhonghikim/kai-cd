# Build Process Documentation (Final & Corrected)

This document outlines the proper, standard method for building the ChatDemon Chrome Extension using Vite. This approach is stable and avoids the pathing issues that previously caused build failures.

## The Core Problem & Solution

The persistent "Could not load manifest" and "file path must exist" errors were caused by an incorrect Vite configuration. By default, Vite's build process preserves the source directory structure in the output. This resulted in files being placed in `dist/src/...` instead of directly in `dist/`.

**The correct solution is to set the `root` property in `vite.config.ts` to `'src'`.**

This tells Vite to treat the `src` directory as the project's root. This single change aligns Vite's understanding of the project structure with the actual layout, resolving all path-related build errors.

## The Correct `vite.config.ts`

This is the final, working configuration that should be used.

```javascript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';
import { viteStaticCopy } from 'vite-plugin-static-copy';

export default defineConfig({
  // Set the project root to the 'src' directory. This is the key to the solution.
  root: 'src',

  plugins: [
    react(),
    // This plugin copies the manifest and icons from the *actual* project root
    // into the final build directory.
    viteStaticCopy({
      targets: [
        {
          src: resolve(__dirname, '..', 'public', 'manifest.json'),
          dest: '.', // Destination is relative to the `outDir`
        },
        {
          src: resolve(__dirname, '..', 'public', 'icons'),
          dest: '.', // Destination is relative to the `outDir`
        },
      ],
    }),
  ],

  build: {
    // The output directory is now relative to the new `root`.
    // We go up one level to place `dist` in the actual project root.
    outDir: '../dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        // Paths here are now relative to the `root` ('src').
        popup: resolve(__dirname, 'popup/index.html'),
        options: resolve(__dirname, 'options/index.html'),
        sidepanel: resolve(__dirname, 'sidepanel/index.html'),
        tab: resolve(__dirname, 'tab/index.html'),
        background: resolve(__dirname, 'background/main.ts'),
      },
      output: {
        entryFileNames: (chunk) => {
          // Keep the background script at the root of the output directory
          if (chunk.name === 'background') {
            return 'background.js';
          }
          // Place all other JS entry points in the assets folder
          return 'assets/[name].js';
        },
        chunkFileNames: 'assets/chunks/[name].js',
        // Let Vite handle asset naming for CSS, images, etc.
        assetFileNames: 'assets/[name].[ext]',
      },
    },
  },
});
```

With this configuration and the source files in their proper locations (`src/popup/index.html`, etc.), the `npm run build` command will produce a correct `dist` directory that can be loaded as a Chrome extension without errors. 
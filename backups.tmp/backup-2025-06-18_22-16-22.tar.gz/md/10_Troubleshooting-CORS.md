# Troubleshooting Guide: Fixing CORS Errors

If you are seeing "Failed to fetch" errors in the extension's console when trying to connect to local AI services like Automatic1111 or ComfyUI, you are likely facing a Cross-Origin Resource Sharing (CORS) issue.

## Why This Happens

For security reasons, web browsers restrict web pages (and extensions) from making requests to a different domain, protocol, or port than the one they came from. Your extension's origin is `chrome-extension://...`, while your local AI service's origin is likely `http://127.0.0.1:7860` or similar. The browser will block the request unless the server explicitly allows it.

## The Solution: Configure Your AI Service

You must configure your AI service to send the correct CORS headers. This is typically done by launching the service with a specific command-line flag.

### For Automatic1111 (Stable Diffusion WebUI)

When you run the `webui.sh` or `webui-user.bat` script, you need to add the `--cors-allow-origins` flag.

**Example:**
```bash
# On Linux/macOS
./webui.sh --cors-allow-origins="chrome-extension://[YOUR_EXTENSION_ID]"

# On Windows
# Edit your webui-user.bat and set the COMMANDLINE_ARGS
set COMMANDLINE_ARGS=--cors-allow-origins="chrome-extension://[YOUR_EXTENSION_ID]"
```

You will need to replace `[YOUR_EXTENSION_ID]` with the actual ID of the ChatDemon extension after you've loaded it into your browser. You can find this ID in your browser's extension management page.

### For ComfyUI

Similarly, you need to add the `--cors-allowed-origins` flag when launching ComfyUI.

**Example:**
```bash
# On Linux/macOS
python main.py --cors-allowed-origins "chrome-extension://[YOUR_EXTENSION_ID]"
```

By providing these flags, you are telling your local AI servers that it's okay to accept requests from the ChatDemon extension, which will resolve the "Failed to fetch" errors and allow the models and other features to load correctly. 
import React, { useState } from 'react';
import styles from '@/styles/components/ChatInput.module.css';
import Button from './common/Button';
import { LLMModel } from '@/types';

interface ChatInputProps {
  onSendMessage: (message: string, model: string) => void;
  isLoading: boolean;
  models: LLMModel[];
  selectedModel: string;
  onModelChange: (modelId: string) => void;
}

const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  models,
  selectedModel,
  onModelChange,
}) => {
  const [prompt, setPrompt] = useState('');

  const handleSendMessage = () => {
    if (!prompt.trim() || isLoading) return;
    onSendMessage(prompt, selectedModel);
    setPrompt('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className={styles.chatInputContainer}>
       <div className={styles.modelSelector}>
        <select value={selectedModel} onChange={(e) => onModelChange(e.target.value)}>
          {models.map((model) => (
            <option key={model.id} value={model.name}>
              {model.name}
            </option>
          ))}
        </select>
      </div>
      <div className={styles.inputArea}>
        <textarea
          className={styles.promptInput}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type your message here..."
          rows={3}
          disabled={isLoading}
        />
        <Button onClick={handleSendMessage} disabled={!prompt.trim() || isLoading}>
          {isLoading ? 'Sending...' : 'Send'}
        </Button>
      </div>
    </div>
  );
};

export default ChatInput; 
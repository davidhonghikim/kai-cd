/* global console */
import { storageManager } from '../storage/storageManager';
import { handlers, Action } from './handlers';
import { setupKeepAliveListener } from '@/utils/keepAlive';
import { RequestHandler } from './types';
import { SERVERS_KEY } from '../utils/settingsIO';
import { DEFAULT_SERVICES } from '../config/defaults';
import { Service } from '@/types';
import { connectorManager } from './connectors';

// Keep the service worker alive
setupKeepAliveListener();

// Initialize default services
async function initializeDefaultServices() {
  console.log('Syncing default services...');
  try {
    const storedServices = await storageManager.get<Service[]>(SERVERS_KEY, []);
    const serviceMap = new Map(storedServices.map(s => [s.id, s]));
    let hasChanged = false;

    // Force update default services with values from config
    for (const defaultService of DEFAULT_SERVICES) {
      const existingService = serviceMap.get(defaultService.id);

      if (!existingService) {
        console.log(`Adding missing service: ${defaultService.name}`);
        serviceMap.set(defaultService.id, {
          ...defaultService,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });
        hasChanged = true;
      } else if (existingService.name !== defaultService.name) {
        // Only update the name if it has changed, leave the URL intact
        console.log(`Updating service name: ${defaultService.name}`);
        serviceMap.set(defaultService.id, {
          ...existingService,
          name: defaultService.name,
          updatedAt: Date.now(),
        });
        hasChanged = true;
      }
    }

    if (hasChanged) {
      const updatedServices = Array.from(serviceMap.values());
      console.log('Saving updated services to storage.', updatedServices);
      await storageManager.set(SERVERS_KEY, updatedServices);
    }

    // Ensure an active service is set
    const activeService = await storageManager.get<Service | null>('activeService', null);
    const allServices = Array.from(serviceMap.values());
    
    if ((!activeService || !serviceMap.has(activeService.id)) && allServices.length > 0) {
      console.log('Setting first available service as active:', allServices[0]);
      await storageManager.set('activeService', allServices[0]);
    }
    
    // Pre-load connectors for all services to ensure they're available immediately
    console.log('Pre-loading connectors for all services...');
    await Promise.all(allServices.map(async (service) => {
      try {
        console.log(`Initializing connector for ${service.name} (${service.type})...`);
        const connector = await connectorManager.getConnector(service);
        console.log(`Connector initialized for ${service.name}: ${connector ? 'success' : 'failed'}`);

        // Pre-load models if the connector was successfully created
        if (connector) {
          console.log(`Loading models for ${service.name}...`);
          try {
            const modelsHandler = handlers['getModels'];
            if (modelsHandler) {
              await modelsHandler(
                { serviceId: service.id },
                { id: 'background' } as chrome.runtime.MessageSender,
                (result: { success: boolean; models?: any[]; data?: any[]; error?: string }) => {
                  const modelCount = result.models?.length || result.data?.length || 0;
                  console.log(
                    `Models loaded for ${service.name}:`,
                    result.success ? `${modelCount} models` : `Error: ${result.error}`
                  );
                }
              );
            }
          } catch (modelError) {
            console.warn(`Failed to pre-load models for ${service.name}:`, modelError);
          }
        }
      } catch (error) {
        console.warn(`Failed to initialize connector for ${service.name}:`, error);
        // Continue with other services even if one fails
      }
    }));
  } catch (error) {
    console.error('Error syncing default services:', error);
    throw error;
  }
}

// Initialize on installation
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Extension installed/updated:', details.reason);
  await initializeDefaultServices();
});

// Initialize on startup
chrome.runtime.onStartup.addListener(async () => {
  console.log('Browser startup, initializing services...');
  await initializeDefaultServices();
});

// Combine all handlers
const allHandlers = handlers;

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message: { action: string; payload?: any }, sender, sendResponse) => {
  const { action, payload } = message;
    console.log("Received message:", action, payload);
    console.log("Available handlers:", Object.keys(allHandlers));
  
  // Check all handlers for the action
  const handler = allHandlers[action as Action] as RequestHandler;
  if (handler) {
    try {
      // Execute handler and ensure response is sent
      const result = handler(payload, sender, sendResponse);
      if (result instanceof Promise) {
        result.catch((error: Error) => {
          console.error(`Error in handler ${action}:`, error);
          sendResponse({ success: false, error: error.message });
        });
        return true; // Keep message channel open for async response
      }
      return result; // Return the result for sync handlers
    } catch (error) {
      console.error(`Error executing handler ${action}:`, error);
      sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
      return false;
    }
  }
  
  // If no handler is found, send an error response
  console.error(`No handler found for action: ${action}`);
  sendResponse({ success: false, error: `No handler found for action: ${action}` });
  return false;
});

console.log('Background script initialized.');

// Initialize services on script startup for development and initial load
initializeDefaultServices().catch(error => {
  console.error("Failed to initialize services on script load:", error);
});

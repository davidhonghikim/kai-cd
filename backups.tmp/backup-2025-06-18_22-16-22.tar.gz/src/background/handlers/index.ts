import { serviceHandlers } from './serviceHandlers';
import { chatHandlers } from './chatHandlers';
import { panelHandlers } from './panelHandlers';
import { storageManager } from '@/storage/storageManager';
import { SERVERS_KEY } from '@/utils/settingsIO';
import { Service } from '@/types';
import { RequestHandler } from './types';

/**
 * A registry of all available background request handlers.
 */
export const handlers = {
  ...serviceHandlers,
  ...chatHandlers,
  ...panelHandlers,
  getPopupState: ((async (_payload, _sender, sendResponse) => {
    try {
      const services = await storageManager.get<Service[]>(SERVERS_KEY, []);
      const activeService = await storageManager.get<Service | null>('activeService', null);
      sendResponse({ success: true, services, activeService });
    } catch (error) {
      sendResponse({ success: false, services: [], activeService: null, error: error instanceof Error ? error.message : 'Unknown error' });
    }
  }) as RequestHandler<undefined, { success: boolean, services: Service[], activeService: Service | null, error?: string}>),
};

export type Action = keyof typeof handlers; 
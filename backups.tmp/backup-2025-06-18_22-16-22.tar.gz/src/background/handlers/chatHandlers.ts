/* eslint-disable @typescript-eslint/no-unused-vars */
import { RequestHandler } from './types';
import { getStoredServices } from '../utils/storage';
import { connectorManager } from '../connectors';
import { LLMModel } from '@/types';

export const handleGetModels: RequestHandler<{ serviceId: string }, { success: boolean, models: LLMModel[], error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const service = services.find(s => s.id === payload.serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    const connector = await connectorManager.getConnector(service);
    if (!connector || !('getModels' in connector)) {
      throw new Error('Connector does not support getting models');
    }
    const models = await (connector as any).getModels();
    sendResponse({ success: true, models });
  } catch (error) {
    sendResponse({ success: false, models: [], error: 'Failed to get models' });
  }
};

export const handleGenerateChatCompletion: RequestHandler<any, { success: boolean, data?: any, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const service = services.find(s => s.id === payload.serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    const connector = await connectorManager.getConnector(service);
    // This is a placeholder for the actual implementation
    const result = await (connector as any).generateChatCompletion(payload);
    sendResponse({ success: true, data: result });
  } catch (error) {
    sendResponse({ success: false, error: 'Failed to generate chat completion' });
  }
};

export const chatHandlers = {
  getModels: handleGetModels,
  generateChatCompletion: handleGenerateChatCompletion,
}; 
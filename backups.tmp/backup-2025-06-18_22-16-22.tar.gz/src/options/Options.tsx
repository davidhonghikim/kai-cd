import React, { useState, useEffect, useCallback } from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { sendMessage } from '../utils/messaging';
import { SERVICE_TYPES, SERVICE_CATEGORIES } from '@/config/constants';
import { SortableServiceItem } from './components/SortableServiceItem';
import styles from '@/styles/components/options/Options.module.css';
import { importServersOnly, exportServersOnly } from '../utils/settingsIO';
import type { Service, LLMModel, ServiceStatus } from '@/types';

interface OptionsProps {
  onOpenAdvancedSettings?: () => void;
}

const Options: React.FC<OptionsProps> = ({ onOpenAdvancedSettings }) => {
  const [services, setServices] = useState<Service[]>([]);
  const [models, setModels] = useState<Record<string, LLMModel[]>>({});
  const [newlyAddedServiceId, setNewlyAddedServiceId] = useState<string | null>(null);
  const [selection, setSelection] = useState<Set<string>>(new Set());
  const [isSelecting, setIsSelecting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const loadServices = useCallback(async () => {
    try {
      console.log('[Options] Loading services...');
      setIsLoading(true);
      const response = await sendMessage('getServices', null) as any;
      console.log('[Options] getServices response:', response);
      if (response && response.success && response.services) {
        console.log('[Options] Services loaded:', response.services);
        setServices(response.services);
      } else {
        console.log('[Options] No services or error in response');
        setServices([]);
      }
    } catch (error) {
      console.error('[Options] Failed to load services:', error);
      setServices([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadServices();
  }, [loadServices]);

  const handleUpdateService = async (serviceId: string, updatedFields: Partial<Service>) => {
    const serviceToUpdate = services.find(s => s.id === serviceId);
    if (!serviceToUpdate) return;

    const updatedService = { ...serviceToUpdate, ...updatedFields, updatedAt: Date.now() };

    setServices(prev => prev.map(s => (s.id === serviceId ? updatedService : s)));
    
    try {
      await sendMessage('updateService', updatedService);
      // Optionally, reload from storage to confirm, but optimistic update is usually fine
    } catch (error) {
      console.error('Failed to save service update:', error);
      // Revert optimistic update on error
      setServices(prev => prev.map(s => (s.id === serviceId ? serviceToUpdate : s)));
    }
  };

  const handleRemoveService = async (serviceId: string) => {
    try {
      await sendMessage('removeService', { id: serviceId });
      loadServices(); // Reload from storage to be safe
    } catch (error) {
      console.error('Failed to remove service:', error);
      alert(`Error removing service: ${error instanceof Error ? error.message : error}`);
    }
  };
  
  const handleCheckStatus = async (serviceId: string) => {
    setServices(prev => prev.map(s => s.id === serviceId ? { ...s, status: 'checking' as const } : s));
    try {
      const response = await sendMessage('checkStatus', { serviceId });
      if (response && response.success && typeof response.data.status === 'string') {
        const status = response.data.status as ServiceStatus;
        const statusCode = response.data.statusCode as number | undefined;
        setServices(prev => prev.map(s => s.id === serviceId ? { ...s, status, statusCode } : s));
      } else {
        setServices(prev => prev.map(s => s.id === serviceId ? { ...s, status: 'error' as const, statusCode: response.data?.statusCode } : s));
      }
    } catch (error) {
      setServices(prev => prev.map(s => s.id === serviceId ? { ...s, status: 'error' as const } : s));
    }
  };

  const handleGetModels = async (serviceId: string) => {
    try {
      const response = await sendMessage('getModels', { serviceId });
      if (response.success) {
        setModels(prev => ({ ...prev, [serviceId]: response.data || [] }));
      }
    } catch (error) {
      console.error(`Failed to get models for ${serviceId}:`, error);
    }
  };

  const handleAddNewService = async () => {
    try {
      const response = await sendMessage('addService', {
        name: 'New Service',
        type: SERVICE_TYPES.OLLAMA,
        url: '',
        category: SERVICE_CATEGORIES.LLM,
      }) as any;
      if (response && response.success && response.data) {
        setServices(prev => [response.data, ...prev]);
        setNewlyAddedServiceId(response.data.id);
      } else {
        throw new Error(response?.error || 'Failed to add service');
      }
    } catch (error) {
       console.error('Failed to add new service:', error);
       alert(`Error adding service: ${error instanceof Error ? error.message : error}`);
    }
  };

  function handleDragEnd(event: any) {
    const { active, over } = event;
    if (active.id !== over.id) {
      setServices((items) => {
        const oldIndex = items.findIndex(item => item.id === active.id);
        const newIndex = items.findIndex(item => item.id === over.id);
        const newItems = arrayMove(items, oldIndex, newIndex);
        
        // Update backend with new order
        const orderedIds = newItems.map(item => item.id);
        sendMessage('updateServicesOrder', { orderedIds });
        
        return newItems;
      });
    }
  }
  
  function handleDragStart() {
    // No need to set activeId as it's handled by the DndContext
  }

  const handleSelectionChange = (serviceId: string) => {
    setSelection(prev => {
      const newSelection = new Set(prev);
      if (newSelection.has(serviceId)) {
        newSelection.delete(serviceId);
      } else {
        newSelection.add(serviceId);
      }
      return newSelection;
    });
  };

  const handleImportServers = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (file) {
        try {
          await importServersOnly(file);
          alert('Servers imported successfully!');
          loadServices();
        } catch (err) {
          alert('Failed to import servers. Please check the file format.');
        }
      }
    };
    input.click();
  };
  
  const handleExportServers = () => {
    exportServersOnly();
  };

  const handleInitializeServices = async () => {
    try {
      console.log('[Options] Manually initializing services...');
      const response = await sendMessage('initializeServices', null) as any;
      console.log('[Options] Initialize services response:', response);
      if (response && response.success && response.services) {
        console.log('[Options] Services initialized:', response.services);
        setServices(response.services);
        alert('Services initialized successfully!');
      } else {
        throw new Error(response?.error || 'Failed to initialize services');
      }
    } catch (error) {
      console.error('[Options] Failed to initialize services:', error);
      alert(`Error initializing services: ${error instanceof Error ? error.message : error}`);
    }
  };

  const handleExport = (exportAll: boolean) => {
    const serviceIds = exportAll ? services.map(s => s.id) : Array.from(selection);
    if (serviceIds.length === 0) {
      alert('Please select at least one service to export.');
      return;
    }
    sendMessage('exportServices', { serviceIds });
    setIsSelecting(false);
    setSelection(new Set());
  };

  return (
    <div className={styles.optionsPage}>
      <header className={styles.header}>
        <h1>ChatDemon Settings</h1>
        <div className={styles.headerActions}>
            <button onClick={handleAddNewService} className={styles.primaryButton}>Add New Service</button>
            <button onClick={handleInitializeServices} className={styles.secondaryButton}>Initialize Services</button>
            <button onClick={handleImportServers} className={styles.secondaryButton}>Import Servers</button>
            <button onClick={onOpenAdvancedSettings} className={styles.secondaryButton}>Advanced Settings</button>
            {isSelecting ? (
                <>
                    <button onClick={() => handleExport(false)} className={styles.primaryButton}>Export Selected ({selection.size})</button>
                    <button onClick={() => {setIsSelecting(false); setSelection(new Set())}} className={styles.secondaryButton}>Cancel</button>
                </>
            ) : (
                <>
                    <button onClick={handleExportServers} className={styles.secondaryButton}>Export All Servers</button>
                    <button onClick={() => setIsSelecting(true)} className={styles.secondaryButton}>Select to Export</button>
                </>
            )}
        </div>
      </header>

      <div className={styles.serviceListContainer}>
        <div className={styles.serviceList}>
            {isLoading ? (
              <div className={styles.loadingMessage}>Loading services...</div>
            ) : (
              <>
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragStart={handleDragStart}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext items={services.map(s => s.id)} strategy={verticalListSortingStrategy}>
                    {services.map(service => (
                      <SortableServiceItem
                        key={service.id}
                        service={service}
                        models={models[service.id] || []}
                        isSelecting={isSelecting}
                        isSelected={selection.has(service.id)}
                        onSelectionChange={handleSelectionChange}
                        onUpdate={(fields) => handleUpdateService(service.id, fields)}
                        onDelete={() => handleRemoveService(service.id)}
                        onCheckStatus={() => handleCheckStatus(service.id)}
                        onGetModels={() => handleGetModels(service.id)}
                        startExpanded={service.id === newlyAddedServiceId}
                      />
                    ))}
                  </SortableContext>
                </DndContext>
                {services.length === 0 && (
                  <p className={styles.noServicesMessage}>No services configured. Click "Add New Service" to begin.</p>
                )}
              </>
            )}
        </div>
      </div>
    </div>
  );
};

export default Options; 
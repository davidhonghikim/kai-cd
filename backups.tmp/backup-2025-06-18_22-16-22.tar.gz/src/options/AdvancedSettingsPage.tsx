import React, { useState } from 'react';
import AdvancedSettingsModal from '../components/settings/AdvancedSettingsModal';
import Button from '../components/common/Button';
import { sendMessage } from '@/utils/chrome';
import styles from '@/styles/components/options/Options.module.css';

const AdvancedSettingsPage: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [resetMessage, setResetMessage] = useState<string | null>(null);
  const [isFixingUrls, setIsFixingUrls] = useState(false);
  const [fixMessage, setFixMessage] = useState<string | null>(null);

  const handleResetServices = async () => {
    if (!confirm('⚠️ This will reset all service configurations to defaults. Are you sure?')) {
      return;
    }

    setIsResetting(true);
    setResetMessage(null);

    try {
      const response = await sendMessage('resetServices', {});
      if (response.success) {
        setResetMessage('✅ Services reset successfully! Page will reload in 2 seconds...');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        setResetMessage(`❌ Error: ${response.error}`);
      }
    } catch (error) {
      setResetMessage(`❌ Failed to reset services: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsResetting(false);
    }
  };

  const handleFixServiceUrls = async () => {
    if (!confirm('🔧 This will fix incorrect service URLs (e.g., Ollama pointing to wrong ports). Continue?')) {
      return;
    }

    setIsFixingUrls(true);
    setFixMessage(null);

    try {
      const response = await sendMessage('fixServiceUrls', {});
      if (response.success) {
        setFixMessage(`✅ ${response.message || 'Service URLs fixed successfully!'} Page will reload in 2 seconds...`);
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        setFixMessage(`❌ Error: ${response.error}`);
      }
    } catch (error) {
      setFixMessage(`❌ Failed to fix service URLs: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsFixingUrls(false);
    }
  };

  return (
    <div className={styles.optionsContainer}>
      <h2>Advanced Settings</h2>
      <p>Manage detailed extension settings and configurations.</p>
      
      <div style={{ marginBottom: '20px' }}>
        <Button onClick={() => setIsModalOpen(true)}>Open Settings</Button>
      </div>

      <div style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ccc', borderRadius: '5px' }}>
        <h3>🔧 Service Configuration</h3>
        <p>Fix service connection issues and URL configuration problems.</p>
        
        <div style={{ marginBottom: '15px' }}>
          <h4>Fix Service URLs</h4>
          <p style={{ fontSize: '14px', color: '#666', marginBottom: '10px' }}>
            Automatically fix common URL configuration issues (e.g., Ollama services pointing to Open WebUI ports).
          </p>
          <Button 
            onClick={handleFixServiceUrls}
            disabled={isFixingUrls}
            style={{ backgroundColor: '#4CAF50', color: 'white', marginRight: '10px' }}
          >
            {isFixingUrls ? 'Fixing URLs...' : 'Fix Service URLs'}
          </Button>
          {fixMessage && (
            <div style={{ marginTop: '10px', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '3px' }}>
              {fixMessage}
            </div>
          )}
        </div>

        <div>
          <h4>Reset All Services</h4>
          <p style={{ fontSize: '14px', color: '#666', marginBottom: '10px' }}>
            Reset all service configurations to their default values. This will remove all custom services.
          </p>
          <Button 
            onClick={handleResetServices}
            disabled={isResetting}
            style={{ backgroundColor: '#ff6b6b', color: 'white' }}
          >
            {isResetting ? 'Resetting...' : 'Reset All Services'}
          </Button>
          {resetMessage && (
            <div style={{ marginTop: '10px', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '3px' }}>
              {resetMessage}
            </div>
          )}
        </div>
      </div>

      <AdvancedSettingsModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
};

export default AdvancedSettingsPage; 
import { SERVICE_CATEGORIES } from './constants';
import type { Service } from '@/types';

// Local and remote IP addresses
const LOCAL_IP = '192.168.1.159';
const REMOTE_IP = '192.168.1.180';

export const DEFAULT_SERVICES: Service[] = [
  // Local services
  {
    id: 'default_ollama_local',
    name: 'Ollama (Local)',
    type: 'ollama',
    url: `http://${LOCAL_IP}:11434`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.LLM,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_openwebui_local',
    name: 'Open WebUI (Local)',
    type: 'open-webui',
    url: `http://${LOCAL_IP}:3000`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.LLM,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_a1111_local',
    name: 'A1111 (Local)',
    type: 'a1111',
    url: `http://${LOCAL_IP}:7860`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.IMAGE_GENERATION,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_comfyui_local',
    name: 'ComfyUI (Local)',
    type: 'comfy-ui',
    url: `http://${LOCAL_IP}:8188`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.IMAGE_GENERATION,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  
  // Remote services
  {
    id: 'default_ollama_remote',
    name: 'Ollama (Remote)',
    type: 'ollama',
    url: `http://${REMOTE_IP}:11434`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.LLM,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_openwebui_remote',
    name: 'Open WebUI (Remote)',
    type: 'open-webui',
    url: `http://${REMOTE_IP}:3000`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.LLM,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_a1111_remote',
    name: 'A1111 (Remote)',
    type: 'a1111',
    url: `http://${REMOTE_IP}:7860`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.IMAGE_GENERATION,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_comfyui_remote',
    name: 'ComfyUI (Remote)',
    type: 'comfy-ui',
    url: `http://${REMOTE_IP}:8188`,
    enabled: true,
    status: 'unknown',
    category: SERVICE_CATEGORIES.IMAGE_GENERATION,
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  }
]; 
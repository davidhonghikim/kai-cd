import { 
  SERVICE_DEFINITIONS, 
  SERVICE_CATEGORIES, 
  getServiceDefinition,
  getServiceTypesByCategory,
  type ServiceType,
  type ServiceCategory,
  type ServiceDefinition
} from './constants';

// Service metadata extends ServiceDefinition with additional UI-specific properties
export interface ServiceMetadata extends ServiceDefinition {
  id: string;
  features: string[];
  defaultHeaders?: Record<string, string>;
}

// Enhanced metadata with additional features for each service
const SERVICE_ENHANCED_METADATA: Record<string, Partial<ServiceMetadata>> = {
  ollama: {
    features: [
      'Local model inference',
      'Model management',
      'Streaming responses',
      'Embedding generation'
    ]
  },
  'open-webui': {
    features: [
      'Web-based chat interface',
      'Multiple model support',
      'Conversation history',
      'User management'
    ]
  },
  a1111: {
    features: [
      'Text-to-image generation',
      'Image-to-image',
      'Inpainting',
      'Upscaling',
      'Model management'
    ]
  },
  'comfy-ui': {
    features: [
      'Node-based workflow editor',
      'Custom workflows',
      'Batch processing',
      'Model management'
    ]
  },
  'llama-cpp': {
    features: [
      'High-performance inference',
      'OpenAI-compatible API',
      'Streaming support',
      'Low memory usage'
    ]
  },
  vllm: {
    features: [
      'High-throughput serving',
      'Tensor parallelism',
      'Continuous batching',
      'OpenAI compatibility'
    ]
  },
  'llm-studio': {
    features: [
      'Model fine-tuning',
      'Dataset management',
      'Model evaluation',
      'Easy deployment'
    ]
  },
  'openai-compatible': {
    features: [
      'OpenAI API compatibility',
      'Multiple providers',
      'Streaming support',
      'Function calling'
    ]
  },
  openai: {
    features: [
      'GPT models',
      'Function calling',
      'Vision capabilities',
      'Code generation'
    ]
  },
  anthropic: {
    features: [
      'Claude models',
      'Constitutional AI',
      'Long context windows',
      'Reasoning capabilities'
    ]
  },
  n8n: {
    features: [
      'Workflow automation',
      'Webhook support',
      'Integration with 200+ services',
      'Visual workflow builder'
    ]
  },
  tailscale: {
    features: [
      'Secure remote access',
      'Device management',
      'Network monitoring',
      'ACL controls'
    ]
  },
  custom: {
    features: [
      'Custom configuration',
      'Flexible integration'
    ]
  }
};

/**
 * Get enhanced service metadata by combining SERVICE_DEFINITIONS with additional features
 */
export function getServiceMetadata(serviceType: ServiceType): ServiceMetadata {
  const baseDef = getServiceDefinition(serviceType);
  if (!baseDef) {
    throw new Error(`Unknown service type: ${serviceType}`);
  }

  const enhanced = SERVICE_ENHANCED_METADATA[serviceType] || {};
  
  return {
    ...baseDef,
    id: baseDef.type,
    features: enhanced.features || [],
    defaultHeaders: enhanced.defaultHeaders
  };
}

/**
 * Get all services metadata for a specific category
 */
export function getServicesByCategory(category: ServiceCategory): ServiceMetadata[] {
  return getServiceTypesByCategory(category).map(def => getServiceMetadata(def.type));
}

/**
 * Get all LLM services
 */
export function getLLMServices(): ServiceMetadata[] {
  return getServicesByCategory(SERVICE_CATEGORIES.LLM);
}

/**
 * Get all image generation services
 */
export function getImageServices(): ServiceMetadata[] {
  return getServicesByCategory(SERVICE_CATEGORIES.IMAGE_GENERATION);
}

/**
 * Get all automation services
 */
export function getAutomationServices(): ServiceMetadata[] {
  return getServicesByCategory(SERVICE_CATEGORIES.AUTOMATION);
}

/**
 * Get all network services
 */
export function getNetworkServices(): ServiceMetadata[] {
  return getServicesByCategory(SERVICE_CATEGORIES.NETWORK);
}

/**
 * Get all custom services
 */
export function getCustomServices(): ServiceMetadata[] {
  return getServicesByCategory(SERVICE_CATEGORIES.CUSTOM);
}

/**
 * Get all available service metadata
 */
export function getAllServices(): ServiceMetadata[] {
  return Object.values(SERVICE_DEFINITIONS).map(def => getServiceMetadata(def.type));
}

/**
 * Check if a service type exists
 */
export function isValidServiceType(serviceType: string): serviceType is ServiceType {
  return getServiceDefinition(serviceType) !== undefined;
}

/**
 * Get services that support streaming
 */
export function getStreamingServices(): ServiceMetadata[] {
  return getAllServices().filter(service => service.supportsStreaming);
}

/**
 * Get services that support templates
 */
export function getTemplateServices(): ServiceMetadata[] {
  return getAllServices().filter(service => service.supportsTemplates);
}

/**
 * Get services that require API keys
 */
export function getApiKeyServices(): ServiceMetadata[] {
  return getAllServices().filter(service => service.requiresApiKey);
}

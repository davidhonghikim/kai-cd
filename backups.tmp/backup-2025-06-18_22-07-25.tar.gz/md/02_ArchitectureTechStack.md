# Kai CD: Architecture & Technology Stack

This document outlines the architecture and technology stack for Kai CD, a browser extension for managing and interacting with various AI services.

## System Architecture

Kai CD is designed as a modular browser extension to minimize complexity and maximize maintainability.

*   **Background Script (`/src/background`)**: The central nervous system. Manages state, handles API calls, and orchestrates communication between different parts of the extension.
*   **UI (Vanilla JS/HTML/CSS or React):** The user interface is purposefully lightweight.
*   **Service Connectors:** Individual modules responsible for communicating with specific AI services. Each connector implements a consistent interface for easy integration.
*   **Storage:**
    *   IndexedDB: Used for storing extension settings, service configurations, and potentially cached data.
    *   LocalStorage: Used for smaller pieces of data.
*   **Content Scripts**: (If any) Injected into web pages to interact with their content.
*   **UI Components (`/src/components`)**: Reusable React components that make up the user interface.

**Data Flow:**

1.  User interacts with the UI.
2.  The UI sends a request to the background script.
3.  The background script routes the request to the appropriate service connector.
4.  The service connector communicates with the remote AI service via its API.
5.  The response is processed by the service connector and returned to the background script.
6.  The background script updates the UI with the response.
7.  Generated artifacts (images, chat logs) are optionally stored.

**Tech Stack:**

*   **JavaScript/HTML/CSS or React**:  For the browser extension UI.
*   **TypeScript**: Enforces strong typing and improves code maintainability.
*   **Node.js/npm**: For build tooling and dependency management.
*   **Vite or Webpack**: For bundling the extension code.
*   **IndexedDB Libraries:** Libraries for working with IndexedDB.

**Security:**

*   Enforce HTTPS for all API communication.
*   Securely store API keys using browser extension storage APIs and encryption.
*   Implement input validation and output sanitization to prevent security vulnerabilities.
*   Carefully manage iframe content and communication to prevent cross-site scripting (XSS) attacks.

**Extensibility:**

*   The modular connector design enables easy integration of new services.

### Core UI Views

The extension's user interface is divided into three primary views, each with a distinct role:

- **Popup (`/src/popup`)**: The main controller and entry point. When you click the extension icon, the popup appears. Its sole purpose is to act as a launcher. It displays a list of all configured services and provides buttons to open a service in either the Side Panel or a new Tab. It also provides a link to the main settings page.

- **Side Panel (`/src/sidepanel`)**: The primary chat interface. It's designed for quick, in-context interactions alongside your current web page. It features a condensed view of the chat interface, but uses the same underlying settings as the tab view. You can switch any service from the popup into the side panel.

- **Tab (`/src/tab`)**: The full-featured, immersive view. When a service is opened in a tab, it provides the most screen real estate and is intended for more in-depth work. 
  - For API-only services (like Ollama), it displays our custom, feature-rich chat interface that is designed to emulate the UI/UX of tools like Open WebUI.
  - For services that have their own web interface (like Open WebUI itself or n8n), the tab will render that service's full UI within an `<iframe>`.
  - The header of the tab view will always display the name and clickable URL of the service currently being used.

This separation of concerns allows for a flexible and powerful user experience, accommodating quick chats, deep work, and interaction with external service UIs all within a single extension.

## Technology Stack

### Frontend

*   **JavaScript/HTML/CSS or React**:  For the browser extension UI.
*   **TypeScript**: Enforces strong typing and improves code maintainability.
*   **Node.js/npm**: For build tooling and dependency management.
*   **Vite or Webpack**: For bundling the extension code.
*   **IndexedDB Libraries:** Libraries for working with IndexedDB.
import React, { useEffect, useState } from 'react';
import { connectToBackground } from '@/utils/keepAlive';
import { sendMessage } from '@/utils/chrome';
import ViewRouter from '@/components/ViewRouter';
import ViewHeader from '@/components/ViewHeader';
import { Service } from '@/types';
import '@/styles/global.css';
import styles from '@/styles/components/sidepanel/SidePanel.module.css';

const SidePanel: React.FC = () => {
  const [activeService, setActiveService] = useState<Service | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    connectToBackground('sidepanel');

    const getActiveService = async () => {
      try {
        setIsLoading(true);
        const response = await sendMessage('getActiveService', undefined);
        if (response?.success && response.service) {
          setActiveService(response.service);
        } else {
          setError(response?.error || 'No active service found.');
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to get active service.');
      } finally {
        setIsLoading(false);
      }
    };

    getActiveService();
  }, []);

  const renderContent = () => {
    if (isLoading) {
      return <div className={styles.loadingState}>Loading...</div>;
    }
    if (error) {
      return <div className={styles.errorState}>Error: {error}</div>;
    }
    if (!activeService) {
      return <div className={styles.emptyState}>No service selected. Please select a service from the popup.</div>;
    }
    return (
      <>
        <ViewHeader service={activeService} isTab={false} />
        <div className={styles.contentContainer}>
          <ViewRouter service={activeService} isTab={false} />
        </div>
      </>
    );
  };

  return (
    <div className={styles.sidePanelContainer}>
      {renderContent()}
    </div>
  );
};

export default SidePanel;
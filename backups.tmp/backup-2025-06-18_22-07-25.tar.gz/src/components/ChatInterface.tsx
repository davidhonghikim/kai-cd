import React from 'react';
import { ChatMessage, LLMModel } from '@/types';
import MessageList from './MessageList';
import ChatInput from './ChatInput';
import styles from '@/styles/components/ChatInterface.module.css';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  models: LLMModel[];
  selectedModel: string;
  onSendMessage: (message: string, model: string) => void;
  onModelChange: (modelId: string) => void;
  isLoading: boolean;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({
  messages,
  models,
  selectedModel,
  onSendMessage,
  onModelChange,
  isLoading,
}) => {
  // Placeholder functions to satisfy MessageListProps
  const handleEdit = () => console.log('Edit action triggered');
  const handleCopy = () => console.log('Copy action triggered');
  const handleContinue = () => console.log('Continue action triggered');
  const handleRegenerate = () => console.log('Regenerate action triggered');
  const handleRate = () => console.log('Rate action triggered');
  const handleGenerateImage = () => console.log('Generate image action triggered');
  const handleReadAloud = () => console.log('Read aloud action triggered');
  const handleDelete = () => console.log('Delete action triggered');
  const handleStop = () => console.log('Stop action triggered');

  return (
    <div className={styles.chatContainer}>
      <MessageList
        messages={messages}
        isLoading={isLoading}
        onEdit={handleEdit}
        onCopy={handleCopy}
        onContinue={handleContinue}
        onRegenerate={handleRegenerate}
        onRate={handleRate}
        onGenerateImage={handleGenerateImage}
        onReadAloud={handleReadAloud}
        onDelete={handleDelete}
        onStopGeneration={handleStop}
      />
      <ChatInput
        onSendMessage={onSendMessage}
        models={models}
        selectedModel={selectedModel}
        onModelChange={onModelChange}
        isLoading={isLoading}
      />
    </div>
  );
};

export default ChatInterface;
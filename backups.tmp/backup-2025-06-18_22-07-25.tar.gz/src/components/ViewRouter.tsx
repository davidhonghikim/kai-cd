import React from 'react';
import { Service } from '@/types';
import ChatView from '../views/ChatView';
import A1111View from '../views/A1111View';
import ComfyUIView from '../views/ComfyUIView';
// We'll use string literals directly instead of constants

interface ViewRouterProps {
  service: Service;
  isTab?: boolean;
}

const IframeView: React.FC<{ service: Service }> = ({ service }) => (
  <iframe
    src={service.url}
    style={{ width: '100%', height: '100%', border: 'none' }}
    title={service.name}
  />
);

const ViewRouter: React.FC<ViewRouterProps> = ({ service, isTab = false }) => {
  if (!service) {
    return <div>No active service selected.</div>;
  }

  // In a tab, always use the IframeView for services that have a UI
  if (isTab) {
    const servicesWithNativeUI: Service['type'][] = ['open-webui', 'a1111', 'comfy-ui', 'n8n'];
    if (servicesWithNativeUI.includes(service.type)) {
      return <IframeView service={service} />;
    }
    return <ChatView service={service} />;
  }

  // In the side panel, use specific components
  switch (service.type) {
    case 'ollama':
    case 'openai':
    case 'openai-compatible':
      return <ChatView service={service} />;
    case 'a1111':
      return <A1111View service={service} />;
    case 'comfy-ui':
      return <ComfyUIView service={service} />;
    case 'open-webui':
    case 'n8n':
      return <IframeView service={service} />;
    default:
      return <IframeView service={service} />;
  }
};

export default ViewRouter;

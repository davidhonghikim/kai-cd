// Service Definition Interface
export interface ServiceDefinition {
  type: string;
  displayName: string;
  category: string;
  description: string;
  icon: string;
  defaultPort: number;
  defaultPath: string;
  requiresApiKey: boolean;
  supportsStreaming: boolean;
  supportsTemplates: boolean;
  healthCheckPath?: string;
}

// Consolidated Service Definitions - Single Source of Truth
export const SERVICE_DEFINITIONS: Record<string, ServiceDefinition> = {
  ollama: {
    type: 'ollama',
    displayName: 'Ollama',
    category: 'LLM',
    description: 'Run large language models locally with Ollama',
    icon: '🦙',
    defaultPort: 11434,
    defaultPath: '',
    requiresApiKey: false,
    supportsStreaming: true,
    supportsTemplates: true,
    healthCheckPath: '/api/tags'
  },
  open_webui: {
    type: 'open-webui',
    displayName: 'Open WebUI',
    category: 'LLM',
    description: 'Web-based interface for interacting with LLMs',
    icon: '🌐',
    defaultPort: 3000,
    defaultPath: '',
    requiresApiKey: false,
    supportsStreaming: true,
    supportsTemplates: true
  },
  a1111: {
    type: 'a1111',
    displayName: 'Automatic1111',
    category: 'IMAGE_GENERATION',
    description: 'Stable Diffusion web UI with a feature-rich interface',
    icon: '🎨',
    defaultPort: 7860,
    defaultPath: '',
    requiresApiKey: false,
    supportsStreaming: false,
    supportsTemplates: false,
    healthCheckPath: '/sdapi/v1/progress'
  },
  comfy_ui: {
    type: 'comfy-ui',
    displayName: 'ComfyUI',
    category: 'IMAGE_GENERATION',
    description: 'Node-based UI for Stable Diffusion with advanced workflows',
    icon: '🎛️',
    defaultPort: 8188,
    defaultPath: '',
    requiresApiKey: false,
    supportsStreaming: false,
    supportsTemplates: true,
    healthCheckPath: '/'
  },
  llama_cpp: {
    type: 'llama-cpp',
    displayName: 'Llama.cpp',
    category: 'LLM',
    description: 'LLaMA model inference in C/C++',
    icon: '🦙',
    defaultPort: 8080,
    defaultPath: '/v1',
    requiresApiKey: false,
    supportsStreaming: true,
    supportsTemplates: true
  },
  vllm: {
    type: 'vllm',
    displayName: 'vLLM',
    category: 'LLM',
    description: 'High-throughput and memory-efficient LLM serving',
    icon: '⚡',
    defaultPort: 8000,
    defaultPath: '/v1',
    requiresApiKey: false,
    supportsStreaming: true,
    supportsTemplates: true
  },
  llm_studio: {
    type: 'llm-studio',
    displayName: 'LLM Studio',
    category: 'LLM',
    description: 'Fine-tune and serve LLMs with an easy-to-use interface',
    icon: '🎓',
    defaultPort: 1234,
    defaultPath: '/v1',
    requiresApiKey: false,
    supportsStreaming: true,
    supportsTemplates: true
  },
  openai_compatible: {
    type: 'openai-compatible',
    displayName: 'OpenAI Compatible',
    category: 'LLM',
    description: 'Any service with an OpenAI-compatible API',
    icon: '🔌',
    defaultPort: 443,
    defaultPath: '/v1',
    requiresApiKey: true,
    supportsStreaming: true,
    supportsTemplates: true
  },
  openai: {
    type: 'openai',
    displayName: 'OpenAI',
    category: 'LLM',
    description: 'Official OpenAI API service',
    icon: '🔗',
    defaultPort: 443,
    defaultPath: '/v1',
    requiresApiKey: true,
    supportsStreaming: true,
    supportsTemplates: true
  },
  anthropic: {
    type: 'anthropic',
    displayName: 'Anthropic',
    category: 'LLM',
    description: 'Anthropic Claude API service',
    icon: '📚',
    defaultPort: 443,
    defaultPath: '/v1',
    requiresApiKey: true,
    supportsStreaming: true,
    supportsTemplates: true
  },
  n8n: {
    type: 'n8n',
    displayName: 'n8n',
    category: 'AUTOMATION',
    description: 'Workflow automation platform with a wide range of integrations',
    icon: '🔄',
    defaultPort: 5678,
    defaultPath: '/api',
    requiresApiKey: true,
    supportsStreaming: false,
    supportsTemplates: false,
    healthCheckPath: '/healthz'
  },
  tailscale: {
    type: 'tailscale',
    displayName: 'Tailscale',
    category: 'NETWORK',
    description: 'Zero-config VPN for secure access to devices and services',
    icon: '🔒',
    defaultPort: 443,
    defaultPath: '/api/v2',
    requiresApiKey: true,
    supportsStreaming: false,
    supportsTemplates: false
  },
  custom: {
    type: 'custom',
    displayName: 'Custom',
    category: 'CUSTOM',
    description: 'Custom service',
    icon: '⚙️',
    defaultPort: 0,
    defaultPath: '',
    requiresApiKey: false,
    supportsStreaming: false,
    supportsTemplates: false
  }
};

// Export backward-compatible utility constants derived from SERVICE_DEFINITIONS
export const SERVICE_TYPES = Object.fromEntries(
  Object.entries(SERVICE_DEFINITIONS).map(([key, value]) => [key.toUpperCase(), value.type])
) as { [key: string]: string };

export const SERVICE_CATEGORIES = {
  LLM: 'LLM',
  IMAGE_GENERATION: 'IMAGE_GENERATION',
  AUTOMATION: 'AUTOMATION',
  NETWORK: 'NETWORK',
  CUSTOM: 'CUSTOM'
} as const;

export type ServiceType = string;
export type ServiceCategory = typeof SERVICE_CATEGORIES[keyof typeof SERVICE_CATEGORIES];

// Default host configuration
export const DEFAULT_HOST = '192.168.1.180';

// Helper function to get default service URL
export const getDefaultServiceUrl = (type: string, host: string = 'localhost'): string => {
  const serviceDef = SERVICE_DEFINITIONS[type] || Object.values(SERVICE_DEFINITIONS).find(def => def.type === type);
  if (!serviceDef) {
    console.warn(`No service definition found for type: ${type}`);
    return '';
  }
  const port = serviceDef.defaultPort;
  const path = serviceDef.defaultPath;
  const protocol = port === 443 ? 'https' : 'http';
  return `${protocol}://${host}:${port}${path}`;
};

// Helper function to get health check path
export const getHealthCheckPath = (type: string): string | undefined => {
  const serviceDef = SERVICE_DEFINITIONS[type] || Object.values(SERVICE_DEFINITIONS).find(def => def.type === type);
  return serviceDef?.healthCheckPath;
};

// Helper function to get service definition by type
export const getServiceDefinition = (type: string): ServiceDefinition | undefined => {
  return SERVICE_DEFINITIONS[type] || Object.values(SERVICE_DEFINITIONS).find(def => def.type === type);
};

// Helper function to get all service types by category
export const getServiceTypesByCategory = (category: string): ServiceDefinition[] => {
  return Object.values(SERVICE_DEFINITIONS).filter(def => def.category === category);
};

// Default Services Configuration - using the new structure
export const DEFAULT_SERVICES = [
  // Local Services
  {
    id: 'default_ollama_local',
    name: 'Ollama (Local)',
    type: 'ollama',
    url: getDefaultServiceUrl('ollama', 'localhost'),
    enabled: true,
    status: 'unknown' as const,
    category: 'LLM',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_open_webui_local',
    name: 'Open WebUI (Local)',
    type: 'open-webui',
    url: getDefaultServiceUrl('open-webui', 'localhost'),
    enabled: true,
    status: 'unknown' as const,
    category: 'LLM',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_a1111_local',
    name: 'A1111 (Local)',
    type: 'a1111',
    url: getDefaultServiceUrl('a1111', 'localhost'),
    enabled: true,
    status: 'unknown' as const,
    category: 'IMAGE_GENERATION',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_comfy_ui_local',
    name: 'ComfyUI (Local)',
    type: 'comfy-ui',
    url: getDefaultServiceUrl('comfy-ui', 'localhost'),
    enabled: true,
    status: 'unknown' as const,
    category: 'IMAGE_GENERATION',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  // Remote Services
  {
    id: 'default_ollama_remote',
    name: 'Ollama (Remote)',
    type: 'ollama',
    url: getDefaultServiceUrl('ollama', DEFAULT_HOST),
    enabled: true,
    status: 'unknown' as const,
    category: 'LLM',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_open_webui_remote',
    name: 'Open WebUI (Remote)',
    type: 'open-webui',
    url: getDefaultServiceUrl('open-webui', DEFAULT_HOST),
    enabled: true,
    status: 'unknown' as const,
    category: 'LLM',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_a1111_remote',
    name: 'A1111 (Remote)',
    type: 'a1111',
    url: getDefaultServiceUrl('a1111', DEFAULT_HOST),
    enabled: true,
    status: 'unknown' as const,
    category: 'IMAGE_GENERATION',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  },
  {
    id: 'default_comfy_ui_remote',
    name: 'ComfyUI (Remote)',
    type: 'comfy-ui',
    url: getDefaultServiceUrl('comfy-ui', DEFAULT_HOST),
    enabled: true,
    status: 'unknown' as const,
    category: 'IMAGE_GENERATION',
    requiresApiKey: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isActive: false
  }
];

// Backward compatibility exports - these will be deprecated
export const SERVICE_DEFAULT_PORTS = Object.fromEntries(
  Object.values(SERVICE_DEFINITIONS).map(def => [def.type, def.defaultPort])
);

export const SERVICE_API_PATHS = Object.fromEntries(
  Object.values(SERVICE_DEFINITIONS).map(def => [def.type, def.defaultPath])
);

export const SERVICE_DISPLAY_NAMES = Object.fromEntries(
  Object.values(SERVICE_DEFINITIONS).map(def => [def.type, def.displayName])
);

export const SERVICE_ICONS = Object.fromEntries(
  Object.values(SERVICE_DEFINITIONS).map(def => [def.type, def.icon])
);

export const HEALTH_CHECK_PATHS = Object.fromEntries(
  Object.values(SERVICE_DEFINITIONS)
    .filter(def => def.healthCheckPath)
    .map(def => [def.type, def.healthCheckPath!])
);

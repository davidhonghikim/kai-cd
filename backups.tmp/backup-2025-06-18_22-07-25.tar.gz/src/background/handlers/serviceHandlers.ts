/* eslint-disable @typescript-eslint/no-unused-vars */
import { storageManager } from '@/storage/storageManager';
import { SERVERS_KEY } from '@/utils/settingsIO';
import { Service } from '@/types';
// @ts-ignore
import { v4 as uuidv4 } from 'uuid';
import { RequestHandler } from './types';
import { getStoredServices } from '../utils/storage';
import { connectorManager } from '../connectors';
import { DEFAULT_SERVICES } from '@/config/defaults';

export const getServicesHandler: RequestHandler<undefined, { success: boolean, services: Service[], error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    sendResponse({ success: true, services });
  } catch (error) {
    sendResponse({ success: false, services: [], error: 'Failed to get services' });
  }
};

export const addServiceHandler: RequestHandler<Partial<Service>, { success: boolean, data: Service, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const newService: Service = {
      id: uuidv4(),
      name: payload.name || 'New Service',
      type: payload.type || 'ollama',
      url: payload.url || '',
      apiKey: payload.apiKey,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      status: 'unknown',
      category: payload.category || 'LLM',
      requiresApiKey: payload.requiresApiKey || false,
      enabled: payload.enabled === undefined ? true : payload.enabled,
      isActive: false,
    };
    const updatedServices = [newService, ...services];
    await storageManager.set(SERVERS_KEY, updatedServices);
    sendResponse({ success: true, data: newService });
  } catch (error) {
    sendResponse({ success: false, data: {} as Service, error: 'Failed to add service' });
  }
};

export const updateServiceHandler: RequestHandler<Service, { success: boolean, service: Service, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const index = services.findIndex(s => s.id === payload.id);
    if (index === -1) {
      throw new Error('Service not found');
    }
    const updatedServices = [...services];
    updatedServices[index] = payload;
    await storageManager.set(SERVERS_KEY, updatedServices);
    sendResponse({ success: true, service: payload });
  } catch (error) {
    sendResponse({ success: false, service: {} as Service, error: 'Failed to update service' });
  }
};

export const removeServiceHandler: RequestHandler<{ id: string }, { success: boolean, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const updatedServices = services.filter(s => s.id !== payload.id);
    await storageManager.set(SERVERS_KEY, updatedServices);
    connectorManager.removeConnector(payload.id);
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: 'Failed to delete service' });
  }
};

export const checkServiceStatusHandler: RequestHandler<{ serviceId: string }, { success: boolean, status: any, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const service = services.find(s => s.id === payload.serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    const connector = await connectorManager.getConnector(service);
    if (!connector || !('checkStatus' in connector)) {
      throw new Error('Connector does not support status checking');
    }
    const status = await (connector as any).checkStatus();
    sendResponse({ success: true, status });
  } catch (error) {
    sendResponse({ success: false, status: null, error: 'Failed to check service status' });
  }
};

export const getServiceHandler: RequestHandler<{ serviceId: string }, { success: boolean, service?: Service, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const service = services.find(s => s.id === payload.serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    sendResponse({ success: true, service });
  } catch (error) {
    sendResponse({ success: false, error: 'Failed to get service' });
  }
};

/**
 * Reset all services to default configurations with correct URLs
 */
export const resetServicesHandler: RequestHandler<void, { success: boolean; message?: string; error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    console.log('[ServiceHandlers] Resetting services to defaults...');
    
    // Get current services for logging
    const currentServices = await storageManager.get<Service[]>(SERVERS_KEY, []);
    console.log('[ServiceHandlers] Current services:', currentServices.map(s => ({ name: s.name, url: s.url })));
    
    // Reset to default services with correct URLs
    const resetServices = DEFAULT_SERVICES.map(service => ({
      ...service,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }));
    
    await storageManager.set(SERVERS_KEY, resetServices);
    
    // Clear active service to reset
    await storageManager.set('activeService', null);
    
    console.log('[ServiceHandlers] Services reset successfully');
    console.log('[ServiceHandlers] New services:', resetServices.map(s => ({ name: s.name, url: s.url })));
    
    sendResponse({ 
      success: true, 
      message: `Reset ${resetServices.length} services to default configurations with correct URLs` 
    });
  } catch (error) {
    console.error('[ServiceHandlers] Error resetting services:', error);
    sendResponse({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
};

/**
 * Fix common service URL configuration issues
 */
export const fixServiceUrlsHandler: RequestHandler<void, { success: boolean; message?: string; error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    console.log('[ServiceHandlers] Fixing service URL configurations...');
    
    const services = await storageManager.get<Service[]>(SERVERS_KEY, []);
    console.log('[ServiceHandlers] Current services:', services.map(s => ({ name: s.name, type: s.type, url: s.url })));
    
    let fixedCount = 0;
    const fixedServices = services.map(service => {
      let needsFix = false;
      const originalUrl = service.url;
      let newUrl = service.url;
      
      // Fix Ollama services pointing to port 3000 (Open WebUI) instead of 11434 (Ollama API)
      if (service.type === 'ollama' && service.url.includes(':3000')) {
        newUrl = service.url.replace(':3000', ':11434');
        needsFix = true;
        console.log(`[ServiceHandlers] Fixed Ollama service ${service.name}: ${originalUrl} → ${newUrl}`);
      }
      
      // Fix Open WebUI services pointing to wrong ports
      if (service.type === 'open-webui' && service.url.includes(':11434')) {
        newUrl = service.url.replace(':11434', ':3000');
        needsFix = true;
        console.log(`[ServiceHandlers] Fixed Open WebUI service ${service.name}: ${originalUrl} → ${newUrl}`);
      }
      
      // Fix A1111 services with incorrect ports
      if (service.type === 'a1111') {
        if (!service.url.includes(':7860') && !service.url.includes('/api')) {
          // Default A1111 setup
          const baseUrl = service.url.replace(/:\d+.*$/, '');
          newUrl = `${baseUrl}:7860`;
          needsFix = true;
          console.log(`[ServiceHandlers] Fixed A1111 service ${service.name}: ${originalUrl} → ${newUrl}`);
        }
      }
      
      // Fix ComfyUI services with incorrect ports
      if (service.type === 'comfy-ui') {
        if (!service.url.includes(':8188')) {
          const baseUrl = service.url.replace(/:\d+.*$/, '');
          newUrl = `${baseUrl}:8188`;
          needsFix = true;
          console.log(`[ServiceHandlers] Fixed ComfyUI service ${service.name}: ${originalUrl} → ${newUrl}`);
        }
      }
      
      if (needsFix) {
        fixedCount++;
        return {
          ...service,
          url: newUrl,
          updatedAt: Date.now(),
        };
      }
      
      return service;
    });
    
    if (fixedCount > 0) {
      await storageManager.set(SERVERS_KEY, fixedServices);
      console.log(`[ServiceHandlers] Fixed ${fixedCount} service URL(s)`);
      
      sendResponse({ 
        success: true, 
        message: `Fixed ${fixedCount} service URL(s) with incorrect configurations` 
      });
    } else {
      console.log('[ServiceHandlers] All service URLs are correctly configured');
      sendResponse({ 
        success: true, 
        message: 'All service URLs are correctly configured - no fixes needed' 
      });
    }
    
  } catch (error) {
    console.error('[ServiceHandlers] Error fixing service URLs:', error);
    sendResponse({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
};

export const serviceHandlers = {
  getServices: getServicesHandler,
  getService: getServiceHandler,
  addService: addServiceHandler,
  updateService: updateServiceHandler,
  removeService: removeServiceHandler,
  checkServiceStatus: checkServiceStatusHandler,
  resetServices: resetServicesHandler,
  fixServiceUrls: fixServiceUrlsHandler,
}; 
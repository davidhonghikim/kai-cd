/* eslint-disable @typescript-eslint/no-unused-vars */
import { connectorManager } from '../connectors';
import { getStoredServices } from '../utils/storage';
import { ChatMessage } from '@/types';

interface StreamChatPayload {
  serviceId: string;
  messages: ChatMessage[];
  model: string;
}

export async function handleStreamChat(payload: StreamChatPayload, port: chrome.runtime.Port): Promise<void> {
  try {
    const { serviceId, messages, model } = payload;
    
    // Get the service
    const services = await getStoredServices();
    const service = services.find(s => s.id === serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    
    // Get the connector
    const connector = await connectorManager.getConnector(service);
    if (!connector) {
      throw new Error('Connector not available');
    }
    
    // Check if connector supports streaming
    if (!('generateChatCompletion' in connector)) {
      throw new Error('Connector does not support chat completion');
    }
    
    // Start streaming
    console.log(`Starting stream for service ${service.name} with model ${model}`);
    
    const streamingConnector = connector as any;
    await streamingConnector.generateChatCompletion({
      messages,
      model,
      stream: true,
      onChunk: (chunk: string) => {
        port.postMessage({
          action: 'streamChunk',
          payload: chunk
        });
      }
    });
    
    // Send end signal
    port.postMessage({
      action: 'streamEnd',
      payload: null
    });
    
  } catch (error) {
    console.error('Stream chat error:', error);
    port.postMessage({
      action: 'streamError',
      payload: error instanceof Error ? error.message : 'Unknown streaming error'
    });
  }
} 
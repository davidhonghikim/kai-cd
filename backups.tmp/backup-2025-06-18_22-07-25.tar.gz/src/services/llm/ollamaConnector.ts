import type { Service, ChatMessage, CompletionRequest, EmbeddingRequest, CompletionResponse, EmbeddingResponse, LLMModel, GenerationParams, ChatConnector, ChatSession, ChatCompletionResponse } from '@/types';
import { BaseConnector } from '../base/BaseConnector';

interface OllamaModel {
  name: string;
  modified_at: string;
  size: number;
}

export class OllamaConnector extends BaseConnector implements ChatConnector {
  private abortController: AbortController | null = null;

  constructor(service: Service) {
    super(service);
  }
  
  private log(message: string, ...args: any[]) {
    console.log(`[OllamaConnector] ${message}`, ...args);
  }

  async connect(): Promise<boolean> {
    // Try to fetch models as a connectivity check
    try {
      await this.getModels();
      return true;
    } catch {
      return false;
    }
  }

  async disconnect(): Promise<void> {
    // Disconnect implementation
  }

  async checkStatus(): Promise<{ isOnline: boolean; details?: any; error?: string }> {
    try {
      await this.getModels();
      return { isOnline: true, details: this.service };
    } catch (error) {
      return { isOnline: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  private async fetchWithAuth(path: string, options: RequestInit = {}, signal?: AbortSignal): Promise<Response> {
    const url = new URL(path, this.service.url).toString();
    const headers = new Headers({
      'User-Agent': 'ChatDemon-Extension/1.0',
      'Accept': 'application/json',
      'Accept-Language': 'en-US,en;q=0.9',
      'Content-Type': 'application/json',
    });

    if (options.headers) {
      const customHeaders = new Headers(options.headers);
      customHeaders.forEach((value, key) => {
        headers.append(key, value);
      });
    }

    const loggableHeaders: Record<string, string> = {};
    headers.forEach((value, key) => {
      loggableHeaders[key] = value;
    });

    console.log('[OllamaConnector] Making request to:', url);
    console.log('[OllamaConnector] Request method:', options.method || 'GET');
    console.log('[OllamaConnector] Request headers:', JSON.stringify(loggableHeaders));
    if (options.body) {
      console.log('[OllamaConnector] Request body:', options.body);
    }

    this.abortController = new AbortController();

    try {
      const response = await fetch(url, {
        ...options,
        headers,
        signal: signal || this.abortController.signal,
        mode: 'cors',
        credentials: 'omit'
      });

      const responseHeaders: Record<string, string> = {};
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value;
      });
      console.log('[OllamaConnector] Response received:', response.status, response.statusText);
      console.log('[OllamaConnector] Response headers:', JSON.stringify(responseHeaders));

      return response;
    } catch (error) {
      console.error('[OllamaConnector] Fetch error:', error);
      if (error instanceof Error) {
        console.error('[OllamaConnector] Error name:', error.name);
        console.error('[OllamaConnector] Error message:', error.message);
      }
      throw error;
    }
  }

  public abortRequest(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }

  async validateConfig(): Promise<{ isValid: boolean; errors?: string[]; warnings?: string[] }> {
    try {
      const response = await this.fetchWithAuth('/api/tags');
      return { isValid: response.ok };
    } catch (error) {
      return { isValid: false, errors: ['Failed to connect to Ollama service'] };
    }
  }

  async getModelStatus(): Promise<Record<string, boolean>> {
    try {
      const response = await this.fetchWithAuth('/api/tags');
      const data = await response.json();
      const models = data.models || [];
      const status: Record<string, boolean> = {};
      models.forEach((model: OllamaModel) => {
        status[model.name] = true;
      });
      return status;
    } catch (error) {
      return {};
    }
  }

  public async getModels(): Promise<LLMModel[]> {
    try {
      console.log('[OllamaConnector] Fetching models from:', `${this.service.url}/api/tags`);
      const response = await this.fetchWithAuth('/api/tags');
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('[OllamaConnector] HTTP error fetching models:', errorText);
        throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
      }
      
      const responseText = await response.text();
      console.log('[OllamaConnector] Raw response text (first 200 chars):', responseText.substring(0, 200));
      
      // Check if response looks like HTML
      if (responseText.trim().startsWith('<!') || responseText.trim().startsWith('<html')) {
        throw new Error(`Received HTML response instead of JSON from ${this.service.url}/api/tags. This suggests the URL is pointing to a web interface, not the Ollama API. Check your service URL configuration.`);
      }
      
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (parseError) {
        throw new Error(`Invalid JSON response from ${this.service.url}/api/tags: ${parseError instanceof Error ? parseError.message : 'Unknown parsing error'}`);
      }
      
      console.log('[OllamaConnector] Parsed models response:', data);
      
      const models = data.models || [];
      console.log('[OllamaConnector] Found models:', models);
      
      const mappedModels = models.map((model: OllamaModel) => ({
        id: model.name,
        name: model.name,
        provider: 'ollama',
        contextLength: 4096,
        parameters: model.size
      }));
      
      console.log('[OllamaConnector] Mapped models:', mappedModels);
      return mappedModels;
    } catch (error) {
      console.error('[OllamaConnector] Error fetching models:', error);
      console.error('[OllamaConnector] Error stack:', error instanceof Error ? error.stack : 'No stack');
      return [];
    }
  }

  async chat(messages: ChatMessage[], model: string, options?: any): Promise<ChatMessage> {
    this.abortController = new AbortController();
    
    const cleanedMessages = messages.map(({ role, content }) => ({ role, content }));
    
    const request = {
      model,
      messages: cleanedMessages,
      stream: true, // Always request stream to standardize response handling
      options: {
        temperature: 0.7,
        top_p: 0.9,
        top_k: 40,
        ...options,
      }
    };

    try {
      const response = await this.fetchWithAuth(
        '/api/chat',
        {
          method: 'POST',
          body: JSON.stringify(request),
        },
        this.abortController.signal
      );

      return await this.processResponse(response);
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        this.log('Request was aborted');
        throw new Error('Request was cancelled');
      }
      console.error('[OllamaConnector] Error in chat completion:', error);
      throw error;
    } finally {
      this.abortController = null;
    }
  }

  private async processResponse(response: Response): Promise<ChatMessage> {
    const contentType = response.headers.get('Content-Type');
    this.log(`Content-Type: ${contentType}`);

    const isStreaming = contentType?.includes('application/x-ndjson');
    this.log(`Is streaming: ${isStreaming}`);

    if (isStreaming) {
      return this.handleStreamingResponse(response);
    } else {
      this.log('Processing non-streaming response...');
      const json = await response.json();
      
      if (json.message) {
        return {
          id: `${this.service.id}-${Date.now()}`,
          role: json.message.role,
          content: json.message.content,
          timestamp: Date.now(),
        };
      } else if (json.error) {
        throw new Error(`Ollama API Error: ${json.error}`);
      } else {
        throw new Error('Invalid non-streaming response format from Ollama');
      }
    }
  }
  
  private async handleStreamingResponse(response: Response): Promise<ChatMessage> {
    this.log('Processing streaming response...');
    if (!response.body) {
      throw new Error('Response body is null');
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullContent = '';
    let finalRole: 'assistant' | 'user' | 'system' = 'assistant';
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        
        if (done) {
          if (buffer.trim()) {
            try {
              const data: ChatCompletionResponse = JSON.parse(buffer);
              if (data.message && data.message.content) {
                fullContent += data.message.content;
                finalRole = data.message.role;
              }
            } catch (e) {
              // It's fine to fail here, buffer might be incomplete
            }
          }
          break;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // keep incomplete line

        for (const line of lines) {
          if (line.trim() === '') continue;
          try {
            const data: ChatCompletionResponse = JSON.parse(line);
            if (data.message && data.message.content) {
              fullContent += data.message.content;
              finalRole = data.message.role;
            }
            if (data.done) {
              // Stream is complete. Return the final message.
              return {
                id: `${this.service.id}-${Date.now()}`,
                role: finalRole,
                content: fullContent.trim(),
                timestamp: Date.now(),
              };
            }
          } catch (e) {
            console.error('Failed to parse stream chunk:', line, e);
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
    
    // This part is reached if the stream ends without a `done: true` message
    return {
      id: `${this.service.id}-${Date.now()}`,
      role: finalRole,
      content: fullContent.trim(),
      timestamp: Date.now(),
    };
  }

  public async completion(prompt: string, model: string, options: GenerationParams = {}): Promise<string> {
    const request: CompletionRequest = {
      model: model || 'gemma3:1b',
      prompt,
      options: {
        temperature: options.temperature || 0.7,
        top_p: options.topP || 0.9,
        top_k: options.topK || 40,
        max_tokens: options.maxTokens || 2048,
        stop: options.stopSequences || []
      }
    };

    try {
      const response = await this.fetchWithAuth('/api/generate', {
        method: 'POST',
        body: JSON.stringify(request)
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: CompletionResponse = await response.json();
      return data.response || '';
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        console.log('[OllamaConnector] Request was aborted');
        throw new Error('Request was cancelled');
      }
      console.error('Error in completion:', error);
      throw error;
    }
  }

  public async embedding(text: string): Promise<number[]> {
    const model = 'gemma3:1b';
    const request: EmbeddingRequest = {
      model,
      input: text
    };

    try {
      const response = await this.fetchWithAuth('/api/embeddings', {
        method: 'POST',
        body: JSON.stringify(request)
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: EmbeddingResponse = await response.json();
      return data.embedding || [];
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        console.log('[OllamaConnector] Request was aborted');
        throw new Error('Request was cancelled');
      }
      console.error('Error in embedding:', error);
      throw error;
    }
  }

  public async tokenize(_text: string): Promise<number[]> {
    // Placeholder implementation
    return [];
  }

  public async detokenize(_tokens: number[]): Promise<string> {
    // Placeholder implementation
    return '';
  }

  // --- Placeholder methods to satisfy ChatConnector interface ---

  public async sendMessage(message: string, model: string, options?: any): Promise<ChatMessage> {
    const userMessage: ChatMessage = {
      id: `${this.service.id}-${Date.now()}`,
      role: 'user',
      content: message,
      timestamp: Date.now(),
    };
    return this.chat([userMessage], model, options);
  }

  public async clearHistory(): Promise<void> {
    console.warn('[OllamaConnector] clearHistory() is not implemented.');
    return Promise.resolve();
  }

  public async getHistory(): Promise<ChatSession[]> {
    console.warn('[OllamaConnector] getHistory() is not implemented.');
    return Promise.resolve([]);
  }

  // --- End of placeholder methods ---
}

export default OllamaConnector; 
import React, { useState, useRef, useEffect } from 'react';
import { SERVICE_TYPES, SERVICE_CATEGORIES } from '@/config/constants';
import type { Service } from '@/types';
import styles from './ServiceListItem.module.css';
import { sendMessage } from '@/utils/messaging';

interface ServiceListItemProps {
  service: Service;
  onUpdate: (service: Service) => void;
  onDelete: (id: string) => void;
  isSelecting?: boolean;
  isSelected?: boolean;
  onSelectionChange?: (id: string) => void;
  startExpanded?: boolean;
}

const ServiceListItem: React.FC<ServiceListItemProps> = ({ 
  service, 
  onUpdate, 
  onDelete, 
  isSelecting = false,
  isSelected = false,
  onSelectionChange,
  startExpanded = false
}) => {
  const [isExpanded, setIsExpanded] = useState(startExpanded);
  const [isEditing, setIsEditing] = useState(startExpanded);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [formData, setFormData] = useState<Partial<Service>>({
    name: service.name,
    url: service.url,
    type: service.type,
    enabled: service.enabled,
    status: service.status,
    category: service.category,
    requiresApiKey: service.requiresApiKey,
    apiKey: service.apiKey
  });
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const [error, setError] = useState<string | null>(null);

  // Track changes to enable/disable save button
  useEffect(() => {
    const hasChanges = Object.keys(formData).some(key => {
      const k = key as keyof Service;
      return formData[k] !== service[k];
    });
    setHasUnsavedChanges(hasChanges);
  }, [formData, service]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSave = async () => {
    setError(null);
    const updatedService = {
      ...service,
      ...formData,
      updatedAt: Date.now()
    };
    try {
      const response = await sendMessage('updateService', updatedService);
      if (response.success) {
        onUpdate(updatedService);
        setIsEditing(false);
        setHasUnsavedChanges(false);
      } else {
        setError(response.error || 'Failed to save service');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to save service');
    }
  };

  const handleCancel = () => {
    setFormData({
      name: service.name,
      url: service.url,
      type: service.type,
      enabled: service.enabled,
      status: service.status,
      category: service.category,
      requiresApiKey: service.requiresApiKey,
      apiKey: service.apiKey
    });
    setIsEditing(false);
    setHasUnsavedChanges(false);
  };

  const handleDelete = () => {
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    onDelete(service.id);
    setShowDeleteConfirm(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return '#28a745';
      case 'offline': return '#dc3545';
      case 'checking': return '#ffc107';
      default: return '#6c757d';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'online': return 'Online';
      case 'offline': return 'Offline';
      case 'checking': return 'Checking...';
      default: return 'Unknown';
    }
  };

  return (
    <div className={styles.serviceCard}>
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <h3>Delete Service</h3>
            <p>Are you sure you want to delete "{service.name}"? This action cannot be undone.</p>
            <div className={styles.modalActions}>
              <button 
                className={styles.dangerButton}
                onClick={confirmDelete}
              >
                Delete
              </button>
              <button 
                className={styles.cancelButton}
                onClick={() => setShowDeleteConfirm(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Service Header */}
      <div className={styles.serviceHeader}>
        <div className={styles.serviceInfo}>
          {isSelecting && (
            <input 
              type="checkbox" 
              checked={isSelected} 
              onChange={() => onSelectionChange?.(service.id)}
              className={styles.checkbox}
            />
          )}
          
          <div 
            className={styles.statusIndicator}
            style={{ backgroundColor: getStatusColor(service.status) }}
          />
          
          <div className={styles.serviceDetails}>
            <h3 className={styles.serviceName}>{service.name}</h3>
            <p className={styles.serviceUrl}>{service.url}</p>
            <div className={styles.serviceMeta}>
              <span className={styles.serviceType}>{service.type}</span>
              <span className={styles.serviceCategory}>{service.category}</span>
              <span className={styles.serviceStatus}>{getStatusText(service.status)}</span>
            </div>
          </div>
        </div>

        <div className={styles.serviceActions}>
          <button 
            className={styles.expandButton}
            onClick={() => setIsExpanded(!isExpanded)}
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? '▼' : '▶'}
          </button>
          
          {!isEditing && (
            <>
              <button 
                className={styles.editButton}
                onClick={() => setIsEditing(true)}
                title="Edit Service"
              >
                Edit
              </button>
              <button 
                className={styles.deleteButton}
                onClick={handleDelete}
                title="Delete Service"
              >
                Delete
              </button>
            </>
          )}
        </div>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className={styles.expandedContent}>
          {isEditing ? (
            <form ref={formRef} className={styles.editForm}>
              <div className={styles.formGrid}>
                <div className={styles.formField}>
                  <label htmlFor="name">Service Name</label>
                  <input
                    id="name"
                    type="text"
                    name="name"
                    value={formData.name || ''}
                    onChange={handleInputChange}
                    required
                    placeholder="Enter service name"
                  />
                </div>

                <div className={styles.formField}>
                  <label htmlFor="url">Service URL</label>
                  <input
                    id="url"
                    type="url"
                    name="url"
                    value={formData.url || ''}
                    onChange={handleInputChange}
                    required
                    placeholder="http://localhost:11434"
                  />
                </div>

                <div className={styles.formField}>
                  <label htmlFor="type">Service Type</label>
                  <select
                    id="type"
                    name="type"
                    value={formData.type || ''}
                    onChange={handleInputChange}
                    required
                  >
                    {Object.entries(SERVICE_TYPES).map(([key, value]) => (
                      <option key={key} value={value}>{key}</option>
                    ))}
                  </select>
                </div>

                <div className={styles.formField}>
                  <label htmlFor="category">Category</label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category || ''}
                    onChange={handleInputChange}
                    required
                  >
                    {Object.entries(SERVICE_CATEGORIES).map(([key, value]) => (
                      <option key={key} value={value}>{key}</option>
                    ))}
                  </select>
                </div>

                <div className={styles.formField}>
                  <label className={styles.checkboxLabel}>
                    <input
                      type="checkbox"
                      name="enabled"
                      checked={formData.enabled}
                      onChange={handleInputChange}
                    />
                    Enabled
                  </label>
                </div>

                <div className={styles.formField}>
                  <label className={styles.checkboxLabel}>
                    <input
                      type="checkbox"
                      name="requiresApiKey"
                      checked={formData.requiresApiKey}
                      onChange={handleInputChange}
                    />
                    Requires API Key
                  </label>
                </div>
              </div>

              {formData.requiresApiKey && (
                <div className={styles.formField}>
                  <label htmlFor="apiKey">API Key</label>
                  <input
                    id="apiKey"
                    type="password"
                    name="apiKey"
                    value={formData.apiKey || ''}
                    onChange={handleInputChange}
                    placeholder="Enter API key"
                  />
                </div>
              )}

              {error && <div style={{ color: 'red', marginBottom: 8 }}>{error}</div>}
              <div className={styles.formActions}>
                <button 
                  type="button"
                  className={styles.saveButton}
                  onClick={handleSave}
                  disabled={!hasUnsavedChanges}
                >
                  Save Changes
                </button>
                <button 
                  type="button"
                  className={styles.cancelButton}
                  onClick={handleCancel}
                >
                  Cancel
                </button>
              </div>
            </form>
          ) : (
            <div className={styles.serviceDetails}>
              <div className={styles.detailGrid}>
                <div className={styles.detailItem}>
                  <strong>Name:</strong> {service.name}
                </div>
                <div className={styles.detailItem}>
                  <strong>URL:</strong> {service.url}
                </div>
                <div className={styles.detailItem}>
                  <strong>Type:</strong> {service.type}
                </div>
                <div className={styles.detailItem}>
                  <strong>Category:</strong> {service.category}
                </div>
                <div className={styles.detailItem}>
                  <strong>Status:</strong> {getStatusText(service.status)}
                </div>
                <div className={styles.detailItem}>
                  <strong>Enabled:</strong> {service.enabled ? 'Yes' : 'No'}
                </div>
                {service.requiresApiKey && (
                  <div className={styles.detailItem}>
                    <strong>API Key:</strong> {service.apiKey ? '••••••••' : 'Not Set'}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ServiceListItem; 
import React, { useState, useEffect, useRef } from 'react';
import { Service, LLMModel } from '@/types';
import { sendMessage } from '@/utils/chrome';
import styles from '@/styles/components/ChatInterface.module.css';
import { v4 as uuidv4 } from 'uuid';
import { getChatSessions, saveChatSession, getCurrentSessionId, removeChatSession } from '@/background/utils/storage';
import { generateSessionTitle, sortSessionsByDate, hasValidContent } from '@/utils/chatUtils';
import type { ChatMessage, ChatSession } from '@/types';
import ChatMessageComponent from './ChatMessage';
import SessionList from './SessionList';

interface ChatInterfaceProps {
  service: Service;
  generationOptions?: {
    temperature: number;
    maxTokens: number;
    tools: {
      webSearch: boolean;
      codeInterpreter: boolean;
      fileUpload: boolean;
    };
  };
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ service, generationOptions }) => {
  const [models, setModels] = useState<LLMModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionIdState] = useState<string | null>(null);
  const [sendOnlyPrompt, setSendOnlyPrompt] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [modelsLoading, setModelsLoading] = useState(true);
  const [modelsError, setModelsError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const fetchModels = async () => {
      setModelsLoading(true);
      setModelsError(null);
      if (service) {
        try {
          console.log('[ChatInterface] Fetching models for service:', service.id, service.name);
          const fetchedModels = await sendMessage<LLMModel[]>('getModels', { serviceId: service.id });
          console.log('[ChatInterface] Received models:', fetchedModels);
          setModels(fetchedModels || []);
          
          // Check for saved model first
          const key = `lastModel_${service.id}`;
          const savedModel = localStorage.getItem(key);
          console.log('[ChatInterface] Saved model from localStorage:', savedModel);
          
          if (savedModel && fetchedModels?.some(model => model.id === savedModel)) {
            console.log('[ChatInterface] Using saved model:', savedModel);
            setSelectedModel(savedModel);
          } else if (fetchedModels && fetchedModels.length > 0) {
            console.log('[ChatInterface] No saved model found, using first model:', fetchedModels[0].id);
            setSelectedModel(fetchedModels[0].id);
          } else {
            console.log('[ChatInterface] No models available');
            setSelectedModel('');
          }
        } catch (error) {
          console.error('[ChatInterface] Error fetching models:', error);
          setModelsError("Failed to fetch models");
          setModels([]);
        } finally {
          setModelsLoading(false);
        }
      }
    };
    fetchModels();
  }, [service]);

  useEffect(() => {
    const loadSessions = async () => {
      console.log('[ChatInterface] Loading sessions for service:', service.id);
      const allSessions = await getChatSessions(service.id);
      console.log('[ChatInterface] All sessions loaded:', allSessions.length);
      console.log('[ChatInterface] All sessions:', allSessions);
      
      const validSessions = allSessions.filter(hasValidContent);
      console.log('[ChatInterface] Valid sessions after filtering:', validSessions.length);
      console.log('[ChatInterface] Valid sessions:', validSessions);
      
      const sortedSessions = sortSessionsByDate(validSessions);
      setSessions(sortedSessions);
      
      // Only load a session if there's an explicit currentSessionId
      let sessionId = await getCurrentSessionId(service.id);
      console.log('[ChatInterface] Current session ID from storage:', sessionId);
      
      if (sessionId) {
        const session = sortedSessions.find(s => s.id === sessionId);
        if (session) {
          console.log('[ChatInterface] Loading existing session:', session.id);
          setMessages(session.messages);
          setCurrentSessionIdState(sessionId);
        } else {
          console.log('[ChatInterface] Session not found, starting new chat');
          setCurrentSessionIdState(null);
          setMessages([]);
        }
      } else {
        console.log('[ChatInterface] No current session, starting new chat');
        setCurrentSessionIdState(null);
        setMessages([]);
      }
    };
    
    loadSessions();
  }, [service.id]);

  const handleModelChange = (modelId: string) => {
    console.log('[ChatInterface] Model changed to:', modelId);
    setSelectedModel(modelId);
    if (service) {
      const key = `lastModel_${service.id}`;
      localStorage.setItem(key, modelId);
      console.log('[ChatInterface] Saved model to localStorage:', key, modelId);
      // Insert a system message noting the model switch
      setMessages(prev => [
        ...prev,
        {
          id: uuidv4(),
          role: 'system',
          content: `Model switched to: ${modelId}`,
          timestamp: Date.now()
        }
      ]);
    }
  };

  const handleNewChat = async () => {
    if (!service) return;
    setCurrentSessionIdState(null);
    setMessages([]);
  };

  const handleStopGeneration = async () => {
    try {
      await sendMessage('abortRequest', { serviceId: service.id });
      setIsLoading(false);
    } catch (error) {
      // Do not log or append any error if abort fails
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!prompt.trim() || isLoading) return;
    
    console.log('[ChatInterface] Sending message with model:', selectedModel);
    console.log('[ChatInterface] Available models:', models);
    console.log('[ChatInterface] Generation options:', generationOptions);
    
    setIsLoading(true);
    let sessionId = currentSessionId || uuidv4();
    let session = sessions.find(s => s.id === sessionId);
    if (!session) {
      session = { 
        id: sessionId, 
        createdAt: Date.now(), 
        updatedAt: Date.now(),
        messages: [] 
      };
      setCurrentSessionIdState(sessionId);
    }
    
    const newMessage: ChatMessage = {
      id: uuidv4(),
      role: 'user',
      content: prompt,
      timestamp: Date.now()
    };
    
    let updatedMessages = [...(session?.messages || []), newMessage];
    setMessages(updatedMessages);
    setPrompt('');
    
    try {
      const toSend = sendOnlyPrompt ? [newMessage] : updatedMessages;
      console.log('[ChatInterface] Sending message with:', { 
        serviceId: service.id, 
        messageCount: toSend.length, 
        model: selectedModel,
        options: generationOptions
      });
      
      const fullHistory = await sendMessage('sendMessage', {
        serviceId: service.id,
        messages: toSend,
        model: selectedModel,
        sessionId: sessionId as string,
        options: generationOptions
      });
      
      console.log('[ChatInterface] Received fullHistory:', fullHistory);
      console.log('[ChatInterface] fullHistory structure:', JSON.stringify(fullHistory, null, 2));
      console.log('[ChatInterface] fullHistory type:', typeof fullHistory);
      console.log('[ChatInterface] fullHistory length:', Array.isArray(fullHistory) ? fullHistory.length : 'not an array');
      console.log('[ChatInterface] fullHistory content:', fullHistory);
      
      // Ensure we have the full response
      if (Array.isArray(fullHistory) && fullHistory.length > 0) {
        const lastMessage = fullHistory[fullHistory.length - 1];
        console.log('[ChatInterface] Last message:', lastMessage);
        console.log('[ChatInterface] Last message content:', lastMessage.content);
        console.log('[ChatInterface] Last message content length:', lastMessage.content?.length);
        console.log('[ChatInterface] Last message content type:', typeof lastMessage.content);
        console.log('[ChatInterface] Last message content JSON:', JSON.stringify(lastMessage.content));
      }
      
      setMessages(fullHistory);
      // Print all messages for debugging
      console.log('[ChatInterface] All messages:', fullHistory.map((m: ChatMessage) => m.content));
      console.log('[ChatInterface] All message lengths:', fullHistory.map((m: ChatMessage) => m.content?.length));
      
      const updatedSession: ChatSession = {
        title: generateSessionTitle(fullHistory),
        ...(session || {}),
        id: sessionId,
        createdAt: session?.createdAt || Date.now(),
        updatedAt: session?.updatedAt || Date.now(),
        messages: fullHistory
      };
      await saveChatSession(service.id, updatedSession);
      // Reload sessions after saving
      const allSessionsAfter = await getChatSessions(service.id);
      const validSessionsAfter = allSessionsAfter.filter(hasValidContent);
      const sortedSessionsAfter = sortSessionsByDate(validSessionsAfter);
      setSessions(sortedSessionsAfter);
      setCurrentSessionIdState(sessionId);
    } catch (error) {
      console.error('Error sending message:', error);
      let displayMessage = 'An unknown error occurred.';
      let isCancelled = false;
      if (error instanceof Error) {
        if (error.message.includes('403')) {
          displayMessage = 'Access Denied (Error 403). Please check if an API key is required and correctly configured for this service in the settings.';
        } else if (error.message.includes('cancelled') || error.message.includes('abort')) {
          isCancelled = true;
        } else {
          displayMessage = error.message;
        }
      }
      if (!isCancelled) {
        setMessages(prev => [...prev, { id: uuidv4(), role: 'assistant', content: `Error: ${displayMessage}`, timestamp: Date.now() }]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Action handlers for ChatMessage component
  const handleEditMessage = (messageId: string, newContent: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, content: newContent } : msg
    ));
  };

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    // Add copy feedback
    const notification = document.createElement('div');
    notification.textContent = 'Copied to clipboard!';
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: var(--accent-color);
      color: white;
      padding: 8px 16px;
      border-radius: 4px;
      z-index: 10000;
      font-size: 14px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 2000);
  };

  const handleContinueResponse = async (messageId: string) => {
    const message = messages.find(msg => msg.id === messageId);
    if (!message || message.role !== 'assistant') return;
    
    setIsLoading(true);
    try {
      const response = await sendMessage('sendMessage', {
        serviceId: service.id,
        messages: [...messages, { role: 'user', content: 'Continue', id: uuidv4(), timestamp: Date.now() }],
        model: selectedModel,
        sessionId: currentSessionId || uuidv4(),
      });
      setMessages(response);
    } catch (error) {
      console.error('Error continuing response:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegenerateResponse = async (messageId: string) => {
    const messageIndex = messages.findIndex(msg => msg.id === messageId);
    if (messageIndex === -1 || messages[messageIndex].role !== 'assistant') return;
    
    // Remove the assistant message and regenerate
    const messagesBeforeAssistant = messages.slice(0, messageIndex);
    setMessages(messagesBeforeAssistant);
    
    setIsLoading(true);
    try {
      const response = await sendMessage('sendMessage', {
        serviceId: service.id,
        messages: messagesBeforeAssistant,
        model: selectedModel,
        sessionId: currentSessionId || uuidv4(),
      });
      setMessages(response);
    } catch (error) {
      console.error('Error regenerating response:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRateResponse = (messageId: string, rating: 'good' | 'bad') => {
    console.log(`Rating message ${messageId} as ${rating}`);
    // Could send rating to backend or store locally
  };

  const handleGenerateImage = (prompt: string) => {
    console.log('Generate image from prompt:', prompt);
    // Could open image generation service or send to background
  };

  const handleReadAloud = (content: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(content);
      speechSynthesis.speak(utterance);
    }
  };

  const handleDeleteMessage = (messageId: string) => {
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
  };

  const handleSessionSelect = (sessionId: string) => {
    const session = sessions.find(s => s.id === sessionId);
    if (session) {
      setCurrentSessionIdState(sessionId);
      setMessages(session.messages);
    }
  };

  const handleSessionDelete = async (sessionId: string) => {
    const updatedSessions = sessions.filter(s => s.id !== sessionId);
    setSessions(updatedSessions);
    
    // If we're deleting the current session, start a new chat
    if (sessionId === currentSessionId) {
      setCurrentSessionIdState(null);
      setMessages([]);
    }
    
    // Remove from storage
    await removeChatSession(service.id, sessionId);
    console.log('Session deleted:', sessionId);
  };

  return (
    <div className={styles.chatContainer}>
      {/* Sidebar with session history */}
      <div className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <h3 className={styles.sidebarTitle}>Chat History</h3>
          <button onClick={handleNewChat} className={styles.newChatButton}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            New Chat
          </button>
        </div>
        <div className={styles.sidebarContent}>
          <SessionList
            sessions={sessions}
            currentSessionId={currentSessionId}
            onSessionSelect={handleSessionSelect}
            onSessionDelete={handleSessionDelete}
          />
        </div>
      </div>

      {/* Main chat area */}
      <div className={styles.mainContent}>
        {/* Model selector and controls */}
        <div className={styles.chatHeader}>
          <div className={styles.modelSelector}>
            {modelsLoading ? (
              <span className={styles.modelLoading}>Loading models...</span>
            ) : modelsError ? (
              <span className={styles.modelError}>{modelsError}</span>
            ) : (
              <>
                <select
                  className={styles.modelSelect}
                  value={selectedModel}
                  onChange={(e) => handleModelChange(e.target.value)}
                >
                  {models.map((model) => (
                    <option key={model.id} value={model.id}>
                      {model.name}
                    </option>
                  ))}
                </select>
                {selectedModel && (
                  <span className={styles.currentModelLabel}>
                    Model: <b>{selectedModel}</b>
                  </span>
                )}
              </>
            )}
          </div>
        </div>

        {/* Messages area */}
        <div className={styles.messagesContainer}>
          {messages.length === 0 ? (
            <div className={styles.welcomeMessage}>
              <div className={styles.welcomeIcon}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <h2 className={styles.welcomeTitle}>Welcome to {service.name}</h2>
              <p className={styles.welcomeText}>
                Start a conversation with your AI assistant. You can ask questions, get help with tasks, or just chat.
              </p>
            </div>
          ) : (
            <div className={styles.messagesList}>
              {messages.map((msg, index) => (
                <ChatMessageComponent
                  key={msg.id || index}
                  message={msg}
                  onEdit={handleEditMessage}
                  onCopy={handleCopyMessage}
                  onContinue={handleContinueResponse}
                  onRegenerate={handleRegenerateResponse}
                  onRate={handleRateResponse}
                  onGenerateImage={handleGenerateImage}
                  onReadAloud={handleReadAloud}
                  onDelete={handleDeleteMessage}
                  showActions={true}
                  isLastMessage={msg.role === 'assistant' && index === messages.length - 1}
                />
              ))}
              
              {isLoading && (
                <div className={styles.loadingMessage}>
                  <div className={styles.loadingIndicator}>
                    <div className={styles.loadingDots}>
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    <span>Assistant is typing...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input area */}
        <div className={styles.inputArea}>
          <div className={styles.inputContainer}>
            <div className={styles.inputOptions}>
              <label className={styles.optionLabel}>
                <input 
                  type="checkbox" 
                  checked={sendOnlyPrompt} 
                  onChange={(e) => setSendOnlyPrompt(e.target.checked)} 
                  className={styles.optionCheckbox}
                />
                Send only current prompt
              </label>
            </div>
            
            <div className={styles.inputWrapper}>
              <textarea
                className={styles.messageInput}
                placeholder="Type your message here..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyPress={handleKeyPress}
                rows={1}
                disabled={isLoading}
              />
              <div className={styles.inputButtons}>
                {isLoading ? (
                  <button 
                    onClick={handleStopGeneration} 
                    className={`${styles.sendButton} ${styles.stopButton}`}
                    title="Stop Generation"
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="6" y="6" width="12" height="12"></rect>
                    </svg>
                  </button>
                ) : (
                  <button 
                    onClick={handleSendMessage} 
                    className={styles.sendButton}
                    disabled={!prompt.trim()}
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22,2 15,22 11,13 2,9"></polygon>
                    </svg>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
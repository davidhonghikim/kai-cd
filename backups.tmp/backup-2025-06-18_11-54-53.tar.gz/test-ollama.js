// Test script to simulate the extension's request
const testRequest = async () => {
  const url = 'http://192.168.1.180:11434/api/chat';
  
  // Simulate the exact request the extension makes
  const request = {
    model: 'gemma3:1b',
    messages: [
      {
        role: 'user',
        content: 'who are you'
      }
    ],
    temperature: 0.7,
    top_p: 0.9,
    top_k: 40,
    num_predict: 2048,
    stop: []
  };

  console.log('Making request to:', url);
  console.log('Request body:', JSON.stringify(request, null, 2));

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers.entries()));

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Error response:', errorText);
    } else {
      const responseText = await response.text();
      console.log('Success response (first 500 chars):', responseText.substring(0, 500));
    }
  } catch (error) {
    console.error('Fetch error:', error);
  }
};

testRequest(); 
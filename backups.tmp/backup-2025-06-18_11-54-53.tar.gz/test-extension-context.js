// Test script to simulate extension context
console.log('Testing extension-style request to remote Ollama...');

const testExtensionContext = async () => {
  const url = 'http://192.168.1.180:11434';
  
  console.log('=== Extension Context Test ===');
  console.log('URL:', url);
  console.log('User Agent:', navigator.userAgent);
  console.log('Origin:', window.location.origin);
  
  try {
    // Test 1: Basic request (like extension)
    console.log('\n--- Test 1: Basic Extension Request ---');
    const response1 = await fetch(`${url}/api/tags`, {
      headers: {
        'User-Agent': 'ChatDemon-Extension/1.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json'
      },
      credentials: 'omit'
    });
    
    console.log('Status:', response1.status);
    console.log('Status Text:', response1.statusText);
    console.log('Headers:', Object.fromEntries(response1.headers.entries()));
    
    const data1 = await response1.json();
    console.log('Models count:', data1.models?.length || 0);
    console.log('First model:', data1.models?.[0]?.name);
    
    // Test 2: Chat request
    console.log('\n--- Test 2: Chat Request ---');
    const response2 = await fetch(`${url}/api/chat`, {
      method: 'POST',
      headers: {
        'User-Agent': 'ChatDemon-Extension/1.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json'
      },
      credentials: 'omit',
      body: JSON.stringify({
        model: 'gemma3:1b',
        messages: [{ role: 'user', content: 'Hello from extension test' }],
        stream: false
      })
    });
    
    console.log('Chat Status:', response2.status);
    console.log('Chat Status Text:', response2.statusText);
    console.log('Chat Headers:', Object.fromEntries(response2.headers.entries()));
    
    const data2 = await response2.json();
    console.log('Chat Response:', data2.message?.content?.substring(0, 100) + '...');
    
    console.log('\n✅ All tests passed!');
    
  } catch (error) {
    console.error('\n❌ Error occurred:');
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    // Additional debugging info
    console.error('\n--- Debug Info ---');
    console.error('Error type:', typeof error);
    console.error('Error constructor:', error.constructor.name);
    
    if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
      console.error('This looks like a CORS or network error');
    }
    
    if (error.name === 'TypeError' && error.message.includes('NetworkError')) {
      console.error('This is a network connectivity issue');
    }
  }
};

// Run the test
testExtensionContext(); 
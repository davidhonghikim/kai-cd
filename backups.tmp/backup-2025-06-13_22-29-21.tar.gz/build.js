const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Ensure src directory exists
if (!fs.existsSync('src')) {
  console.error('src directory not found');
  process.exit(1);
}

// Create dist directory if it doesn't exist
if (!fs.existsSync('dist')) {
  fs.mkdirSync('dist');
}

// Compile TypeScript files
try {
  console.log('Compiling TypeScript files...');
  execSync('tsc --project tsconfig.json', { stdio: 'inherit' });
  console.log('TypeScript compilation completed successfully');
} catch (error) {
  console.error('TypeScript compilation failed:', error);
  process.exit(1);
}

// Run Vite build
try {
  console.log('Running Vite build...');
  execSync('vite build', { stdio: 'inherit' });
  console.log('Vite build completed successfully');
} catch (error) {
  console.error('Vite build failed:', error);
  process.exit(1);
}

// Copy manifest.json to dist directory
try {
  console.log('Copying manifest.json to dist directory...');
  fs.copyFileSync('manifest.json', 'dist/manifest.json');
  console.log('manifest.json copied successfully');
} catch (error) {
  console.error('Failed to copy manifest.json:', error);
}

// Copy icons to dist directory
try {
  console.log('Copying icons to dist directory...');
  if (!fs.existsSync('dist/icons')) {
    fs.mkdirSync('dist/icons', { recursive: true });
  }
  
  const iconFiles = fs.readdirSync('icons');
  iconFiles.forEach(file => {
    fs.copyFileSync(`icons/${file}`, `dist/icons/${file}`);
  });
  console.log('Icons copied successfully');
} catch (error) {
  console.error('Failed to copy icons:', error);
}

// Copy UI directory to dist
try {
  console.log('Copying UI directory to dist...');
  
  // Function to recursively copy a directory
  function copyDir(src, dest) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    
    const entries = fs.readdirSync(src, { withFileTypes: true });
    
    for (const entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);
      
      if (entry.isDirectory()) {
        copyDir(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }
  
  copyDir('ui', 'dist/ui');
  console.log('UI directory copied successfully');
} catch (error) {
  console.error('Failed to copy UI directory:', error);
}

console.log('Build completed successfully!'); 
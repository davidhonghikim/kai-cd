# ChatDemon - AI Browser Extension

This project is a Chrome extension based on OpenWebUI that enables interaction with various AI backends directly from your browser.

## Project Structure

- **src/**: Core extension code 
  - **background.ts**: Main background script handling server communications and management
  - **constants.js**: Shared constants used throughout the extension
  - **content.js**: Content script for interacting with web pages
  - **ui-injector.js**: Handles UI injection into web pages

- **ui/**: Svelte-based user interface
  - **src/lib/components/**: UI components
  - **src/lib/apis/**: API integrations for different services
  - **src/lib/utils/**: Utility functions

- **md/**: Project documentation (sequentially numbered for AI agent optimization)
  - **00-AI-Agent-Documentation-Index.md**: Master index of all documentation
  - **01-Autopilot-Protocol.md**: Core operating protocol for AI agents
  - **02-Agent-Instructions.md** through **12-Documentation.md**: Sequentially organized docs

- **scripts/**: Utility scripts
  - **create_backup.sh**: Creates timestamped project backups with proper exclusions
  - **commit.sh**: Standardized git commit helper
  - **load_docs.sh**: Documentation loader for AI agents

- **backups/**: Project backups and unused code archives

## How to Test

1.  **Open Chrome and navigate to the Extensions page:**
    `chrome://extensions`
2.  **Enable Developer Mode:**
    Click the toggle switch in the top-right corner.
3.  **Load the Extension:**
    - Click the **"Load unpacked"** button.
    - In the file selection dialog, choose the root directory of this project (the one containing `manifest.json`).
4.  **Launch the UI:**
    - Click the extension icon in the Chrome toolbar to open the side panel.
    - You should see the full OpenWebUI interface load.

## Current Status
- The OpenWebUI frontend has been built from source and integrated
- Asset paths have been corrected for the extension environment
- Background and content scripts are in place for basic functionality
- Server manager UI implemented for configuring different AI backends
- Code has been cleaned up and organized for better maintainability
- Documentation reorganized with sequential numbering for AI agent optimization

## Features

- Connect to multiple AI backends:
  - Open-WebUI (port 3000)
  - A1111 Stable Diffusion (port 7860)
  - ComfyUI (port 8069)
  - Ollama (port 11434)
- Configure and manage server connections
- Access AI functionality through browser side panel

## Development

- Uses TypeScript for type safety
- Svelte for UI components
- Chrome Extension Manifest V3

## Documentation

The project uses a sequentially numbered documentation system optimized for AI agent assistance:

```
/load-sequence foundation  # Loads foundation documents (01-03)
/load-sequence technical   # Loads technical specifications (04-06)
/load-sequence development # Loads development context (07-09)
/load-sequence status      # Loads project status documents (10-12)
```

For more details, see [md/00-AI-Agent-Documentation-Index.md](md/00-AI-Agent-Documentation-Index.md).

## Utilities

- Create a backup: `./scripts/create_backup.sh [optional_tag]`
- Standardized commits: `./scripts/commit.sh <type> "<message>"`
- Load documentation: `./scripts/load_docs.sh [sequence]`

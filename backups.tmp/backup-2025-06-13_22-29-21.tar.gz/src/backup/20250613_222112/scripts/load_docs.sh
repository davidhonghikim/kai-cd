#!/bin/bash
# ChatDemon Documentation Loader Script
# Usage: ./scripts/load_docs.sh [sequence]
# Example: ./scripts/load_docs.sh foundation

# Define colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Define document groups
FOUNDATION_DOCS=("md/01-Autopilot-Protocol.md" "md/02-Agent-Instructions.md" "md/03-Project-Overview.md")
TECHNICAL_DOCS=("md/04-Codebase-Review.md" "md/05-Implementation-Plan.md" "md/06-Server-Configuration.md")
DEVELOPMENT_DOCS=("md/07-Dev-Environment.md" "md/08-OpenWebUI-Port-Plan.md" "md/09-Chrome-Extension-Plan.md")
STATUS_DOCS=("md/10-Issues-Roadmap.md" "md/11-Project-Status.md" "md/12-Documentation.md")

# Check if a sequence was provided
if [ $# -eq 0 ]; then
    echo -e "${YELLOW}Usage: $0 [sequence]${NC}"
    echo -e "${BLUE}Available sequences:${NC}"
    echo "  foundation   - Load foundational documents (01-03)"
    echo "  technical    - Load technical specifications (04-06)"
    echo "  development  - Load development context (07-09)"
    echo "  status       - Load project status documents (10-12)"
    echo "  all          - Load all documentation files"
    echo "  index        - Display documentation index"
    exit 1
fi

# Function to display a document
display_doc() {
    local doc=$1
    if [ -f "$doc" ]; then
        echo -e "${GREEN}📄 Loading: ${BLUE}$doc${NC}"
        echo "----------------------------------------"
        cat "$doc"
        echo "----------------------------------------"
        echo -e "${GREEN}✅ Loaded: ${BLUE}$doc${NC}\n"
    else
        echo -e "${RED}❌ Error: File not found - $doc${NC}"
    fi
}

# Load documents based on the sequence
case "$1" in
    "foundation")
        echo -e "${GREEN}📚 Loading Foundation Documents...${NC}\n"
        for doc in "${FOUNDATION_DOCS[@]}"; do
            display_doc "$doc"
        done
        ;;
    "technical")
        echo -e "${GREEN}📚 Loading Technical Documents...${NC}\n"
        for doc in "${TECHNICAL_DOCS[@]}"; do
            display_doc "$doc"
        done
        ;;
    "development")
        echo -e "${GREEN}📚 Loading Development Context Documents...${NC}\n"
        for doc in "${DEVELOPMENT_DOCS[@]}"; do
            display_doc "$doc"
        done
        ;;
    "status")
        echo -e "${GREEN}📚 Loading Status Documents...${NC}\n"
        for doc in "${STATUS_DOCS[@]}"; do
            display_doc "$doc"
        done
        ;;
    "all")
        echo -e "${GREEN}📚 Loading All Documents...${NC}\n"
        display_doc "md/00-AI-Agent-Documentation-Index.md"
        for doc in "${FOUNDATION_DOCS[@]}" "${TECHNICAL_DOCS[@]}" "${DEVELOPMENT_DOCS[@]}" "${STATUS_DOCS[@]}"; do
            display_doc "$doc"
        done
        ;;
    "index")
        echo -e "${GREEN}📚 Loading Documentation Index...${NC}\n"
        display_doc "md/00-AI-Agent-Documentation-Index.md"
        ;;
    *)
        echo -e "${RED}❌ Error: Unknown sequence - $1${NC}"
        echo -e "${YELLOW}Available sequences:${NC} foundation, technical, development, status, all, index"
        exit 1
        ;;
esac

echo -e "${GREEN}✅ Document loading complete!${NC}" 
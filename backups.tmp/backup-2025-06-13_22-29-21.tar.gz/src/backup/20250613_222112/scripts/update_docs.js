const fs = require('fs');
const path = require('path');

// Get all markdown files in the md directory
const mdDir = path.join(__dirname, '..', 'md');
const mdFiles = fs.readdirSync(mdDir).filter(file => file.endsWith('.md'));

console.log(`Found ${mdFiles.length} markdown files to process`);

// Process each markdown file
mdFiles.forEach(file => {
  const filePath = path.join(mdDir, file);
  let content = fs.readFileSync(filePath, 'utf8');
  
  // Replace incorrect ComfyUI port (8188) with correct one (8069)
  const oldContent = content;
  content = content.replace(/ComfyUI.*?port.*?8188/gi, match => match.replace('8188', '8069'));
  content = content.replace(/port.*?8188.*?ComfyUI/gi, match => match.replace('8188', '8069'));
  content = content.replace(/8188.*?ComfyUI/gi, match => match.replace('8188', '8069'));
  
  // Ensure OpenWebUI is consistently using port 3000
  content = content.replace(/OpenWebUI.*?port.*?(?!3000)\d{4}/gi, match => match.replace(/\d{4}/, '3000'));
  content = content.replace(/port.*?(?!3000)\d{4}.*?OpenWebUI/gi, match => match.replace(/\d{4}/, '3000'));
  
  // Write back to file if changes were made
  if (content !== oldContent) {
    fs.writeFileSync(filePath, content);
    console.log(`Updated port numbers in ${file}`);
  } else {
    console.log(`No changes needed in ${file}`);
  }
});

console.log('Documentation update complete'); 
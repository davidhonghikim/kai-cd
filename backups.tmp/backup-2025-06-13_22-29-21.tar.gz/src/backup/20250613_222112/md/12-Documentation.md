# ChatDemon Project Documentation

## Project Overview

ChatDemon is a Chrome extension that integrates with multiple AI backends (OpenWebUI, Ollama, A1111, ComfyUI) to provide AI capabilities directly in the browser. It's built using modern web technologies and follows Chrome Extension Manifest V3 standards.

## Architecture

### Core Components

1. **Background Script (background.ts)**
   - Manages communication with AI servers
   - Handles server configuration and storage
   - Implements service connectors for different backend types
   - Processes messages from content scripts and UI

2. **Content Script (content.js)**
   - Runs in the context of web pages
   - Captures user selections and page context
   - Communicates with the background script

3. **UI Layer (ui/)**
   - Svelte-based interface components
   - Server management UI
   - Chat interface
   - Settings and configuration

4. **Storage**
   - Uses chrome.storage.local for persistence
   - Stores server configurations and user preferences

## Key Features

- **Multi-server support**: Connect to different AI backends simultaneously
- **Server Manager**: Configure and manage connections to different AI services
- **Type Safety**: Uses TypeScript for improved code quality and maintainability
- **Modern UI**: Svelte-based components for a responsive and efficient interface

## Development Setup

1. **Prerequisites**
   - Node.js (v14+)
   - npm or yarn
   - Chrome browser

2. **Building the Extension**
   - Build the Svelte UI: `cd ui && npm install && npm run build`
   - The extension can then be loaded into Chrome in developer mode

3. **Development Workflow**
   - UI changes: Edit files in `ui/src/`
   - Extension logic: Edit files in `src/`
   - Testing: Load the extension in Chrome and use the developer tools

## API Integration

The extension connects to various AI backends through their respective APIs:

1. **OpenWebUI**
   - API Endpoint: `/v1/chat/completions` (OpenAI-compatible)
   - Default Port: 3000

2. **Ollama**
   - API Endpoint: `/api/generate`
   - Default Port: 11434

3. **A1111 (Stable Diffusion)**
   - API Endpoint: `/sdapi/v1/txt2img`
   - Default Port: 7860

4. **ComfyUI**
   - API varies based on workflow
   - Default Port: 8069

## TO-DO List

### High Priority
- [ ] Complete TypeScript migration for remaining JavaScript files
- [ ] Implement robust error handling for all API connections
- [ ] Add proper authentication for secured backends
- [ ] Test with all supported backend types

### Medium Priority
- [ ] Add support for additional model types
- [ ] Implement context-aware features (page summarization, selection analysis)
- [ ] Create a unified model management interface
- [ ] Add support for model parameter tuning

### Low Priority
- [ ] Implement group chat with multiple models
- [ ] Add export/import functionality for conversations
- [ ] Create a browser action popup for quick access
- [ ] Add keyboard shortcuts for common actions

## Dependencies

- **Svelte**: UI framework
- **TypeScript**: Type safety
- **Chrome Extension API**: Browser integration
- **Fetch API**: Server communication

## Known Issues

- Connection issues may occur with servers behind authentication
- Streaming responses not yet implemented
- Limited error handling in some API connectors

## Project Structure

```
chatdemon/
├── src/                    # Core extension code
│   ├── background.ts       # Main background script (TypeScript)
│   ├── constants.js        # Shared constants
│   ├── content.js          # Content script for web page interaction
│   └── ui-injector.js      # UI injection handling
├── ui/                     # Svelte-based UI
│   ├── src/lib/components/ # UI components including ServerManager.svelte
│   └── static/             # Static assets and manifest
├── icons/                  # Extension icons
├── md/                     # Documentation markdown files
├── backups/                # Project backups and unused code
│   ├── open-webui/         # Original Open-WebUI code (archived)
│   └── unused_files_*/     # Storage for removed duplicate files
└── tsconfig.json           # TypeScript configuration
```

## Archive and Backup Strategy

- Original code from Open-WebUI has been archived in backups/open-webui
- Duplicate or replaced files are stored in backups/unused_files_* directory
- JavaScript files that have been migrated to TypeScript are kept as reference
- Regular backups are created with optimized size by excluding large directories

## References

- [Chrome Extension Documentation](https://developer.chrome.com/docs/extensions/)
- [OpenWebUI API Reference](https://github.com/open-webui/open-webui)
- [Ollama API Documentation](https://github.com/ollama/ollama)
- [Svelte Documentation](https://svelte.dev/docs) 
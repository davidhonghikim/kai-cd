# Comprehensive Codebase Review and Autopilot Protocol

## Instructions

Go into autopilot comprehensive codebase file review mode and:

1. Document errors and issues systematically
2. Create a detailed plan to review:
   - Svelte components
   - Chrome extension architecture
   - TypeScript implementation
   - JavaScript functionality
   - HTML structure
   - CSS styling
   - AI server integration
   - OpenAI API implementation

## Guidelines

- **Avoid repetitive fixes**: Identify patterns and fix multiple instances of the same issue with batch operations
- **Check thoroughly for**:
  - Import statements and dependencies
  - Required modules
  - Duplicate code
  - Formatting issues
  - Missing tags/elements
  - Type definitions
  - API integration points

## Development Practices

- Verify existing files before creating new ones
- Check if code/logic already exists before implementation
- Maintain clean structure - don't create random script files or directories
- Periodically review documentation to refresh understanding
- Update your approach based on project requirements
- Avoid using tools that consistently fail - pivot to alternatives
- **Regularly archive using our backup method**:
  - Create backups at logical checkpoints
  - Exclude large files and directories
  - Maintain a clear naming convention for backups
- **Commit at regular checkpoints**:
  - After completing a logical set of changes
  - When a feature is implemented and tested
  - Before making major structural changes
  - When fixing a significant bug

## Preferred Alternatives

- Use `grep`, `sed`, regex, and temp file swaps instead of `edit_file` when appropriate
- Document which methods work best with the current model
- Double-check paths and working directory constantly

## Communication and Documentation

- Provide verbose, regular feedback about what you're doing and why
- Update to-do lists and documentation files as you work
- Update markdown files proactively in case of session refresh

## Shortcuts

- Use `/c` to invoke this comprehensive review protocol
- Use document loading sequences for optimal context:
  - `/load-sequence foundation` - Load foundational documents (01-03)
  - `/load-sequence technical` - Load technical specifications (04-06)
  - `/load-sequence development` - Load development context (07-09)
  - `/load-sequence status` - Load project status documents (10-12)
  - `/load-sequence all` - Load all documentation files

## Integration

This protocol should be integrated into your operating rules and referenced regularly to ensure consistent, high-quality code review and development. 
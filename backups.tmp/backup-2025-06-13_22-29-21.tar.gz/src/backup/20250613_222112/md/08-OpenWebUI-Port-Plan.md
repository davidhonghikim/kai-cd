# OpenWebUI Chrome Extension Direct Port Plan

## Objective
Port the real OpenWebUI frontend (Svelte/JS/TS/CSS) as a Chrome extension that:
- Loads as a side panel or a full browser tab
- Preserves all OpenWebUI UI/UX and features
- Can interact with any open browser tab (context, selection, summarization, etc.)
- Works with any compatible LLM backend (Ollama, OpenAI, etc.)
- Is robust, modular, and maintainable

---

## 1. Preparation
- Fork or clone the [OpenWebUI repo](https://github.com/open-webui/open-webui)
- Set up a new Chrome extension workspace (Manifest V3)
- Ensure you have Node.js, npm, and build tools installed

---

## 2. Build & Bundle OpenWebUI Frontend
- Use OpenWebUI's build system (Vite, Svelte, etc.) to create a static production build
- Output all assets (HTML, JS, CSS, fonts, images) to a directory suitable for extension packaging
- Ensure all asset paths are relative or compatible with Chrome extension loading

---

## 3. Integrate with Chrome Extension
- Place the built OpenWebUI frontend in the extension's `html/` or `dist/` directory
- Set up `manifest.json`:
  - `side_panel.default_path` points to the built OpenWebUI HTML
  - Add a browser action or context menu to open the UI as a full tab (e.g., `chrome.tabs.create({ url: "tab.html" })`)
  - Request permissions: `sidePanel`, `tabs`, `storage`, `contextMenus`, etc.
- Add a content script to capture selected text or page content and send it to the panel/tab

---

## 4. Backend/Server Connectivity
- Ensure the UI can connect to any backend (Ollama, OpenAI, etc.) as configured by the user
- Store settings and chat history in extension storage or localStorage as appropriate

---

## 5. Contextual Features
- Use content scripts to capture selected text or page content
- Send this data to the extension panel/tab for chat/summarization
- Add context menu items for "Chat about selection" and "Summarize page"

---

## 6. Testing & Polishing
- Test the extension in both side panel and full tab modes
- Ensure all OpenWebUI features work as expected
- Polish UI/UX for browser extension context (icons, permissions, onboarding)

---

## 7. Prompts for Agent

### Initial Setup
```
You are to port the real OpenWebUI frontend (Svelte/JS/TS/CSS) as a Chrome extension. Your goals:
- Use the actual OpenWebUI build, not a hand-rewrite
- Make it load as a side panel and as a full browser tab
- Enable interaction with any open browser tab (context, selection, etc.)
- Ensure all OpenWebUI features and UI/UX are preserved
- Use Manifest V3 and follow Chrome extension best practices
```

### Build & Integration
```
1. Fork or clone OpenWebUI and build the frontend for production.
2. Integrate the built UI into the extension's html/dist directory.
3. Configure manifest.json for side panel and tab loading.
4. Add content scripts and background logic for context menu and tab interaction.
5. Test and adapt asset paths for extension compatibility.
```

### Contextual Features
```
- Implement content scripts to capture selected text or page content.
- Add context menu items for "Chat about selection" and "Summarize page".
- Send captured data to the extension panel/tab for chat/summarization.
```

### Backend/Server
```
- Ensure the UI can connect to any backend (Ollama, OpenAI, etc.) as in OpenWebUI.
- Store settings and chat history in extension storage or localStorage.
```

### Testing & Finalization
```
- Test the extension in both side panel and full tab modes.
- Ensure all OpenWebUI features work as expected.
- Polish UI/UX for browser extension context.
```

---

## 8. References
- [OpenWebUI GitHub](https://github.com/open-webui/open-webui)
- [Chrome Extension Manifest V3 Docs](https://developer.chrome.com/docs/extensions/mv3/intro/)
- [OpenWebUI Build/Dev Guide](https://github.com/open-webui/open-webui#local-development)

---

## 9. Notes
- Do **not** delete or overwrite any backup or legacy files unless explicitly instructed.
- Keep all work modular, well-documented, and aligned with OpenWebUI's architecture.

---

## 10. Current Progress
- Created backup of current state
- Set up Vite configs for UI and extension builds
- Updated manifest.json to point to correct UI files
- Created HTML and CSS files for panel and tab views
- Next steps: Implement backend connectivity and contextual features 
# ChatDemon Documentation

This directory contains all documentation for the ChatDemon project, organized in a numbered sequence for optimal AI agent assistance.

## Documentation Structure

The documentation is organized in a sequential numbering system to facilitate loading in the correct order for AI agent assistance:

1. **00-AI-Agent-Documentation-Index.md** - Master index and guide for document loading
2. **01-Autopilot-Protocol.md** - Core operating protocol for AI agents
3. **02-Agent-Instructions.md** - Base instructions for AI agents
4. **03-Project-Overview.md** - High-level project overview
5. **04-Codebase-Review.md** - Current codebase assessment
6. **05-Implementation-Plan.md** - Detailed implementation plans
7. **06-Server-Configuration.md** - Server-related specifications
8. **07-Dev-Environment.md** - Development environment setup
9. **08-OpenWebUI-Port-Plan.md** - OpenWebUI adaptation details
10. **09-Chrome-Extension-Plan.md** - Chrome extension architecture
11. **10-Issues-Roadmap.md** - Known issues and development roadmap
12. **11-Project-Status.md** - Current project status
13. **12-Documentation.md** - Comprehensive project documentation

## Using the Documentation

### For AI Agents

The documentation is structured for optimal AI agent assistance. Use the loading sequence shortcuts:

```
/load-sequence foundation  # Loads docs 01-03
/load-sequence technical   # Loads docs 04-06
/load-sequence development # Loads docs 07-09
/load-sequence status      # Loads docs 10-12
/load-sequence all         # Loads all documents
```

### For Developers

You can use the provided script to display documentation in the terminal:

```bash
./scripts/load_docs.sh foundation  # Display foundation documents
./scripts/load_docs.sh technical   # Display technical documents
./scripts/load_docs.sh development # Display development context
./scripts/load_docs.sh status      # Display status documents
./scripts/load_docs.sh all         # Display all documents
./scripts/load_docs.sh index       # Display the documentation index
```

## Maintenance

When updating documentation:

1. Maintain the numbered sequence
2. Update the index (00-AI-Agent-Documentation-Index.md) if needed
3. Keep cross-references between documents up to date
4. Run a backup before major documentation changes:

```bash
./scripts/create_backup.sh docs_update
``` 
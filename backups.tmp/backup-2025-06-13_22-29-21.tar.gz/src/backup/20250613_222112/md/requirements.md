# Project Requirements and Dependencies

## Dependencies

### Core Dependencies
- **Node.js**: Latest LTS version
- **npm**: Latest version
- **TypeScript**: ^5.5.3
- **Vite**: ^6.3.5
- **Svelte**: ^5.34.1
- **@sveltejs/vite-plugin-svelte**: ^5.1.0
- **svelte-preprocess**: ^6.0.3

### Development Dependencies
- **@types/chrome**: ^0.0.260
- **@types/jest**: ^29.5.14
- **@types/node**: ^20.19.0
- **@typescript-eslint/eslint-plugin**: ^7.18.0
- **@typescript-eslint/parser**: ^7.18.0
- **eslint**: ^8.57.1
- **jest**: ^29.7.0
- **prettier**: ^3.5.3
- **terser**: ^5.42.0
- **webextension-polyfill**: ^0.10.0

## File and Directory Structure

```
chatdemon/
├── .git/
├── .cursor/
├── backups/
├── icons/
├── md/
│   ├── 05-Implementation-Plan.md
│   ├── 08-OpenWebUI-Port-Plan.md
│   ├── 13-Shortcuts.md
│   └── requirements.md
├── node_modules/
├── scripts/
├── src/
│   ├── background/
│   ├── config/
│   ├── connectors/
│   ├── content/
│   └── utils/
├── ui/
│   ├── .svelte-kit/
│   ├── css/
│   ├── node_modules/
│   ├── src/
│   │   ├── lib/
│   │   └── routes/
│   ├── static/
│   ├── .eslintrc.cjs
│   ├── package.json
│   ├── package-lock.json
│   ├── panel.html
│   ├── svelte.config.js
│   ├── tab.html
│   └── vite.config.js
├── .DS_Store
├── .eslintrc.json
├── .gitignore
├── .prettierrc
├── build.js
├── jest.config.js
├── manifest.json
├── package.json
├── package-lock.json
├── README.md
├── tsconfig.json
└── vite.config.ts
```

## Notes
- Ensure all dependencies are installed using `npm install`.
- Use `npm run build` to build the project.
- Use `npm run lint` to check for linting issues.
- Use `npm run test` to run tests.

## References
- [OpenWebUI GitHub](https://github.com/open-webui/open-webui)
- [Chrome Extension Manifest V3 Docs](https://developer.chrome.com/docs/extensions/mv3/intro/)
- [OpenWebUI Build/Dev Guide](https://github.com/open-webui/open-webui#local-development) 
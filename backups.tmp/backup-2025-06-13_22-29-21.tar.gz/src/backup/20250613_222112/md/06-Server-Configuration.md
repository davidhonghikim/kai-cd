# Server Configuration and Management

## 1. Project Reference
*   **Project Name:** ChatDemon
*   **Target Repository:** `https://github.com/davidhonghikim/chatdemon`
*   **Source Project for Porting:** Open-WebUI (`https://github.com/open-webui/open-webui`)

## 2. Server Manager UI

The Options UI will need a "Server Manager" component that allows users to configure multiple servers, specifying IP, port, and type (Ollama, A1111, etc.). The user's dev setup (`192.168.1.180`) can be used as the default seed data.

## 3. Modular Connectors

The `background.ts` must eventually be refactored to have modular "connectors" for each service type (Open-WebUI, A1111, ComfyUI), each aware of its specific ports (`3000`, `7860`, `8069`) and API endpoints.

## 4. Secure Storage

All user configuration (server IPs, ports, API keys) must be stored securely in `chrome.storage.local`.

## 5. Default Server Settings (Seed Data)

The Server Manager should be pre-populated with the following default settings based on the user's development environment:

*   **Open-WebUI:**
    *   IP Address: `192.168.1.180`
    *   Port: `3000`
    *   Type: Open-WebUI

*   **A1111:**
    *   IP Address: `192.168.1.180`
    *   Port: `7860`
    *   Type: A1111

*   **ComfyUI:**
    *   IP Address: `192.168.1.180`
    *   Port: `8188`
    *   Type: ComfyUI

*   **Ollama:**
    *   IP Address: `localhost` (or `192.168.1.180` if accessed remotely)
    *   Port: `11434`
    *   Type: Ollama
# ChatDemon: Master AI Browser Extension

## 1. Project Reference
*   **Project Name:** ChatDemon
*   **Target Repository:** `https://github.com/davidhonghikim/chatdemon`
*   **Source Project for Porting:** Open-WebUI (`https://github.com/open-webui/open-webui`)

## 2. Mission Statement
To develop a powerful, all-in-one browser extension by **porting and adapting the core functionality of Open-WebUI**. The goal is to create a central hub for interacting with a diverse ecosystem of AI models and services, unifying self-hosted models and commercial APIs, and enabling complex, collaborative workflows between different AIs to function as an "AI Super Team."

## 3. Core Technologies
*   Svelte/SvelteKit frontend
*   TypeScript for all logic
*   Chrome Extension API (Manifest V3)

## 4. Core Features & Vision

1.  **Unified Interface (Ported from Open-WebUI):**
    *   Port the responsive frontend from Open-WebUI to serve as the base for the extension's UI.
    *   Adapt this UI for both a full-featured browser tab and a lightweight panel/side-panel.

2.  **Broad Backend Support:**
    *   Retain and enhance Open-WebUI's support for LLMs.
    *   Integrate robust support for ComfyUI and A1111.

3.  **AI Super Team (Group Chat - Key New Feature):**
    *   Enable a single chat interface where multiple models (LLMs and image generators) can collaborate.
    *   A "Coordinator" model will route prompts and manage the conversation flow.

4.  **Comprehensive Management:**
    *   Create a robust Server Manager pre-configured with defaults.
    *   Adapt Open-WebUI's model management for the extension context.
    *   Manage LoRAs, embeddings, etc., for A1111/ComfyUI.
    *   Implement a Prompt Manager.
    *   Ensure full import/export of all settings.

5.  **Content Syndication & Output:**
    *   A new feature layer for posting to social media and saving to cloud storage.
# Known Issues & Development Roadmap

## 1. Project Reference
*   **Project Name:** ChatDemon
*   **Target Repository:** `https://github.com/davidhonghikim/chatdemon`
*   **Source Project for Porting:** Open-WebUI (`https://github.com/open-webui/open-webui`)

## 2. Immediate Blockers (Bugs to Fix NOW)

1.  **[FIXED] TypeScript Configuration Error (`ts(8006)`)**
    *   **Symptom:** The build process fails because the project is not configured to handle TypeScript files.
    *   **Root Cause:** The `tsconfig.json` file in the ChatDemon repository is missing the entry `"src/**/*.ts"` in its `include` array.
    *   **Solution:** Fixed `tsconfig.json`.

2.  **[FIXED] Blank White Screen / Non-functional UI**
    *   **Symptom:** The extension panel is blank, indicating the ported code is broken.
    *   **Causes and Fixes:**
        *   **Failed Porting:** Implemented API proxy in background script and fetch interception in UI.
        *   **CSP:** Updated Content Security Policy in `manifest.json` to allow connections to the development server.

## 3. Development Roadmap

### Phase 1: Stabilization (Get the Port Working)
*   [x] **Fix the `tsconfig.json` bug.**
*   [x] **Update `manifest.json`'s CSP** to allow connections to `http://192.168.1.180:*`.
*   [x] **Debug the "blank white screen" issue.** This involved implementing an API proxy in the background script and adding fetch interception in the UI.
*   [x] **Implement UI for both panel and tab views** with persistent state management.
*   [x] **Create server management interface** to select AI backends.
*   [ ] **Establish a successful end-to-end chat loop** using the ported UI, connecting to the user's Open-WebUI server at `http://192.168.1.180:3000`.

### Phase 2: Feature Integration
*   [x] **Build the Server Manager UI**, pre-populating it with the user's dev server settings for Open-WebUI, A1111, and ComfyUI.
*   [x] **Implement modular connectors in `background.js`** for each server type.
*   [ ] **Implement authentication support** for secured backend connections.
*   [ ] **Add comprehensive error handling** for API calls and server communications.

### Phase 3: Expansion & "Super Team"
*   [ ] **Implement the "AI Super Team" group chat logic.**
*   [ ] **Implement the Prompt Manager and Content Syndication features.**
*   [ ] **Add context-aware features** (page summarization, selection analysis).

## 4. Current Focus

For the next development iteration, we're focusing on:

1. **Complete end-to-end testing** with the OpenWebUI server to ensure proper chat functionality.
2. **Improve error handling** for API calls and server connection issues.
3. **Continue TypeScript migration** for remaining JavaScript files.
4. **Enhance authentication** support for secured backend connections.

The core functionality is now working, with both panel and tab views implemented, persistent state management, and the ability to select different AI backends. The extension now provides a smooth user experience with keyboard shortcuts and context menu integration.
# Development Environment Configuration

## 1. Project Reference
*   **Project Name:** ChatDemon
*   **Target Repository:** `https://github.com/davidhonghikim/chatdemon`
*   **Source Project for Porting:** Open-WebUI (`https://github.com/open-webui/open-webui`)

## 2. Core Technology Stack
*   Frontend: Svelte/SvelteKit
*   Logic: TypeScript
*   Backend: Re-implemented in the extension's TypeScript service worker (`src/background.ts`)

## 3. User's Local Development Server Configuration:
*   **IP Address:** `192.168.1.180`
*   **Open-WebUI Port:** `3000`
*   **A1111 Port:** `7860`
*   **ComfyUI Port:** `8069`
*   **Ollama (Default):** `11434`

## 4. Key Self-Hosted Systems to Support:
*   **Web UIs:** Open-WebUI
*   **LLM Servers:** Ollama, Llama.cpp
*   **Image Generation:** ComfyUI, AUTOMATIC1111 (A1111)
*   **Automation/Misc:** n8n, MCP Servers
*   **Deployment:** Docker where applicable.
# OpenWebUI Chrome Extension Direct Port Plan

## Objective
Port the real OpenWebUI frontend (Svelte/JS/TS/CSS) as a Chrome extension that:
- Loads as a side panel or a full browser tab
- Preserves all OpenWebUI UI/UX and features
- Can interact with any open browser tab (context, selection, summarization, etc.)
- Works with any compatible LLM backend (Ollama, OpenAI, etc.)
- Is robust, modular, and maintainable

---

## 1. Preparation
- Fork or clone the [OpenWebUI repo](https://github.com/open-webui/open-webui)
- Set up a new Chrome extension workspace (Manifest V3)
- Ensure you have Node.js, npm, and build tools installed

---

## 2. Build & Bundle OpenWebUI Frontend
- Use OpenWebUI's build system (Vite, Svelte, etc.) to create a static production build
- Output all assets (HTML, JS, CSS, fonts, images) to a directory suitable for extension packaging
- Ensure all asset paths are relative or compatible with Chrome extension loading

---

## 3. Integrate with Chrome Extension
- Place the built OpenWebUI frontend in the extension's `html/` or `dist/` directory
- Set up `manifest.json`:
  - `side_panel.default_path` points to the built OpenWebUI HTML
  - Add a browser action or context menu to open the UI as a full tab (e.g., `chrome.tabs.create({ url: "tab.html" })`)
  - Request permissions: `sidePanel`, `tabs`, `storage`, `contextMenus`, etc.
- Add a content script to capture selected text or page content and send it to the panel/tab

---

## 4. Backend/Server Connectivity
- Ensure the UI can connect to any backend (Ollama, OpenAI, etc.) as configured by the user
- Store settings and chat history in extension storage or localStorage as appropriate

---

## 5. Contextual Features
- Use content scripts to capture selected text or page content
- Send this data to the extension panel/tab for chat/summarization
- Add context menu items for "Chat about selection" and "Summarize page"

---

## 6. Testing & Polishing
- Test the extension in both side panel and full tab modes
- Ensure all OpenWebUI features work as expected
- Polish UI/UX for browser extension context (icons, permissions, onboarding)
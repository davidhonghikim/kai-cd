# ChatDemon Agent Interaction Shortcuts

These shortcuts are commands for interacting with AI coding agents (like me) to help with development tasks.

## Quick Commands

| Command | Description |
|---------|-------------|
| `/h` | Show help menu |
| `/c` | Continue with the current task |
| `/a` | Enable agent autopilot mode |
| `/u` | Update shortcuts documentation |

## Development Commands

| Command | Description |
|---------|-------------|
| `/g` | Handle Git operations based on context |
| `/b` | Handle backup of project using backup system |

## Documentation Commands

| Command | Description |
|---------|-------------|
| `/md reload` | Reload all markdown files |
| `/md update` | Update markdown documentation |
| `/md list` | List all markdown files |
| `/md show <name>` | Show specific markdown content |
| `/md edit <name>` | Edit specific markdown file |

## Agent Autopilot Mode

When enabled, the agent will:

1. **Automated Development**
   - Proactively identify and fix issues
   - Suggest improvements
   - Maintain code quality
   - Follow best practices

2. **Code Quality**
   - Automatically fix linter errors
   - Maintain consistent code style
   - Monitor code complexity
   - Suggest optimizations

3. **Project Management**
   - Track project progress
   - Maintain documentation
   - Monitor dependencies
   - Suggest updates

4. **Task Automation**
   - Break down complex tasks
   - Create implementation plans
   - Handle routine tasks
   - Maintain task history

## Usage Examples

```
# Show help menu
/h

# Continue with current task
/c

# Enable agent autopilot
/a

# Git operations (agent will handle based on context)
/g

# Create backup
/b

# Documentation operations
/md reload
/md update
/md show "13-Shortcuts"
```

## Best Practices

1. Use descriptive commands
2. Keep commands short and memorable
3. Group related commands together
4. Document all commands
5. Test new commands before using
6. Use consistent formatting and naming conventions

## Adding New Shortcuts

To add a new shortcut:

1. Add the command to the appropriate section in this file
2. Document the command's purpose and usage
3. Test the command with the agent
4. Update this documentation

## Note

These shortcuts are for interacting with AI coding agents and are not part of the ChatDemon extension functionality. They help streamline the development process by providing quick commands for common agent interactions. 
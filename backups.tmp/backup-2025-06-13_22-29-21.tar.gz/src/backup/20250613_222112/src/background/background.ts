import { Server, Servers, ApiResponse, ChromeMessage, ChromeSender } from '../utils/types';
import { DEFAULT_MODEL_ID, DEFAULT_SERVERS } from '../utils/constants';
import { createConnector } from '../connectors/index';

// --- Storage Functions ---
async function getStorage(key: string): Promise<unknown> {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => {
      resolve(result[key]);
    });
  });
}

async function setStorage(key: string, value: unknown): Promise<void> {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, resolve);
  });
}

// --- Server Management Functions ---
async function initializeServerConfigs(): Promise<void> {
  const servers = await getStorage('servers');
  if (!servers) {
    await setStorage('servers', DEFAULT_SERVERS);
  }
}

async function getActiveServer(): Promise<Server | null> {
  const servers = await getStorage('servers') as Servers;
  if (!servers) return null;
  
  for (const server of Object.values(servers)) {
    if (server.active) {
      return server;
    }
  }
  return null;
}

async function testConnection(server: Server): Promise<boolean> {
  const connector = createConnector(server);
  if (!connector) {
    console.error(`No connector found for server type: ${server.type}`);
    return false;
  }
  return connector.testConnection(server);
}

// --- Message Handlers ---
async function handleApiProxy(request: ChromeMessage, sendResponse: (response: ApiResponse) => void): Promise<void> {
  const activeServer = await getActiveServer();
  if (!activeServer) {
    sendResponse({ success: false, error: 'No active server found' });
    return;
  }

  const connector = createConnector(activeServer);
  if (!connector) {
    sendResponse({ success: false, error: `No connector found for server type: ${activeServer.type}` });
    return;
  }

  try {
    const response = await connector.chat(activeServer, request.message || '', request.modelId || DEFAULT_MODEL_ID);
    sendResponse({ success: true, data: response });
  } catch (error) {
    console.error('Error in API proxy:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
}

async function handleGetServers(sendResponse: (response: ApiResponse<Servers>) => void): Promise<void> {
  try {
    let servers = await getStorage('servers') as Servers;
    
    // If no servers found, initialize with defaults and save them
    if (!servers || Object.keys(servers).length === 0) {
      servers = DEFAULT_SERVERS;
      await setStorage('servers', servers);
      console.log('Initialized default servers:', servers);
    }
    
    sendResponse({ success: true, data: servers, servers: servers });
  } catch (error) {
    console.error('Error getting servers:', error);
    sendResponse({ success: true, data: DEFAULT_SERVERS, servers: DEFAULT_SERVERS });
  }
}

async function handleSaveServers(servers: Record<string, unknown>, sendResponse: (response: ApiResponse) => void): Promise<void> {
  try {
    console.log('Saving servers:', servers);
    if (!servers || typeof servers !== 'object') {
      throw new Error('Invalid servers object');
    }
    // Get current servers to preserve existing data
    const currentServers = await getStorage('servers') || {};
    // Merge: update only the provided servers, keep the rest
    const updatedServers: Record<string, unknown> = { ...currentServers };
    Object.entries(servers).forEach(([id, server]) => {
      if (server && typeof server === 'object' && 'type' in server) {
        const defaultServer = DEFAULT_SERVERS[(server as Server).type] || DEFAULT_SERVERS.openwebui;
        updatedServers[id] = {
          ...defaultServer,
          ...updatedServers[id],
          ...server,
          id,
          endpoints: defaultServer.endpoints
        };
      }
    });
    // If any server is set to active, deactivate all others
    const activatingId = Object.entries(servers).find(([_, s]) => (s && typeof s === 'object' && 'active' in s && (s as Server).active))?.[0];
    if (activatingId) {
      Object.entries(updatedServers).forEach(([id, server]) => {
        if (server && typeof server === 'object') {
          (server as Server).active = (id === activatingId);
        }
      });
    }
    await setStorage('servers', updatedServers);
    console.log('Servers saved successfully:', updatedServers);
    sendResponse({ success: true, servers: updatedServers });
  } catch (error) {
    console.error('Error saving servers:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : String(error) });
  }
}

async function handleTestConnection(server: Server, sendResponse: (response: ApiResponse) => void): Promise<void> {
  try {
    const isConnected = await testConnection(server);
    sendResponse({ success: isConnected });
  } catch (error) {
    console.error('Error testing connection:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
}

async function handleOpenInTab(): Promise<ApiResponse<{ tabId: number }>> {
  try {
    const tab = await chrome.tabs.create({ url: chrome.runtime.getURL('ui/static/index.html') });
    return { success: true, data: { tabId: tab.id! } };
  } catch (error) {
    console.error('Error opening in tab:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// --- Event Listeners ---
chrome.runtime.onInstalled.addListener(() => {
  initializeServerConfigs();
});

// Initialize server configs when background script loads
initializeServerConfigs();

chrome.runtime.onMessage.addListener((message: ChromeMessage, sender: ChromeSender, sendResponse: (response: ApiResponse) => void): boolean => {
  switch (message.action) {
    case 'api_proxy':
      handleApiProxy(message, sendResponse);
      break;
    case 'get_servers':
      handleGetServers(sendResponse);
      break;
    case 'save_servers':
      handleSaveServers(message.servers!, sendResponse);
      break;
    case 'test_connection':
      handleTestConnection(message.server!, sendResponse);
      break;
    case 'open_in_tab':
      handleOpenInTab().then(sendResponse);
      break;
    default:
      sendResponse({ success: false, error: 'Unknown action' });
  }
  return true;
});

console.log('Background script loaded.'); 
export * from './base';
export * from './openwebui';
export * from './ollama';
export * from './a1111';
export * from './comfyui';
export * from './generic-openai';
export * from './custom';

import type { ServerType, Server } from '@utils/types';
import { SERVER_SOFTWARE } from '@utils/constants';
import { A1111Connector } from './a1111';
import { ComfyUIConnector } from './comfyui';
import { CustomConnector } from './custom';
import { GenericOpenAIConnector } from './generic-openai';
import { OllamaConnector } from './ollama';
import { OpenWebUIConnector } from './openwebui';
import type { ServiceConnector } from './base';

// Map of server types to their connector implementations
export const serviceConnectors: Record<ServerType, new (server: Server) => ServiceConnector> = {
  [SERVER_SOFTWARE.OPENWEBUI]: OpenWebUIConnector,
  [SERVER_SOFTWARE.OLLAMA]: OllamaConnector,
  [SERVER_SOFTWARE.A1111]: A1111Connector,
  [SERVER_SOFTWARE.COMFYUI]: ComfyUIConnector,
  [SERVER_SOFTWARE.CUSTOM]: CustomConnector,
  generic_openai: GenericOpenAIConnector
};

// Helper function to create a connector instance
export function createConnector(server: Server): ServiceConnector {
  const ConnectorClass = serviceConnectors[server.type];
  if (!ConnectorClass) {
    throw new Error(`No connector found for server type: ${server.type}`);
  }
  return new ConnectorClass(server);
} 
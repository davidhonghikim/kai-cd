import type { Server } from '@utils/types';

export interface ServiceConnector {
  getModels: (server: Server) => Promise<string[]>;
  chat: (server: Server, message: string, modelId: string) => Promise<string>;
  testConnection: (server: Server) => Promise<boolean>;
}

export abstract class BaseConnector implements ServiceConnector {
  protected server: Server;

  constructor(server: Server) {
    this.server = server;
  }

  protected getHeaders(extraHeaders?: HeadersInit): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (this.server.apiKey) {
      headers['Authorization'] = `Bearer ${this.server.apiKey}`;
    }
    if (extraHeaders) {
      if (typeof extraHeaders === 'object' && !Array.isArray(extraHeaders)) {
        Object.entries(extraHeaders as Record<string, string>).forEach(([k, v]) => {
          headers[k] = v;
        });
      }
    }
    return headers;
  }

  protected async fetchWithAuth(url: string, server: Server, options: RequestInit = {}): Promise<Response> {
    const headers = this.getHeaders(options.headers);
    return fetch(url, { ...options, headers });
  }

  protected handleError(error: unknown, context: string): never {
    console.error(`Error in ${context}:`, error);
    throw error instanceof Error ? error : new Error(String(error));
  }

  abstract getModels(server: Server): Promise<string[]>;
  abstract chat(server: Server, message: string, modelId: string): Promise<string>;
  abstract testConnection(server: Server): Promise<boolean>;
} 
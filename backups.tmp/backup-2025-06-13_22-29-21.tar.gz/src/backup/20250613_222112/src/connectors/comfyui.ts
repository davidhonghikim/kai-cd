import type { Server } from '@utils/types';
import { BaseConnector } from './base';

interface ComfyUIHistory {
  models?: string[];
}

interface ComfyUIPromptPayload {
  prompt: string;
  model: string;
}

export class ComfyUIConnector extends BaseConnector {
  async getModels(server: Server): Promise<string[]> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/api/history`,
        server
      );
      
      if (!response.ok) {
        throw new Error(`Failed to get ComfyUI models: ${response.statusText}`);
      }
      
      const data = await response.json() as ComfyUIHistory;
      return data.models || [];
    } catch (error) {
      this.handleError(error, 'ComfyUI getModels');
      return [];
    }
  }
  
  async chat(server: Server, message: string, modelId: string): Promise<string> {
    try {
      const payload: ComfyUIPromptPayload = {
        prompt: message,
        model: modelId || 'default'
      };
      
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/api/prompt`,
        server,
        {
          method: 'POST',
          body: JSON.stringify(payload)
        }
      );
      
      if (!response.ok) {
        throw new Error(`ComfyUI prompt failed: ${response.statusText}`);
      }
      
      await response.json();
      return `Processed prompt: "${message}"`;
    } catch (error) {
      this.handleError(error, 'ComfyUI prompt');
      return '';
    }
  }
  
  async testConnection(server: Server): Promise<boolean> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/api/history`,
        server
      );
      return response.ok;
    } catch (error) {
      console.error('Error testing ComfyUI connection:', error);
      return false;
    }
  }
} 
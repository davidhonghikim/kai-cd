import { BaseConnector } from './base';
import type { Server } from '@utils/types';
import { DEFAULT_MODEL_ID } from '@utils/constants';
import type { OpenAICompletionsRequest, OpenAICompletionsResponse } from '@utils/types';

export class OpenWebUIConnector extends BaseConnector {
  async getModels(server: Server): Promise<string[]> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/api/models`,
        server
      );
      
      if (!response.ok) {
        throw new Error(`Failed to get models: ${response.statusText}`);
      }
      
      const data = await response.json();
      // Support both 'models' and 'data' (array of models)
      if (Array.isArray(data)) return data;
      if (Array.isArray(data.models)) return data.models;
      if (Array.isArray(data.data)) return data.data;
      return [];
    } catch (error) {
      this.handleError(error, 'OpenWebUI getModels');
    }
  }
  
  async chat(server: Server, message: string, modelId: string): Promise<string> {
    try {
      const fullApiUrl = `http://${server.ip}:${server.port}${server.endpoints.chat}`;
      
      const body: OpenAICompletionsRequest = {
        model: modelId || DEFAULT_MODEL_ID,
        messages: [{ role: "user", content: message }]
      };
      
      const response = await this.fetchWithAuth(fullApiUrl, server, {
        method: 'POST',
        body: JSON.stringify(body)
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server returned an error: ${response.status} - ${errorText || response.statusText}`);
      }
      
      const responseData: OpenAICompletionsResponse = await response.json();
      const aiMessage = responseData.choices?.[0]?.message?.content;
      
      if (!aiMessage) {
        throw new Error('No message content in response');
      }
      
      return aiMessage;
    } catch (error) {
      this.handleError(error, 'OpenWebUI chat');
    }
  }
  
  async testConnection(server: Server): Promise<boolean> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/api/status`,
        server
      );
      return response.ok;
    } catch (error) {
      console.error('Error testing OpenWebUI connection:', error);
      return false;
    }
  }
} 
import type { Server } from '@utils/types';
import type { OpenAICompletionsRequest, OpenAICompletionsResponse } from '@utils/types';
import { BaseConnector } from './base';

interface OpenAIModel {
  id: string;
}

interface OpenAIModelsResponse {
  data: OpenAIModel[];
}

export class GenericOpenAIConnector extends BaseConnector {
  async getModels(server: Server): Promise<string[]> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/v1/models`,
        server
      );
      
      if (!response.ok) {
        throw new Error(`Failed to get OpenAI models: ${response.statusText}`);
      }
      
      const data = await response.json() as OpenAIModelsResponse;
      return data.data.map((model) => model.id);
    } catch (error) {
      this.handleError(error, 'Generic OpenAI getModels');
      return [];
    }
  }
  
  async chat(server: Server, message: string, modelId: string): Promise<string> {
    try {
      const fullApiUrl = `http://${server.ip}:${server.port}/v1/chat/completions`;
      
      const body: OpenAICompletionsRequest = {
        model: modelId || 'gpt-3.5-turbo',
        messages: [{ role: "user", content: message }]
      };
      
      const response = await this.fetchWithAuth(fullApiUrl, server, {
        method: 'POST',
        body: JSON.stringify(body)
      });
      
      if (!response.ok) {
        throw new Error(`OpenAI chat failed: ${response.statusText}`);
      }
      
      const responseData: OpenAICompletionsResponse = await response.json();
      const aiMessage = responseData.choices?.[0]?.message?.content;
      
      if (!aiMessage) {
        throw new Error('No message content in response');
      }
      
      return aiMessage;
    } catch (error) {
      this.handleError(error, 'Generic OpenAI chat');
      return '';
    }
  }
  
  async testConnection(server: Server): Promise<boolean> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/v1/models`,
        server
      );
      return response.ok;
    } catch (error) {
      console.error('Error testing Generic OpenAI connection:', error);
      return false;
    }
  }
} 
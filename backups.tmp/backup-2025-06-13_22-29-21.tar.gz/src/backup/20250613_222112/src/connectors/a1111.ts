import type { Server } from '@utils/types';
import { BaseConnector } from './base';

interface A1111Model {
  title?: string;
  name?: string;
}

interface A1111ImagePayload {
  prompt: string;
  negative_prompt: string;
  steps: number;
  sampler_name: string;
  width: number;
  height: number;
  cfg_scale: number;
}

export class A1111Connector extends BaseConnector {
  async getModels(server: Server): Promise<string[]> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/sdapi/v1/sd-models`,
        server
      );
      
      if (!response.ok) {
        throw new Error(`Failed to get A1111 models: ${response.statusText}`);
      }
      
      const models = await response.json() as A1111Model[];
      return models.map((model) => model.title || model.name || '');
    } catch (error) {
      this.handleError(error, 'A1111 getModels');
      return [];
    }
  }
  
  async chat(server: Server, message: string): Promise<string> {
    try {
      // A1111 doesn't support chat, but we can generate an image from text
      const payload: A1111ImagePayload = {
        prompt: message,
        negative_prompt: "",
        steps: 20,
        sampler_name: "Euler a",
        width: 512,
        height: 512,
        cfg_scale: 7
      };
      
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/sdapi/v1/txt2img`,
        server,
        {
          method: 'POST',
          body: JSON.stringify(payload)
        }
      );
      
      if (!response.ok) {
        throw new Error(`A1111 image generation failed: ${response.statusText}`);
      }
      
      await response.json();
      return `Generated image with prompt: "${message}"`;
    } catch (error) {
      this.handleError(error, 'A1111 image generation');
      return '';
    }
  }
  
  async testConnection(server: Server): Promise<boolean> {
    try {
      const response = await this.fetchWithAuth(
        `http://${server.ip}:${server.port}/sdapi/v1/sd-models`,
        server
      );
      return response.ok;
    } catch (error) {
      console.error('Error testing A1111 connection:', error);
      return false;
    }
  }
} 
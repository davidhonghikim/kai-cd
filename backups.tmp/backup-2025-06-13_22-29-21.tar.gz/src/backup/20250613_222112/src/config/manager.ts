import { DEFAULT_MODEL_ID } from '@utils/constants';
import type { ServerConfig, ChatConfig, AppConfig, ExportData } from './types';

class ConfigManager {
  private static instance: ConfigManager;
  private servers: ServerConfig[] = [];
  private chatConfig: ChatConfig = {
    modelId: DEFAULT_MODEL_ID,
    temperature: 0.7,
    maxTokens: 2000,
    contextWindow: 4096
  };
  private appConfig: AppConfig = {
    theme: 'system',
    fontSize: 14,
    autoSave: true,
    notifications: true,
    contextWindow: 4096
  };

  constructor() {
    this.loadConfig();
  }

  public static getInstance(): ConfigManager {
    if (!ConfigManager.instance) {
      ConfigManager.instance = new ConfigManager();
    }
    return ConfigManager.instance;
  }

  private async loadConfig(): Promise<void> {
    try {
      const result = await new Promise<Record<string, unknown>>((resolve) => {
        chrome.storage.local.get(['servers', 'chatConfig', 'appConfig'], resolve);
      });
      
      if (result.servers) {
        this.servers = result.servers as ServerConfig[];
      }
      if (result.chatConfig) {
        this.chatConfig = { ...this.chatConfig, ...(result.chatConfig as Partial<ChatConfig>) };
      }
      if (result.appConfig) {
        this.appConfig = { ...this.appConfig, ...(result.appConfig as Partial<AppConfig>) };
      }
    } catch (error) {
      console.error('Error loading config:', error);
    }
  }

  private async saveConfig(): Promise<void> {
    try {
      await new Promise<void>((resolve) => {
        chrome.storage.local.set({
          servers: this.servers,
          chatConfig: this.chatConfig,
          appConfig: this.appConfig
        }, resolve);
      });
    } catch (error) {
      console.error('Error saving config:', error);
    }
  }

  // Server Management
  public getServers(): ServerConfig[] {
    return this.servers;
  }

  public async addServer(server: ServerConfig): Promise<void> {
    this.servers.push(server);
    await this.saveConfig();
  }

  public async updateServer(id: string, updates: Partial<ServerConfig>): Promise<void> {
    const serverIndex = this.servers.findIndex(server => server.id === id);
    if (serverIndex !== -1) {
      this.servers[serverIndex] = { ...this.servers[serverIndex], ...updates };
      await this.saveConfig();
    }
  }

  public async deleteServer(id: string): Promise<void> {
    this.servers = this.servers.filter(server => server.id !== id);
    await this.saveConfig();
  }

  public getActiveServer(): ServerConfig | null {
    return this.servers.find(server => server.active) || null;
  }

  // Chat Configuration
  public getChatConfig(): ChatConfig {
    return this.chatConfig;
  }

  public async updateChatConfig(updates: Partial<ChatConfig>): Promise<void> {
    this.chatConfig = { ...this.chatConfig, ...updates };
    await this.saveConfig();
  }

  // Application Configuration
  public getAppConfig(): AppConfig {
    return this.appConfig;
  }

  public async updateAppConfig(updates: Partial<AppConfig>): Promise<void> {
    this.appConfig = { ...this.appConfig, ...updates };
    await this.saveConfig();
  }

  // Export/Import
  public exportConfig(): ExportData {
    return {
      servers: this.servers,
      chatConfig: this.chatConfig,
      appConfig: this.appConfig
    };
  }

  public async importConfig(data: ExportData): Promise<void> {
    this.servers = data.servers;
    this.chatConfig = data.chatConfig;
    this.appConfig = data.appConfig;
    await this.saveConfig();
  }
}

export const configManager = ConfigManager.getInstance(); 
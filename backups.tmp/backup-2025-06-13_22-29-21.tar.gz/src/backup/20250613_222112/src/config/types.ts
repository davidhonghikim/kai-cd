import type { Server, ChatConfig as BaseChatConfig, AppConfig as BaseAppConfig } from '@utils/types';

export interface ServerConfig extends Server {
  settings: {
    timeout: number;
    maxRetries: number;
    temperature?: number;
    maxTokens?: number;
  };
}

export interface ChatConfig extends BaseChatConfig {
  contextWindow?: number;
}

export interface AppConfig extends BaseAppConfig {
  contextWindow?: number;
}

export interface ExportData {
  servers: ServerConfig[];
  chatConfig: ChatConfig;
  appConfig: AppConfig;
} 
// --- Type Definitions for Clarity ---
export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface OpenAICompletionsRequest {
  model: string;
  messages: ChatMessage[];
}

export interface OpenAICompletionsResponse {
  choices?: Array<{
    message?: {
      content?: string;
    };
  }>;
}

export interface ServerEndpoints {
  chat: string;
  health: string;
  models?: string;  // Optional models endpoint
}

export type ServerType = 
  | 'openwebui'
  | 'ollama'
  | 'a1111'
  | 'comfyui'
  | 'generic_openai'
  | 'custom';

export interface Server {
  id: string;
  name: string;
  type: ServerType;
  ip: string;
  port: number;
  active: boolean;
  apiKey?: string;
  endpoints: ServerEndpoints;
}

export interface Servers {
  [key: string]: Server;
}

export interface ServiceConnector {
  getModels: (server: Server) => Promise<string[]>;
  chat: (server: Server, message: string, modelId: string) => Promise<string>;
  testConnection: (server: Server) => Promise<boolean>;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  servers?: Servers; // Added for backward compatibility with UI
}

export type ChromeMessageAction = 
  | 'api_proxy'
  | 'get_servers'
  | 'save_servers'
  | 'test_connection'
  | 'open_in_tab';

export interface ChromeMessage {
  action: ChromeMessageAction;
  message?: string;
  modelId?: string;
  servers?: Servers;
  server?: Server;
}

export interface ChromeSender {
  tab?: {
    id: number;
  };
}

export interface ChatConfig {
  modelId: string;
  temperature: number;
  maxTokens: number;
  systemPrompt?: string;
}

export interface AppConfig {
  theme: 'light' | 'dark' | 'system';
  fontSize: number;
  autoSave: boolean;
  notifications: boolean;
} 
// Type definitions for Chrome extension API
declare namespace chrome {
  namespace runtime {
    function getManifest(): any;
    function getURL(path: string): string;
    function sendMessage(message: any, responseCallback?: (response: any) => void): void;
    const onInstalled: {
      addListener(callback: (details: { reason: string }) => void): void;
    };
    const onMessage: {
      addListener(callback: (message: any, sender: any, sendResponse: (response?: any) => void) => void): void;
    };
  }
  
  namespace storage {
    namespace local {
      function get(keys: string | string[] | object | null, callback: (items: { [key: string]: any }) => void): void;
      function set(items: object, callback?: () => void): void;
      function remove(keys: string | string[], callback?: () => void): void;
    }
  }

  namespace tabs {
    function query(queryInfo: any, callback: (result: any[]) => void): void;
    function create(createProperties: { url: string }): Promise<chrome.tabs.Tab>;
    function sendMessage(tabId: number, message: any, responseCallback?: (response: any) => void): void;
  }

  namespace contextMenus {
    function create(createProperties: any, callback?: () => void): number | string;
    function removeAll(callback?: () => void): void;
  }
} 
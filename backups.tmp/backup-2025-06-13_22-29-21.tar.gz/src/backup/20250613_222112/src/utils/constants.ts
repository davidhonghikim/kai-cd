import type { Server } from './types';

/**
 * User-facing names for server software options.
 * Keys are uppercase for enum-like usage, values are lowercase for storage/logic.
 * @readonly
 * @enum {string}
 */
export const SERVER_SOFTWARE = {
  OPENWEBUI: 'openwebui',
  A1111: 'a1111',
  COMFYUI: 'comfyui',
  OLLAMA: 'ollama',
  CUSTOM: 'custom'
} as const;

/**
 * Default network ports for common LLM/AI servers.
 * @readonly
 * @enum {number}
 */
export const DEFAULT_PORTS = {
  [SERVER_SOFTWARE.OPENWEBUI]: 3000,
  [SERVER_SOFTWARE.A1111]: 7860,
  [SERVER_SOFTWARE.COMFYUI]: 8069,
  [SERVER_SOFTWARE.OLLAMA]: 11434
} as const;

/**
 * Internal type identifiers for server configurations, driving API logic.
 * @readonly
 * @enum {string}
 */
export const INTERNAL_SERVER_TYPES = {
  OPENWEBUI: 'openwebui',
  OLLAMA: 'ollama',
  A1111: 'a1111',
  COMFYUI: 'comfyui',
  GENERIC_OPENAI: 'generic_openai',
  CUSTOM: 'custom'
} as const;

/**
 * Default API endpoint paths for different internal server types.
 * These are relative paths; the base URL comes from server configuration.
 * @readonly
 * @type {Object<INTERNAL_SERVER_TYPES, Object<string, string>>}
 */
export const DEFAULT_ENDPOINTS = {
  [SERVER_SOFTWARE.OPENWEBUI]: {
    models: '/api/models',
    chat: '/api/chat',
    health: '/api/health'
  },
  [SERVER_SOFTWARE.A1111]: {
    models: '/sdapi/v1/sd-models',
    chat: '/sdapi/v1/txt2img',
    health: '/sdapi/v1/sd-models'
  },
  [SERVER_SOFTWARE.COMFYUI]: {
    models: '/api/models',
    chat: '/api/prompt',
    health: '/api/history'
  },
  [SERVER_SOFTWARE.OLLAMA]: {
    models: '/api/tags',
    chat: '/api/generate',
    health: '/api/tags'
  }
} as const;

// API base URLs
export const API_BASE_URLS = {
  WEBUI: '/api',
  OLLAMA: '/api',
  A1111: '/sdapi/v1',
  COMFYUI: '/api',
  GENERIC_OPENAI: '/v1',
  CUSTOM: '/api'
} as const;

// Default model ID that OpenWebUI instance recognizes
export const DEFAULT_MODEL_ID = 'gpt-3.5-turbo';

// This is a common endpoint for OpenWebUI when it's set to be OpenAI-compatible
export const OPENAI_COMPATIBLE_CHAT_ENDPOINT = '/v1/chat/completions';

// Default server configurations
export const DEFAULT_SERVERS: Record<string, Server> = {
  openwebui: {
    id: 'openwebui',
    name: 'Open-WebUI',
    type: SERVER_SOFTWARE.OPENWEBUI,
    ip: '192.168.1.180',
    port: DEFAULT_PORTS[SERVER_SOFTWARE.OPENWEBUI],
    active: true,
    endpoints: DEFAULT_ENDPOINTS[SERVER_SOFTWARE.OPENWEBUI]
  },
  a1111: {
    id: 'a1111',
    name: 'A1111',
    type: SERVER_SOFTWARE.A1111,
    ip: '192.168.1.180',
    port: DEFAULT_PORTS[SERVER_SOFTWARE.A1111],
    active: false,
    endpoints: DEFAULT_ENDPOINTS[SERVER_SOFTWARE.A1111]
  },
  comfyui: {
    id: 'comfyui',
    name: 'ComfyUI',
    type: SERVER_SOFTWARE.COMFYUI,
    ip: '192.168.1.180',
    port: DEFAULT_PORTS[SERVER_SOFTWARE.COMFYUI],
    active: false,
    endpoints: DEFAULT_ENDPOINTS[SERVER_SOFTWARE.COMFYUI]
  },
  ollama: {
    id: 'ollama',
    name: 'Ollama',
    type: SERVER_SOFTWARE.OLLAMA,
    ip: 'localhost',
    port: DEFAULT_PORTS[SERVER_SOFTWARE.OLLAMA],
    active: false,
    endpoints: DEFAULT_ENDPOINTS[SERVER_SOFTWARE.OLLAMA]
  }
}; 
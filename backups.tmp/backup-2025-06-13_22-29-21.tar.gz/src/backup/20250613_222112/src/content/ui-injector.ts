// UI injector for OpenWebUI
interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

function injectNewGroupChatButton(): void {
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar) return;

  const button = document.createElement('button');
  button.className = 'new-group-chat-btn';
  button.textContent = 'New Group Chat';
  button.onclick = (): void => {
    // Create new group chat
    const chatId = Date.now().toString();
    chrome.runtime.sendMessage({
      action: 'createGroupChat',
      chatId
    });
  };

  sidebar.appendChild(button);
}

function injectManageConnectionsButton(): void {
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar) return;

  const button = document.createElement('button');
  button.className = 'manage-connections-btn';
  button.textContent = 'Manage Connections';
  button.onclick = (): void => {
    chrome.runtime.sendMessage({ action: 'openConnectionsPanel' });
  };

  sidebar.appendChild(button);
}

function setGroupChatTitle(title: string): void {
  const titleElement = document.querySelector('.chat-title');
  if (titleElement) {
    titleElement.textContent = title;
  }
}

function displayMessage(message: ChatMessage): void {
  const chatWindow = document.querySelector('.chat-window');
  if (!chatWindow) return;

  const messageElement = document.createElement('div');
  messageElement.className = `message ${message.role}`;
  messageElement.textContent = message.content;

  chatWindow.appendChild(messageElement);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

// Monitor chat input area
const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    if (mutation.type === 'childList') {
      const chatInput = document.querySelector('.chat-input');
      if (chatInput) {
        chatInput.addEventListener('keypress', (e: Event) => {
          const keyEvent = e as KeyboardEvent;
          if (keyEvent.key === 'Enter' && !keyEvent.shiftKey) {
            e.preventDefault();
            const content = (chatInput as HTMLTextAreaElement).value;
            if (content.trim()) {
              chrome.runtime.sendMessage({
                action: 'sendMessage',
                content
              });
              (chatInput as HTMLTextAreaElement).value = '';
            }
          }
        });
      }
    }
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Listen for messages from the extension
chrome.runtime.onMessage.addListener((message: { action: string; title?: string; message?: ChatMessage }) => {
  if (message.action === 'setTitle' && message.title) {
    setGroupChatTitle(message.title);
  } else if (message.action === 'displayMessage' && message.message) {
    displayMessage(message.message);
  }
  return true;
});

// Initialize UI
injectNewGroupChatButton();
injectManageConnectionsButton(); 
// Content script for interacting with web pages
function getSelectedText(): string {
  const selection = window.getSelection();
  return selection ? selection.toString().trim() : '';
}

// Listen for messages from the extension
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getSelectedText') {
    sendResponse({ text: getSelectedText() });
  } else if (message.action === 'getPageInfo') {
    const metaDescription = document.querySelector('meta[name="description"]');
    sendResponse({
      title: document.title,
      url: window.location.href,
      description: metaDescription ? (metaDescription as HTMLMetaElement).content || '' : ''
    });
  }
  return true;
}); 
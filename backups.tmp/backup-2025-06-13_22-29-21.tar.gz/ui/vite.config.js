import { defineConfig } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import { resolve } from 'path';

export default defineConfig({
	plugins: [svelte()],
	build: {
		outDir: '../dist/ui',
		emptyOutDir: true,
		rollupOptions: {
			input: {
				panel: resolve(__dirname, 'panel.html'),
				tab: resolve(__dirname, 'tab.html')
			},
			output: {
				entryFileNames: '[name].js',
				chunkFileNames: '[name].js',
				assetFileNames: '[name].[ext]'
			}
		}
	},
	resolve: {
		alias: {
			$lib: resolve(__dirname, 'src/lib')
		}
	}
}); 
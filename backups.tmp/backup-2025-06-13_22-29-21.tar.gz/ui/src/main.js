import App from './App.svelte'
// Import API proxy to intercept fetch calls
import './lib/apis/proxy.js'

const app = new App({
  target: document.getElementById('app'),
})

export default app

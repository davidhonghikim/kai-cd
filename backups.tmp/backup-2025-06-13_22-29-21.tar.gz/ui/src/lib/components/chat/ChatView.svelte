<script lang="ts">
  import Messages from './Messages.svelte';
  import MessageInput from './MessageInput.svelte';

  // This will be the new, simplified chat view.
  // We will build out the new UI here.
</script>

<div class="flex flex-col h-full">
  <div class="flex-grow overflow-y-auto">
    <Messages />
  </div>
  <div class="p-4">
    <MessageInput />
  </div>
</div> 
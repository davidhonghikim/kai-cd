<script lang="ts">
	import { getContext, onMount } from 'svelte';
	import { toast } from 'svelte-sonner';
	import { settings } from '$lib/stores';
	
	import Modal from '$lib/components/common/Modal.svelte';
	import Plus from '$lib/components/icons/Plus.svelte';
	import Minus from '$lib/components/icons/Minus.svelte';
	import PencilSolid from '$lib/components/icons/PencilSolid.svelte';
	import Switch from '$lib/components/common/Switch.svelte';
	import Tooltip from '$lib/components/common/Tooltip.svelte';
	import SensitiveInput from '$lib/components/common/SensitiveInput.svelte';
	
	const i18n = getContext('i18n');
	
	// Server types and default ports
	const SERVER_TYPES = [
		{ id: 'openwebui', name: 'Open-WebUI', port: 3000 },
		{ id: 'a1111', name: 'A1111', port: 7860 },
		{ id: 'comfyui', name: 'ComfyUI', port: 8069 },
		{ id: 'ollama', name: 'Ollama', port: 11434 }
	];
	
	// Default server configurations
	const DEFAULT_SERVERS = {
		openwebui: {
			id: 'openwebui',
			name: 'Open-WebUI',
			type: 'openwebui',
			ip: '192.168.1.180',
			port: 3000,
			active: true,
			apiKey: ''
		},
		a1111: {
			id: 'a1111',
			name: 'A1111',
			type: 'a1111',
			ip: '192.168.1.180',
			port: 7860,
			active: false,
			apiKey: ''
		},
		comfyui: {
			id: 'comfyui',
			name: 'ComfyUI',
			type: 'comfyui',
			ip: '192.168.1.180',
			port: 8069,
			active: false,
			apiKey: ''
		},
		ollama: {
			id: 'ollama',
			name: 'Ollama',
			type: 'ollama',
			ip: 'localhost',
			port: 11434,
			active: false,
			apiKey: ''
		}
	};
	
	let servers = [];
	let showAddModal = false;
	let showEditModal = false;
	let currentServer = null;
	let loading = true;
	
	// New server form data
	let newServer = {
		id: '',
		name: '',
		type: 'openwebui',
		ip: '',
		port: 3000,
		active: false,
		apiKey: ''
	};
	
	// Form fields for editing server
	let serverName = '';
	let serverIp = '';
	let serverPort = '';
	let serverType = '';
	let serverApiKey = '';
	
	// Load servers from chrome.storage.local
	async function loadServers() {
		loading = true;
		try {
			const response = await chrome.runtime.sendMessage({ action: 'getServers' });
			if (response.success) {
				servers = Object.entries(response.servers).map(([id, server]) => ({
					id,
					...server
				}));
			} else {
				toast.error('Failed to load servers');
			}
		} catch (error) {
			toast.error(`Error: ${error.message}`);
		} finally {
			loading = false;
		}
	}
	
	// Save servers to chrome.storage.local
	async function saveServers() {
		try {
			const serversObj = servers.reduce((acc, server) => {
				acc[server.id] = server;
				return acc;
			}, {});
			await chrome.storage.local.set({ servers: serversObj });
			toast.success(i18n.t('Servers saved successfully'));
		} catch (error) {
			console.error('Error saving servers:', error);
			toast.error(i18n.t('Failed to save servers'));
		}
	}
	
	// Set a server as active
	function setActive(id) {
		servers = servers.map(server => ({
			...server,
			active: server.id === id
		}));
		saveServers();
	}
	
	// Add a new server
	function addServer() {
		if (!serverName || !serverIp || !serverPort) {
			alert('Please fill in all required fields');
			return;
		}
		
		const id = serverName.trim();
		const newServer = {
			id,
			ip: serverIp.trim(),
			port: serverPort.trim(),
			type: serverType,
			active: false,
			apiKey: serverApiKey.trim()
		};
		
		// Update servers store
		servers.update(current => ({
			...current,
			[id]: newServer
		}));
		
		// Save to Chrome storage
		chrome.runtime.sendMessage({
			action: 'saveServers',
			servers: get(servers)
		});
		
		resetNewServer();
		showAddModal = false;
	}
	
	// Edit an existing server
	function editServer() {
		servers = servers.map(server => 
			server.id === currentServer.id ? currentServer : server
		);
		saveServers();
		currentServer = null;
		showEditModal = false;
	}
	
	// Delete a server
	function deleteServer(id) {
		if (confirm(`Are you sure you want to delete server ${id}?`)) {
			let updatedServers = { ...servers };
			delete updatedServers[id];
			
			// Update store
			servers.set(updatedServers);
			
			// Save to Chrome storage
			chrome.runtime.sendMessage({
				action: 'saveServers',
				servers: updatedServers
			});
		}
	}
	
	// Open edit modal for a server
	function openEditModal(server) {
		currentServer = { ...server };
		showEditModal = true;
	}
	
	// Reset new server form
	function resetNewServer() {
		serverName = '';
		serverIp = '';
		serverPort = '';
		serverType = 'openwebui';
		serverApiKey = '';
		currentServer = null;
	}
	
	// Update port when server type changes
	function updatePort() {
		const serverType = SERVER_TYPES.find(type => type.id === newServer.type);
		if (serverType) {
			newServer.port = serverType.port;
		}
	}
	
	// Update port when server type changes in edit mode
	function updatePortEdit() {
		const serverType = SERVER_TYPES.find(type => type.id === currentServer.type);
		if (serverType) {
			currentServer.port = serverType.port;
		}
	}
	
	// Test connection to a server
	async function testConnection(server) {
		toast.info(i18n.t('Testing connection to {0}...', [server.name]));
		try {
			const url = `http://${server.ip}:${server.port}`;
			const response = await fetch(url, { method: 'HEAD', mode: 'no-cors' });
			toast.success(i18n.t('Connection successful'));
		} catch (error) {
			console.error('Connection test error:', error);
			toast.error(i18n.t('Connection failed'));
		}
	}
	
	// Start editing a server
	function startEdit(server) {
		editingServer = server;
		serverName = server.id;
		serverIp = server.ip;
		serverPort = server.port.toString();
		serverType = server.type;
		serverApiKey = server.apiKey || '';
	}
	
	// Cancel editing a server
	function cancelEdit() {
		editingServer = null;
	}
	
	// Save edited server
	async function saveServer() {
		if (!serverName || !serverIp || !serverPort || !serverType) {
			toast.error('All fields are required');
			return;
		}
		
		const updatedServer = {
			ip: serverIp,
			port: parseInt(serverPort),
			type: serverType,
			active: editingServer.active,
			apiKey: serverApiKey || undefined
		};
		
		const updatedServers = { ...Object.fromEntries(servers.map(s => [s.id, s])) };
		
		// If renaming the server
		if (editingServer.id !== serverName) {
			delete updatedServers[editingServer.id];
		}
		
		updatedServers[serverName] = updatedServer;
		
		try {
			const response = await chrome.runtime.sendMessage({ 
				action: 'saveServers', 
				servers: updatedServers 
			});
			
			if (response.success) {
				toast.success('Server saved');
				await loadServers();
				editingServer = null;
			} else {
				toast.error('Failed to save server');
			}
		} catch (error) {
			toast.error(`Error: ${error.message}`);
		}
	}
	
	// Set a server as active
	async function setActiveServer(server) {
		const updatedServers = { ...Object.fromEntries(servers.map(s => [s.id, {
			...s,
			active: s.id === server.id
		}])) };
		
		try {
			const response = await chrome.runtime.sendMessage({ 
				action: 'saveServers', 
				servers: updatedServers 
			});
			
			if (response.success) {
				toast.success(`${server.id} is now the active server`);
				await loadServers();
			} else {
				toast.error('Failed to update active server');
			}
		} catch (error) {
			toast.error(`Error: ${error.message}`);
		}
	}
	
	// Test server connection
	async function testServerConnection(server) {
		try {
			const response = await chrome.runtime.sendMessage({ 
				action: 'testConnection', 
				server 
			});
			
			if (response.success) {
				toast.success(`Connection to ${server.id} successful`);
			} else {
				toast.error(`Failed to connect to ${server.id}`);
			}
		} catch (error) {
			toast.error(`Error: ${error.message}`);
		}
	}
	
	// Initialize on mount
	onMount(() => {
		loadServers();
		resetNewServer();
	});
</script>

<div class="w-full">
	<div class="flex justify-between items-center mb-4">
		<h2 class="text-lg font-medium dark:text-white">{i18n.t('Server Manager')}</h2>
		<div class="flex justify-end mt-4">
			<button
				class="bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-4 rounded-md dark:bg-primary-800 dark:hover:bg-primary-700"
				on:click={() => {
					// Initialize new server form
					editingServer = {
						id: '',
						ip: '',
						port: '',
						type: 'openwebui',
						active: false,
						apiKey: ''
					};
					
					// Show form for new server
					serverName = '';
					serverIp = '';
					serverPort = '';
					serverType = 'openwebui';
					serverApiKey = '';
				}}
			>
				{i18n.t('Add Server')}
			</button>
		</div>
	</div>
	
	<div class="border rounded-lg dark:border-gray-700 overflow-hidden">
		{#if loading}
			<div class="p-4 text-center text-gray-500 dark:text-gray-400">
				{i18n.t('Loading servers...')}
			</div>
		{:else}
			{#if servers.length === 0}
				<div class="p-4 text-center text-gray-500 dark:text-gray-400">
					{i18n.t('No servers configured. Add a server to get started.')}
				</div>
			{:else}
				<div class="overflow-x-auto">
					<table class="w-full">
						<thead class="bg-gray-50 dark:bg-gray-800">
							<tr>
								<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
									{i18n.t('Name')}
								</th>
								<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
									{i18n.t('Type')}
								</th>
								<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
									{i18n.t('IP/Host')}
								</th>
								<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
									{i18n.t('Port')}
								</th>
								<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
									{i18n.t('Status')}
								</th>
								<th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
									{i18n.t('Actions')}
								</th>
							</tr>
						</thead>
						<tbody class="divide-y divide-gray-200 dark:divide-gray-700">
							{#each servers as server (server.id)}
								<tr class="bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800">
									<td class="px-4 py-3 text-sm text-gray-900 dark:text-white">
										{server.name}
									</td>
									<td class="px-4 py-3 text-sm text-gray-900 dark:text-white">
										{SERVER_TYPES.find(type => type.id === server.type)?.name || server.type}
									</td>
									<td class="px-4 py-3 text-sm text-gray-900 dark:text-white">
										{server.ip}
									</td>
									<td class="px-4 py-3 text-sm text-gray-900 dark:text-white">
										{server.port}
									</td>
									<td class="px-4 py-3 text-sm">
										{#if server.active}
											<span class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
												{i18n.t('Active')}
											</span>
										{:else}
											<button
												class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300 hover:bg-primary-100 dark:hover:bg-primary-900"
												on:click={() => setActive(server.id)}
											>
												{i18n.t('Set Active')}
											</button>
										{/if}
									</td>
									<td class="px-4 py-3 text-sm">
										<div class="flex gap-2">
											<Tooltip content={i18n.t('Test Connection')}>
												<button
													class="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
													on:click={() => testServerConnection(server)}
												>
													<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
														<path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd" />
													</svg>
												</button>
											</Tooltip>
											<Tooltip content={i18n.t('Edit')}>
												<button
													class="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
													on:click={() => startEdit(server)}
												>
													<PencilSolid class="h-4 w-4" />
												</button>
											</Tooltip>
											<Tooltip content={i18n.t('Delete')}>
												<button
													class="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
													on:click={() => deleteServer(server.id)}
												>
													<Minus class="h-4 w-4" />
												</button>
											</Tooltip>
										</div>
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
				</div>
			{/if}
		{/if}
	</div>
</div>

<!-- Add Server Modal -->
<Modal bind:show={showAddModal} size="sm">
	<div class="px-5 pt-4 pb-2 flex justify-between dark:text-gray-100">
		<div class="text-lg font-medium self-center font-primary">
			{i18n.t('Add Server')}
		</div>
		<button
			class="self-center"
			on:click={() => {
				showAddModal = false;
			}}
		>
			<svg
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 20 20"
				fill="currentColor"
				class="w-5 h-5"
			>
				<path
					d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"
				/>
			</svg>
		</button>
	</div>
	
	<form
		class="px-5 pb-5"
		on:submit|preventDefault={addServer}
	>
		<div class="space-y-4">
			<div>
				<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="server-name">
					{i18n.t('Name')}
				</label>
				<input
					id="server-name"
					type="text"
					class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
					required
					bind:value={newServer.name}
				/>
			</div>
			
			<div>
				<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="server-type">
					{i18n.t('Server Type')}
				</label>
				<select
					id="server-type"
					class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
					bind:value={newServer.type}
					on:change={updatePort}
				>
					{#each SERVER_TYPES as type}
						<option value={type.id}>{type.name}</option>
					{/each}
				</select>
			</div>
			
			<div>
				<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="server-ip">
					{i18n.t('IP Address / Hostname')}
				</label>
				<input
					id="server-ip"
					type="text"
					class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
					required
					bind:value={newServer.ip}
				/>
			</div>
			
			<div>
				<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="server-port">
					{i18n.t('Port')}
				</label>
				<input
					id="server-port"
					type="number"
					class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
					required
					bind:value={newServer.port}
				/>
			</div>
			
			<div>
				<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="server-api-key">
					{i18n.t('API Key')} ({i18n.t('Optional')})
				</label>
				<SensitiveInput id="server-api-key" bind:value={newServer.apiKey} />
			</div>
		</div>
		
		<div class="mt-6 flex justify-end gap-3">
			<button
				type="button"
				class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-700"
				on:click={() => {
					showAddModal = false;
				}}
			>
				{i18n.t('Cancel')}
			</button>
			<button
				type="submit"
				class="px-4 py-2 text-sm font-medium text-white bg-primary-500 border border-transparent rounded-md hover:bg-primary-600"
			>
				{i18n.t('Add Server')}
			</button>
		</div>
	</form>
</Modal>

<!-- Edit Server Modal -->
<Modal bind:show={showEditModal} size="sm">
	{#if editingServer}
		<div class="px-5 pt-4 pb-2 flex justify-between dark:text-gray-100">
			<div class="text-lg font-medium self-center font-primary">
				{i18n.t('Edit Server')}
			</div>
			<button
				class="self-center"
				on:click={() => {
					showEditModal = false;
				}}
			>
				<svg
					xmlns="http://www.w3.org/2000/svg"
					viewBox="0 0 20 20"
					fill="currentColor"
					class="w-5 h-5"
				>
					<path
						d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"
					/>
				</svg>
			</button>
		</div>
		
		<form
			class="px-5 pb-5"
			on:submit|preventDefault={saveServer}
		>
			<div class="space-y-4">
				<div>
					<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="edit-server-name">
						{i18n.t('Name')}
					</label>
					<input
						id="edit-server-name"
						type="text"
						class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
						required
						bind:value={serverName}
					/>
				</div>
				
				<div>
					<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="edit-server-type">
						{i18n.t('Server Type')}
					</label>
					<select
						id="edit-server-type"
						class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
						bind:value={serverType}
						on:change={updatePortEdit}
					>
						{#each SERVER_TYPES as type}
							<option value={type.id}>{type.name}</option>
						{/each}
					</select>
				</div>
				
				<div>
					<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="edit-server-ip">
						{i18n.t('IP Address / Hostname')}
					</label>
					<input
						id="edit-server-ip"
						type="text"
						class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
						required
						bind:value={serverIp}
					/>
				</div>
				
				<div>
					<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="edit-server-port">
						{i18n.t('Port')}
					</label>
					<input
						id="edit-server-port"
						type="number"
						class="w-full px-3 py-2 border rounded-md dark:bg-gray-900 dark:text-white dark:border-gray-700"
						required
						bind:value={serverPort}
					/>
				</div>
				
				<div>
					<label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" for="edit-server-api-key">
						{i18n.t('API Key')} ({i18n.t('Optional')})
					</label>
					<SensitiveInput id="edit-server-api-key" bind:value={serverApiKey} />
				</div>
			</div>
			
			<div class="mt-6 flex justify-end gap-3">
				<button
					type="button"
					class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-700"
					on:click={() => {
						showEditModal = false;
					}}
				>
					{i18n.t('Cancel')}
				</button>
				<button
					type="submit"
					class="px-4 py-2 text-sm font-medium text-white bg-primary-500 border border-transparent rounded-md hover:bg-primary-600"
				>
					{i18n.t('Save Changes')}
				</button>
			</div>
		</form>
	{/if}
</Modal> 
<script lang="ts">
  import { onMount } from 'svelte';
  import type { Server, Servers, ServerConfig } from '$lib/types';
  import { SERVER_SOFTWARE } from '$lib/constants';
  
  let servers: Servers = {};
  let newServer: ServerConfig = {
    type: SERVER_SOFTWARE.OPENWEBUI,
    name: '',
    ip: '192.168.1.180',
    port: 3000,
    apiKey: ''
  };
  
  let isAddingServer = false;
  let error: string | null = null;
  let success: string | null = null;

  onMount(async () => {
    const response = await chrome.runtime.sendMessage({ action: 'get_servers' });
    if (response.success) {
      servers = response.servers;
    }
  });

  async function addServer() {
    try {
      error = null;
      success = null;
      
      const response = await chrome.runtime.sendMessage({
        action: 'save_servers',
        servers: {
          [newServer.name]: {
            ...newServer,
            id: newServer.name,
            active: true,
            endpoints: {
              chat: '/api/chat',
              models: '/api/models',
              health: '/api/health'
            }
          }
        }
      });

      if (response.success) {
        servers = response.servers;
        success = 'Server added successfully';
        isAddingServer = false;
        newServer = {
          type: SERVER_SOFTWARE.OPENWEBUI,
          name: '',
          ip: '192.168.1.180',
          port: 3000,
          apiKey: ''
        };
      } else {
        error = response.error || 'Failed to add server';
      }
    } catch (e: any) {
      error = e?.message || 'An unexpected error occurred';
    }
  }

  async function testConnection(server: Server) {
    try {
      error = null;
      success = null;
      
      const response = await chrome.runtime.sendMessage({
        action: 'test_connection',
        server
      });

      if (response.success) {
        success = 'Connection successful';
      } else {
        error = response.error || 'Connection failed';
      }
    } catch (e: any) {
      error = e?.message || 'An unexpected error occurred';
    }
  }

  async function deleteServer(serverId: string) {
    try {
      error = null;
      success = null;
      
      const updatedServers = { ...servers };
      delete updatedServers[serverId];
      
      const response = await chrome.runtime.sendMessage({
        action: 'save_servers',
        servers: updatedServers
      });

      if (response.success) {
        servers = response.servers;
        success = 'Server deleted successfully';
      } else {
        error = response.error || 'Failed to delete server';
      }
    } catch (e: any) {
      error = e?.message || 'An unexpected error occurred';
    }
  }

  async function setActiveServer(serverId: string) {
    try {
      error = null;
      success = null;
      
      const updatedServers = { ...servers };
      Object.keys(updatedServers).forEach(id => {
        updatedServers[id].active = id === serverId;
      });
      
      const response = await chrome.runtime.sendMessage({
        action: 'save_servers',
        servers: updatedServers
      });

      if (response.success) {
        servers = response.servers;
        success = 'Active server updated';
      } else {
        error = response.error || 'Failed to update active server';
      }
    } catch (e: any) {
      error = e?.message || 'An unexpected error occurred';
    }
  }
</script>

<div class="server-manager">
  <h2>Server Management</h2>
  
  {#if error}
    <div class="error">{error}</div>
  {/if}
  
  {#if success}
    <div class="success">{success}</div>
  {/if}

  <div class="servers-list">
    {#each Object.entries(servers) as [id, server]}
      <div class="server-item">
        <div class="server-info">
          <h3>{server.name}</h3>
          <p>{server.type} - {server.ip}:{server.port}</p>
        </div>
        
        <div class="server-actions">
          <button 
            class="test-btn"
            on:click={() => testConnection(server)}
          >
            Test Connection
          </button>
          
          <button 
            class="active-btn"
            class:active={server.active}
            on:click={() => setActiveServer(id)}
          >
            {server.active ? 'Active' : 'Set Active'}
          </button>
          
          <button 
            class="delete-btn"
            on:click={() => deleteServer(id)}
          >
            Delete
          </button>
        </div>
      </div>
    {/each}
  </div>

  <button 
    class="add-server-btn"
    on:click={() => isAddingServer = true}
  >
    Add New Server
  </button>

  {#if isAddingServer}
    <div class="add-server-form">
      <h3>Add New Server</h3>
      
      <div class="form-group">
        <label for="server-type">Server Type</label>
        <select 
          id="server-type"
          bind:value={newServer.type}
        >
          {#each Object.values(SERVER_SOFTWARE) as type}
            <option value={type}>{type}</option>
          {/each}
        </select>
      </div>
      
      <div class="form-group">
        <label for="server-name">Name</label>
        <input 
          id="server-name"
          type="text"
          bind:value={newServer.name}
          placeholder="Server Name"
        />
      </div>
      
      <div class="form-group">
        <label for="server-ip">IP Address</label>
        <input 
          id="server-ip"
          type="text"
          bind:value={newServer.ip}
          placeholder="IP Address"
        />
      </div>
      
      <div class="form-group">
        <label for="server-port">Port</label>
        <input 
          id="server-port"
          type="number"
          bind:value={newServer.port}
          placeholder="Port"
        />
      </div>
      
      <div class="form-group">
        <label for="server-key">API Key (Optional)</label>
        <input 
          id="server-key"
          type="password"
          bind:value={newServer.apiKey}
          placeholder="API Key"
        />
      </div>
      
      <div class="form-actions">
        <button on:click={addServer}>Add Server</button>
        <button on:click={() => isAddingServer = false}>Cancel</button>
      </div>
    </div>
  {/if}
</div>

<style>
  .server-manager {
    padding: 1rem;
  }

  .servers-list {
    margin: 1rem 0;
  }

  .server-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    margin-bottom: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .server-info h3 {
    margin: 0;
    font-size: 1.1rem;
  }

  .server-info p {
    margin: 0.5rem 0 0;
    color: #666;
  }

  .server-actions {
    display: flex;
    gap: 0.5rem;
  }

  .server-actions button {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  .test-btn {
    background-color: #4CAF50;
    color: white;
  }

  .active-btn {
    background-color: #2196F3;
    color: white;
  }

  .active-btn.active {
    background-color: #1976D2;
  }

  .delete-btn {
    background-color: #f44336;
    color: white;
  }

  .add-server-btn {
    width: 100%;
    padding: 1rem;
    background-color: #2196F3;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  .add-server-form {
    margin-top: 1rem;
    padding: 1rem;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .form-group {
    margin-bottom: 1rem;
  }

  .form-group label {
    display: block;
    margin-bottom: 0.5rem;
  }

  .form-group input,
  .form-group select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .form-actions {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
  }

  .form-actions button {
    flex: 1;
    padding: 0.5rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  .form-actions button:first-child {
    background-color: #4CAF50;
    color: white;
  }

  .form-actions button:last-child {
    background-color: #f44336;
    color: white;
  }

  .error {
    color: #f44336;
    margin: 1rem 0;
    padding: 0.5rem;
    background-color: #ffebee;
    border-radius: 4px;
  }

  .success {
    color: #4CAF50;
    margin: 1rem 0;
    padding: 0.5rem;
    background-color: #e8f5e9;
    border-radius: 4px;
  }
</style> 
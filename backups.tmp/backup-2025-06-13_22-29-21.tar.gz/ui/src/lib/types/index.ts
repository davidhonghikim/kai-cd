export type Dict<T = any> = { [key: string]: T };

export interface Banner {
	id: string;
	message: string;
	type: 'info' | 'warning' | 'error' | 'success';
}

export interface ModelConfig {
	// Define model config properties here
	id: string;
	name: string;
	// Add other properties as needed from the original codebase
}

export interface Settings {
	chatDirection: 'ltr' | 'rtl';
	// Add other settings properties from the original codebase
}

export type BaseModel = {
	id: string;
	name: string;
	info?: ModelConfig;
	owned_by: 'ollama' | 'openai' | 'arena';
};

export interface OpenAIModel extends BaseModel {
	owned_by: 'openai';
	external: boolean;
	source?: string;
}

export interface OllamaModel extends BaseModel {
	owned_by: 'ollama';
	details: OllamaModelDetails;
	size: number;
	description: string;
	model: string;
	modified_at: string;
	digest: string;
	ollama?: {
		name?: string;
		model?: string;
		modified_at: string;
		size?: number;
		digest?: string;
		details?: {
			parent_model?: string;
			format?: string;
			family?: string;
			families?: string[];
			parameter_size?: string;
			quantization_level?: string;
		};
		urls?: number[];
	};
}

export type OllamaModelDetails = {
	parent_model: string;
	format: string;
	family: string;
	families: string[] | null;
	parameter_size: string;
	quantization_level: string;
};

export type Prompt = {
	command: string;
	user_id: string;
	title: string;
	content: string;
	timestamp: number;
};

export type Document = {
	collection_name: string;
	filename: string;
	name: string;
	title: string;
};

export type Config = {
	status: boolean;
	name: string;
	version: string;
	default_locale: string;
	default_models: string;
	default_prompt_suggestions: PromptSuggestion[];
	features: {
		auth: boolean;
		auth_trusted_header: boolean;
		enable_api_key: boolean;
		enable_signup: boolean;
		enable_login_form: boolean;
		enable_web_search?: boolean;
		enable_google_drive_integration: boolean;
		enable_onedrive_integration: boolean;
		enable_image_generation: boolean;
		enable_admin_export: boolean;
		enable_admin_chat_access: boolean;
		enable_community_sharing: boolean;
		enable_autocomplete_generation: boolean;
		enable_direct_connections: boolean;
	};
	oauth: {
		providers: {
			[key: string]: string;
		};
	};
	ui?: {
		pending_user_overlay_title?: string;
		pending_user_overlay_description?: string;
	};
};

export type PromptSuggestion = {
	content: string;
	title: [string, string];
};

export type SessionUser = {
	id: string;
	email: string;
	name: string;
	role: string;
	profile_image_url: string;
};

export enum TTS_RESPONSE_SPLIT {
	PUNCTUATION = 'punctuation',
	PARAGRAPHS = 'paragraphs',
	NONE = 'none'
}

export interface Server {
	id: string;
	name: string;
	type: string;
	url: string;
	active: boolean;
	apiKey?: string;
	models?: string[];
}

export interface Servers {
	[key: string]: Server;
}

export interface ChatMessage {
	role: 'user' | 'assistant' | 'system';
	content: string;
	timestamp?: number;
}

export interface Chat {
	id: string;
	title: string;
	messages: ChatMessage[];
	modelId: string;
	serverId: string;
	createdAt: number;
	updatedAt: number;
}

export interface Chats {
	[key: string]: Chat;
}

export interface Model {
	id: string;
	name: string;
	description?: string;
	contextWindow?: number;
	maxTokens?: number;
	temperature?: number;
	topP?: number;
	frequencyPenalty?: number;
	presencePenalty?: number;
}

export interface Models {
	[key: string]: Model;
}

export interface Settings {
	theme: 'light' | 'dark' | 'system';
	fontSize: number;
	maxTokens: number;
	temperature: number;
	topP: number;
	frequencyPenalty: number;
	presencePenalty: number;
	defaultModel: string;
	defaultServer: string;
}

export interface AppState {
	servers: Servers;
	chats: Chats;
	models: Models;
	settings: Settings;
	currentChatId: string | null;
	currentServerId: string | null;
	currentModelId: string | null;
}

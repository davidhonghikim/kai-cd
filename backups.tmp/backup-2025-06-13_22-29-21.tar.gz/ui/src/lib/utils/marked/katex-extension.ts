import katex from 'katex';

const DELIMITER_LIST = [
	{ left: '$$', right: '$$', display: true },
	{ left: '$', right: '$', display: false },
	{ left: '\\pu{', right: '}', display: false },
	{ left: '\\ce{', right: '}', display: false },
	{ left: '\\(', right: '\\)', display: false },
	{ left: '\\[', right: '\\]', display: true },
	{ left: '\\begin{equation}', right: '\\end{equation}', display: true }
];

const ALLOWED_SURROUNDING_CHARS =
	'\\s。，、､;；„"''""（）「」『』［］《》【】‹›«»…⋯:：？！～⇒?!-\\/:-@\\[-`{-~\\p{Script=Han}\\p{Script=Hiragana}\\p{Script=Katakana}\\p{Script=Hangul}';

let inlinePatterns: any[] = [];
let blockPatterns: any[] = [];

function escapeRegex(string: string) {
	return string.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
}

function generateRegexRules(delimiters: any[]) {
	delimiters.forEach((delimiter: any) => {
		const { left, right, display } = delimiter;
		const escapedLeft = escapeRegex(left);
		const escapedRight = escapeRegex(right);

		if (!display) {
			inlinePatterns.push(`${escapedLeft}((?:\\\\[^]|[^\\\\])+?)${escapedRight}`);
		} else {
			inlinePatterns.push(`${escapedLeft}(?!\\n)((?:\\\\[^]|[^\\\\])+?)(?!\\n)${escapedRight}`);
			blockPatterns.push(`${escapedLeft}\\n((?:\\\\[^]|[^\\\\])+?)\\n${escapedRight}`);
		}
	});

	const inlineRule = new RegExp(
		`^(${inlinePatterns.join('|')})(?=[${ALLOWED_SURROUNDING_CHARS}]|$)`,
		'u'
	);
	const blockRule = new RegExp(
		`^(${blockPatterns.join('|')})(?=[${ALLOWED_SURROUNDING_CHARS}]|$)`,
		'u'
	);

	return { inlineRule, blockRule };
}

const { inlineRule, blockRule } = generateRegexRules(DELIMITER_LIST);

export default function (options: any = {}) {
	return {
		extensions: [inlineKatex(options), blockKatex(options)]
	};
}

function katexStart(src: any, displayMode: boolean): number | undefined {
	let ruleReg = displayMode ? blockRule : inlineRule;

	let indexSrc = src;

	while (indexSrc) {
		let index = -1;
		let startDelimiter = '';
		let endDelimiter = '';
		for (const delimiter of DELIMITER_LIST) {
			if (delimiter.display !== displayMode) {
				continue;
			}

			const startIndex = indexSrc.indexOf(delimiter.left);
			if (startIndex === -1) {
				continue;
			}

			index = startIndex;
			startDelimiter = delimiter.left;
			endDelimiter = delimiter.right;
			break; // Found first potential delimiter
		}

		if (index === -1) {
			return; // No delimiters found, exit loop
		}

		const f =
			index === 0 ||
			indexSrc.charAt(index - 1).match(new RegExp(`[${ALLOWED_SURROUNDING_CHARS}]`, 'u'));
		if (f) {
			const possibleKatex = indexSrc.substring(index);
			if (possibleKatex.match(ruleReg)) {
				return index;
			}
		}

		indexSrc = indexSrc.substring(index + startDelimiter.length).replace(endDelimiter, '');
	}
	return;
}

function katexTokenizer(src: any, tokens: any, displayMode: boolean) {
	const ruleReg = displayMode ? blockRule : inlineRule;
	const type = displayMode ? 'blockKatex' : 'inlineKatex';

	const match = src.match(ruleReg);

	if (match) {
		const rawText = match
			.slice(2)
			.filter((item: any) => item)
			.find((item: any) => item.trim());

		if (!rawText) return;

		const text = katex.renderToString(rawText, { displayMode });

		return {
			type,
			raw: match[0],
			text: text,
			displayMode,
			rawText
		};
	}
}

function inlineKatex(options: any) {
	return {
		name: 'inlineKatex',
		level: 'inline',
		start(src: any) {
			return katexStart(src, false);
		},
		tokenizer(src: any, tokens: any) {
			return katexTokenizer(src, tokens, false);
		},
		renderer(token: any) {
			return token.text;
		}
	};
}

function blockKatex(options: any) {
	return {
		name: 'blockKatex',
		level: 'block',
		start(src: any) {
			return katexStart(src, true);
		},
		tokenizer(src: any, tokens: any) {
			return katexTokenizer(src, tokens, true);
		},
		renderer(token: any) {
			return token.text;
		}
	};
} 
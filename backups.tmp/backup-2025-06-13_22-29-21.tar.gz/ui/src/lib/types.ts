export interface Model {
  id: string;
  name: string;
  info: {
    meta: {
      capabilities: {
        vision: boolean;
        file_upload: boolean;
        web_search: boolean;
        image_generation: boolean;
        code_interpreter: boolean;
      };
    };
  };
  filters: any[];
}

export interface Server {
  id: string;
  name: string;
  type: string;
  ip: string;
  port: number;
  apiKey?: string;
  active: boolean;
  endpoints: {
    chat: string;
    models: string;
    health: string;
  };
}

export interface Servers {
  [key: string]: Server;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  servers?: Servers;
}

export interface ServerConfig {
  type: string;
  name: string;
  ip: string;
  port: number;
  apiKey?: string;
  endpoints?: {
    chat?: string;
    models?: string;
    health?: string;
  };
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface ServerResponse {
  success: boolean;
  servers?: Record<string, Server>;
  error?: string;
}

export interface MessageResponse {
  success: boolean;
  message?: Message;
  error?: string;
} 
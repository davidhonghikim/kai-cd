export const SERVER_SOFTWARE = {
  OPENWEBUI: 'openwebui',
  OLLAMA: 'ollama',
  A1111: 'a1111',
  COMFYUI: 'comfyui',
  GENERIC_OPENAI: 'generic_openai',
  CUSTOM: 'custom'
} as const;

export const DEFAULT_PORTS = {
  [SERVER_SOFTWARE.OPENWEBUI]: 3000,
  [SERVER_SOFTWARE.OLLAMA]: 11434,
  [SERVER_SOFTWARE.A1111]: 7860,
  [SERVER_SOFTWARE.COMFYUI]: 8188,
  [SERVER_SOFTWARE.GENERIC_OPENAI]: 8080,
  [SERVER_SOFTWARE.CUSTOM]: 8080
} as const;

export const DEFAULT_ENDPOINTS = {
  [SERVER_SOFTWARE.OPENWEBUI]: {
    chat: '/api/chat',
    models: '/api/models',
    health: '/api/health'
  },
  [SERVER_SOFTWARE.OLLAMA]: {
    chat: '/api/chat',
    models: '/api/tags',
    health: '/api/health'
  },
  [SERVER_SOFTWARE.A1111]: {
    chat: '/sdapi/v1/txt2img',
    models: '/sdapi/v1/sd-models',
    health: '/sdapi/v1/sd-models'
  },
  [SERVER_SOFTWARE.COMFYUI]: {
    chat: '/api/prompt',
    models: '/api/history',
    health: '/api/history'
  },
  [SERVER_SOFTWARE.GENERIC_OPENAI]: {
    chat: '/v1/chat/completions',
    models: '/v1/models',
    health: '/v1/models'
  },
  [SERVER_SOFTWARE.CUSTOM]: {
    chat: '/api/chat',
    models: '/api/models',
    health: '/api/health'
  }
} as const;

export const DEFAULT_MODEL_ID = 'gpt-3.5-turbo'; 
import { APP_NAME } from '$lib/ui-constants';
import { type Writable, writable } from 'svelte/store';
import type {
	Banner,
	Settings,
	Config,
	SessionUser,
	Model,
	Prompt,
	Document,
	Dict,
	AppState,
	Server,
	Chat
} from '$lib/types';
import type { Socket } from 'socket.io-client';

import emojiShortCodes from '$lib/emoji-shortcodes.json';

// Backend
export const WEBUI_NAME = writable(APP_NAME);
export const config: Writable<Config | undefined> = writable(undefined);
export const user: Writable<SessionUser | undefined> = writable(undefined);

// Electron App
export const isApp = writable(false);
export const appInfo: Writable<any | null> = writable(null);
export const appData: Writable<any | null> = writable(null);

// Frontend
export const MODEL_DOWNLOAD_POOL: Writable<Dict<any>> = writable({});

export const mobile = writable(false);

export const socket: Writable<null | Socket> = writable(null);
export const activeUserIds: Writable<null | string[]> = writable(null);
export const USAGE_POOL: Writable<null | string[]> = writable(null);

export const theme = writable('system');

export const shortCodesToEmojis = writable(
	Object.entries(emojiShortCodes).reduce((acc: Dict<string>, [key, value]) => {
		if (typeof value === 'string') {
			acc[value] = key;
		} else if (Array.isArray(value)) {
			for (const v of value) {
				acc[v] = key;
			}
		}
		return acc;
	}, {})
);

export const TTSWorker: Writable<any | null> = writable(null);

export const chatId = writable('');
export const chatTitle = writable('');

export const channels: Writable<any[]> = writable([]);
export const chats: Writable<any[] | null> = writable(null);
export const pinnedChats: Writable<any[]> = writable([]);
export const tags: Writable<any[]> = writable([]);

export const models: Writable<Model[]> = writable([]);

export const prompts: Writable<null | Prompt[]> = writable(null);
export const knowledge: Writable<null | Document[]> = writable(null);
export const tools: Writable<any | null> = writable(null);
export const functions: Writable<any | null> = writable(null);

export const toolServers: Writable<any[]> = writable([]);

export const banners: Writable<Banner[]> = writable([]);

export const banner: Writable<Banner | null> = writable(null);

export const settings: Writable<Settings> = writable({
	chatDirection: 'ltr'
});

export const showSidebar = writable(false);
export const showSearch = writable(false);
export const showSettings = writable(false);
export const showArchivedChats = writable(false);
export const showChangelog = writable(false);

export const showControls = writable(false);
export const showOverview = writable(false);
export const showArtifacts = writable(false);
export const showCallOverlay = writable(false);

export const artifactCode: Writable<any | null> = writable(null);

export const temporaryChatEnabled = writable(false);
export const scrollPaginationEnabled = writable(false);
export const currentChatPage = writable(1);

export const isLastActiveTab = writable(true);
export const playingNotificationSound = writable(false);

export const apiKey: Writable<string> = writable('');

// Initialize default settings
const defaultSettings: Settings = {
	theme: 'system',
	fontSize: 16,
	maxTokens: 2048,
	temperature: 0.7,
	topP: 1,
	frequencyPenalty: 0,
	presencePenalty: 0,
	defaultModel: '',
	defaultServer: ''
};

// Create stores
export const servers = writable<{ [key: string]: Server }>({});
export const chats = writable<{ [key: string]: Chat }>({});
export const models = writable<{ [key: string]: Model }>({});
export const settings = writable<Settings>(defaultSettings);
export const currentChatId = writable<string | null>(null);
export const currentServerId = writable<string | null>(null);
export const currentModelId = writable<string | null>(null);

// Load state from storage
export async function loadState() {
	try {
		const response = await chrome.runtime.sendMessage({ action: 'get_state' });
		if (response.success) {
			const state: AppState = response.state;
			servers.set(state.servers);
			chats.set(state.chats);
			models.set(state.models);
			settings.set(state.settings);
			currentChatId.set(state.currentChatId);
			currentServerId.set(state.currentServerId);
			currentModelId.set(state.currentModelId);
		}
	} catch (error) {
		console.error('Failed to load state:', error);
	}
}

// Save state to storage
export async function saveState() {
	try {
		const state: AppState = {
			servers: await servers.get(),
			chats: await chats.get(),
			models: await models.get(),
			settings: await settings.get(),
			currentChatId: await currentChatId.get(),
			currentServerId: await currentServerId.get(),
			currentModelId: await currentModelId.get()
		};
		await chrome.runtime.sendMessage({ action: 'save_state', state });
	} catch (error) {
		console.error('Failed to save state:', error);
	}
}

// Subscribe to store changes to auto-save
servers.subscribe(() => saveState());
chats.subscribe(() => saveState());
models.subscribe(() => saveState());
settings.subscribe(() => saveState());
currentChatId.subscribe(() => saveState());
currentServerId.subscribe(() => saveState());
currentModelId.subscribe(() => saveState());

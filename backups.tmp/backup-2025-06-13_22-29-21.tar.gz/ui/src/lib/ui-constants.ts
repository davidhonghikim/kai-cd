// Constants for the ChatDemon UI

// Base URL for API calls - empty string means the proxy will handle the routing
export const WEBUI_BASE_URL = '';

// Define the supported AI backends
export const BACKEND_TYPES = {
  OPENWEBUI: 'openwebui',
  OLLAMA: 'ollama',
  A1111: 'a1111',
  COMFYUI: 'comfyui'
};

// Constants for the UI
export const UI_CONSTANTS = {
  APP_NAME: 'ChatDemon',
  VERSION: '1.0.0',
  GITHUB_URL: 'https://github.com/davidhonghikim/chatdemon'
};

// Default model settings
export const DEFAULT_MODEL_SETTINGS = {
  temperature: 0.7,
  top_p: 0.95,
  max_tokens: 2048
};

// Define the server status indicators
export const SERVER_STATUS = {
  ONLINE: 'online',
  OFFLINE: 'offline',
  UNKNOWN: 'unknown'
};

export const APP_NAME = 'Open WebUI';
export const WEBUI_API_BASE_URL = '/api/v1';
export const OLLAMA_API_BASE_URL = '/ollama/api';
export const OPENAI_API_BASE_URL = '/openai/api';
export const RETRIEVAL_API_BASE_URL = '/retrieval/api'; 
<script lang="ts">
  import { onMount } from 'svelte';
  import type { Server, Servers } from '$lib/types';
  
  let servers: Servers = {};
  let selectedServer: Server | null = null;
  let selectedModel: string = '';
  let availableModels: string[] = [];
  let messages: Array<{role: string, content: string}> = [];
  let newMessage: string = '';
  let isConnecting: boolean = false;
  let error: string | null = null;

  onMount(async () => {
    // Load servers from storage
    const response = await chrome.runtime.sendMessage({ action: 'get_servers' });
    if (response.success) {
      servers = response.servers;
      // Select first active server
      selectedServer = Object.values(servers).find(s => s.active) || null;
      if (selectedServer) {
        await loadModels(selectedServer);
      }
    }
  });

  async function loadModels(server: Server) {
    try {
      isConnecting = true;
      error = null;
      const response = await chrome.runtime.sendMessage({
        action: 'api_proxy',
        server,
        endpoint: '/api/models'
      });
      if (response.success) {
        availableModels = response.data;
        if (availableModels.length > 0) {
          selectedModel = availableModels[0];
        }
      } else {
        error = response.error;
      }
    } catch (e) {
      error = e.message;
    } finally {
      isConnecting = false;
    }
  }

  async function sendMessage() {
    if (!newMessage.trim() || !selectedServer || !selectedModel) return;
    
    const userMessage = { role: 'user', content: newMessage };
    messages = [...messages, userMessage];
    newMessage = '';
    
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'api_proxy',
        server: selectedServer,
        modelId: selectedModel,
        message: userMessage.content
      });
      
      if (response.success) {
        messages = [...messages, { role: 'assistant', content: response.data }];
      } else {
        error = response.error;
      }
    } catch (e) {
      error = e.message;
    }
  }

  async function handleServerChange(event: Event) {
    const serverId = (event.target as HTMLSelectElement).value;
    selectedServer = servers[serverId];
    if (selectedServer) {
      await loadModels(selectedServer);
    }
  }
</script>

<div class="panel-container">
  <div class="server-selector">
    <select bind:value={selectedServer} on:change={handleServerChange}>
      {#each Object.entries(servers) as [id, server]}
        <option value={id}>{server.name}</option>
      {/each}
    </select>
    
    {#if selectedServer}
      <select bind:value={selectedModel}>
        {#each availableModels as model}
          <option value={model}>{model}</option>
        {/each}
      </select>
    {/if}
  </div>

  {#if error}
    <div class="error">{error}</div>
  {/if}

  <div class="chat-container">
    {#each messages as message}
      <div class="message {message.role}">
        <div class="content">{message.content}</div>
      </div>
    {/each}
  </div>

  <div class="input-container">
    <input
      type="text"
      bind:value={newMessage}
      placeholder="Type your message..."
      on:keydown={(e) => e.key === 'Enter' && sendMessage()}
    />
    <button on:click={sendMessage} disabled={isConnecting}>
      {isConnecting ? 'Connecting...' : 'Send'}
    </button>
  </div>
</div>

<style>
  .panel-container {
    display: flex;
    flex-direction: column;
    height: 100vh;
    padding: 1rem;
  }

  .server-selector {
    display: flex;
    gap: 1rem;
    margin-bottom: 1rem;
  }

  .server-selector select {
    flex: 1;
    padding: 0.5rem;
  }

  .chat-container {
    flex: 1;
    overflow-y: auto;
    margin: 1rem 0;
    padding: 1rem;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .message {
    margin-bottom: 1rem;
    padding: 0.5rem;
    border-radius: 4px;
  }

  .message.user {
    background-color: #e3f2fd;
  }

  .message.assistant {
    background-color: #f5f5f5;
  }

  .input-container {
    display: flex;
    gap: 1rem;
  }

  .input-container input {
    flex: 1;
    padding: 0.5rem;
  }

  .error {
    color: red;
    margin: 1rem 0;
  }
</style> 
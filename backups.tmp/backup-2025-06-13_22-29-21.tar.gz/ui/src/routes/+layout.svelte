<script lang="ts">
  import { page } from '$app/stores';
  import ServerManager from '$lib/components/admin/Settings/ServerManager.svelte';
  
  let showSettings = false;
  let activeServer: any = null;
  
  async function loadActiveServer() {
    const response = await chrome.runtime.sendMessage({ action: 'get_servers' });
    if (response.success) {
      activeServer = Object.values(response.servers).find((s: any) => s.active);
    }
  }
  
  $: if ($page.url.hash !== '#/panel') {
    loadActiveServer();
  }
</script>

<div class="app-container">
  <nav class="sidebar">
    <div class="logo">
      <img src="/icons/icon48.png" alt="ChatDemon" />
      <h1>ChatDemon</h1>
    </div>
    
    <div class="nav-links">
      <a href="/" class:active={$page.url.pathname === '/'}>
        Chat
      </a>
      <a href="/settings" class:active={$page.url.pathname === '/settings'}>
        Settings
      </a>
    </div>
    
    {#if activeServer}
      <div class="active-server">
        <h3>Active Server</h3>
        <p>{activeServer.name}</p>
        <p class="server-type">{activeServer.type}</p>
      </div>
    {/if}
  </nav>
  
  <main class="content">
    <slot />
  </main>
</div>

<style>
  .app-container {
    display: flex;
    height: 100vh;
  }
  
  .sidebar {
    width: 250px;
    background-color: #1a1a1a;
    color: white;
    padding: 1rem;
    display: flex;
    flex-direction: column;
  }
  
  .logo {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 2rem;
  }
  
  .logo img {
    width: 32px;
    height: 32px;
  }
  
  .logo h1 {
    font-size: 1.2rem;
    margin: 0;
  }
  
  .nav-links {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .nav-links a {
    color: white;
    text-decoration: none;
    padding: 0.5rem;
    border-radius: 4px;
    transition: background-color 0.2s;
  }
  
  .nav-links a:hover {
    background-color: #333;
  }
  
  .nav-links a.active {
    background-color: #2196F3;
  }
  
  .active-server {
    margin-top: auto;
    padding: 1rem;
    background-color: #333;
    border-radius: 4px;
  }
  
  .active-server h3 {
    margin: 0 0 0.5rem;
    font-size: 0.9rem;
    color: #999;
  }
  
  .active-server p {
    margin: 0;
  }
  
  .server-type {
    font-size: 0.8rem;
    color: #999;
  }
  
  .content {
    flex: 1;
    padding: 1rem;
    background-color: #f5f5f5;
    overflow-y: auto;
  }
</style> 
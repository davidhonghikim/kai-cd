<script lang="ts">
  import ServerManager from '$lib/components/admin/Settings/ServerManager.svelte';
  import { onMount } from 'svelte';
  import type { Server } from '$lib/types';
  
  let servers: Record<string, Server> = {};
  let isLoading = true;
  
  onMount(async () => {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'get_servers' });
      if (response.success) {
        servers = response.servers;
      }
    } catch (error) {
      console.error('Error loading servers:', error);
    } finally {
      isLoading = false;
    }
  });
</script>

<div class="settings-container">
  <h1>Settings</h1>
  
  {#if isLoading}
    <div class="loading">Loading settings...</div>
  {:else}
    <div class="settings-section">
      <h2>Server Management</h2>
      <ServerManager />
    </div>
    
    <div class="settings-section">
      <h2>Active Servers</h2>
      {#if Object.keys(servers).length === 0}
        <p class="no-servers">No servers configured. Add a server to get started.</p>
      {:else}
        <div class="server-list">
          {#each Object.values(servers) as server}
            <div class="server-card {server.active ? 'active' : ''}">
              <h3>{server.name}</h3>
              <p class="server-type">{server.type}</p>
              <p class="server-url">{server.url}</p>
              {#if server.active}
                <span class="active-badge">Active</span>
              {/if}
            </div>
          {/each}
        </div>
      {/if}
    </div>
  {/if}
</div>

<style>
  .settings-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 2rem;
  }
  
  h1 {
    margin: 0 0 2rem;
    font-size: 2rem;
    color: #333;
  }
  
  .settings-section {
    background-color: white;
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  h2 {
    margin: 0 0 1rem;
    font-size: 1.5rem;
    color: #333;
  }
  
  .loading {
    text-align: center;
    padding: 2rem;
    color: #666;
  }
  
  .no-servers {
    color: #666;
    text-align: center;
    padding: 2rem;
  }
  
  .server-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 1rem;
  }
  
  .server-card {
    background-color: #f5f5f5;
    border-radius: 4px;
    padding: 1rem;
    position: relative;
  }
  
  .server-card.active {
    background-color: #e3f2fd;
    border: 1px solid #2196F3;
  }
  
  .server-card h3 {
    margin: 0 0 0.5rem;
    font-size: 1.1rem;
  }
  
  .server-type {
    color: #666;
    font-size: 0.9rem;
    margin: 0 0 0.5rem;
  }
  
  .server-url {
    color: #999;
    font-size: 0.8rem;
    margin: 0;
    word-break: break-all;
  }
  
  .active-badge {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background-color: #2196F3;
    color: white;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-size: 0.8rem;
  }
</style> 
<script lang="ts">
  import { page } from '$app/stores';
  import '../app.css';
  import Panel from './routes/panel/+page.svelte';
  import Main from './routes/+page.svelte';
  import { getContext, setContext } from 'svelte';

  // Mock i18n context
  setContext('i18n', {
    t: (key) => key
  });

</script>

<main>
  {#if $page.url.hash === '#/panel'}
    <Panel />
  {:else}
    <Main />
  {/if}
</main>

<style>
  main {
    width: 100%;
    height: 100vh;
    margin: 0;
    padding: 0;
  }
</style>

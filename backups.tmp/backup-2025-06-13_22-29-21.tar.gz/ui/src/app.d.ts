/// <reference types="@sveltejs/kit" />

declare namespace App {
  interface Locals {}
  interface PageData {}
  interface Error {}
  interface Platform {}
}

declare module '$lib/stores' {
  import { Writable } from 'svelte/store';
  export const i18n: Writable<any>;
  // Add other store exports here as needed
}

declare module '$lib/apis/prompts/index' {
  export function createNewPrompt(token: string, data: any): Promise<any>;
  export function deletePromptByCommand(token: string, command: string): Promise<any>;
  export function getPrompts(token: string): Promise<any[]>;
}

declare module '$lib/apis/tools' {
  export function getTools(token: string): Promise<any[]>;
}

declare module '$lib/apis/knowledge/index' {
  export function createNewKnowledge(token: string, data: any): Promise<any>;
  export function getKnowledgeBases(token: string): Promise<any[]>;
  export function updateKnowledgeById(token: string, id: string, data: any): Promise<any>;
}

declare module '$lib/apis/files/index' {
    export function getFileById(token: string, id: string): Promise<any>;
}

declare module '$lib/components/workspace/common/AccessControlModal.svelte' {}
declare module '$lib/components/workspace/common/AccessControl.svelte' {}
declare module '$lib/components/common/ConfirmDialog.svelte' {}

declare module 'vitest' {
    export function expect(value: any): any;
    export function test(name: string, fn: () => void): void;
}

declare module 'crc-32' {
    export default function(buffer: Buffer | string): number;
}

declare global {
	namespace App {
		// interface Error {}
		// interface Locals {}
		// interface PageData {}
		// interface Platform {}
	}
}

declare module '*.json' {
	const value: any;
	export default value;
}

export {}; 
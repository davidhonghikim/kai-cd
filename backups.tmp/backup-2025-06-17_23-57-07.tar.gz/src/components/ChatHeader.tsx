import React from 'react';
import type { Service } from '@/types';
import type { LLMModel } from '@/types';
import { sendMessage } from '@/utils/chrome';
import styles from '@/styles/components/ChatHeader.module.css';

interface ChatHeaderProps {
  service: Service;
  isTab: boolean;
  models: LLMModel[];
  selectedModel: string;
  onModelChange: (modelId: string) => void;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({
  service,
  isTab,
  models,
  selectedModel,
  onModelChange,
}) => {
  const handleSwitchView = async () => {
    if (isTab) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) {
        try {
          console.log('[SwitchToPanel] Setting active service:', service.id);
          await sendMessage('setActiveService', { serviceId: service.id });
          console.log('[SwitchToPanel] Enabling panel for tab:', tab.id);
          await chrome.sidePanel.setOptions({ tabId: tab.id, path: 'src/sidepanel/index.html', enabled: true });
          console.log('[SwitchToPanel] Opening panel for window:', tab.windowId);
          await chrome.sidePanel.open({ windowId: tab.windowId });
          console.log('[SwitchToPanel] Closing tab:', tab.id);
          await chrome.tabs.remove(tab.id);
        } catch (error) {
          console.error('[SwitchToPanel] Failed:', error);
        }
      }
    } else {
      try {
        const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (currentTab?.id) {
          await chrome.sidePanel.setOptions({ tabId: currentTab.id, enabled: false });
          chrome.runtime.sendMessage({ action: 'panelStateChanged', payload: { enabled: false } });
        }
        await sendMessage('openServiceInTab', { serviceId: service.id });
      } catch (error) {
        console.error('[SwitchToTab] Failed:', error);
      }
    }
  };

  return (
    <header className={styles.header}>
      <div className={styles.titleContainer}>
        <h1 className={styles.title}>{service.name}</h1>
        {models.length > 0 && (
          <select
            className={styles.modelSelector}
            value={selectedModel}
            onChange={(e) => onModelChange(e.target.value)}
          >
            {models.map((model) => (
              <option key={model.id} value={model.id}>
                {model.name}
              </option>
            ))}
          </select>
        )}
      </div>
      <button onClick={handleSwitchView} className={styles.switchButton}>
        {isTab ? 'Switch to Panel' : 'Switch to Tab'}
      </button>
    </header>
  );
};

export default ChatHeader; 
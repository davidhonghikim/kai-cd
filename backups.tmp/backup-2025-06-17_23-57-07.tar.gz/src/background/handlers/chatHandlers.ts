/* global console */
import { RequestHandler } from './types';
import { getStoredServices } from '../utils/storage';
import { serviceFactory } from '@/services/ServiceFactory';
import type { Service, ChatSession, LLMModel, ChatConnector, ChatMessage } from '@/types';

function isChatConnector(connector: any): connector is ChatConnector {
  return typeof connector?.sendMessage === 'function' && 
         typeof connector?.getModels === 'function' &&
         typeof connector?.clearHistory === 'function' &&
         typeof connector?.getHistory === 'function';
}

async function getService(serviceId: string): Promise<Service | undefined> {
  const services = await getStoredServices();
  return services.find(s => s.id === serviceId);
}

async function getConnector(service: Service): Promise<ChatConnector> {
  const connector = await serviceFactory.getConnector(service);
  if (!connector || !isChatConnector(connector)) {
    throw new Error(`No chat connector found for service ${service.id}`);
  }
  return connector;
}

/**
 * Send a chat message and handle the conversation history (session-based)
 */
export const sendMessage: RequestHandler<{ serviceId: string; messages: ChatMessage[]; model: string }, { success: boolean; data?: ChatMessage[]; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId, messages, model } = payload;
    console.log('[ChatHandler] sendMessage called with:', { serviceId, model, messageCount: messages.length });
    
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }

    const connector = await getConnector(service);
    
    // Get the last user message from the messages array
    const lastUserMessage = messages.slice().reverse().find((msg: ChatMessage) => msg.role === 'user');
    if (!lastUserMessage) {
      throw new Error('No user message found in messages array');
    }
    
    console.log('[ChatHandler] Calling connector.sendMessage with:', { 
      message: lastUserMessage.content.substring(0, 100) + '...', 
      model, 
      serviceType: service.type 
    });
    
    // Use sendMessage with the last user message and model in options
    const response = await connector.sendMessage(lastUserMessage.content, { model });
    
    console.log('[ChatHandler] Connector response type:', typeof response);
    console.log('[ChatHandler] Connector response:', response);
    console.log('[ChatHandler] Response content type:', typeof response.content);
    console.log('[ChatHandler] Response content (first 200 chars):', response.content?.substring(0, 200));
    
    // Return the full conversation history as expected by ChatInterface
    const fullHistory = [...messages, response];
    const responseData = { success: true, data: fullHistory };
    console.log('[ChatHandler] Final response data:', responseData);
    
    sendResponse(responseData);
  } catch (error) {
    console.error('[ChatHandler] Error sending message:', error);
    console.error('[ChatHandler] Error stack:', error instanceof Error ? error.stack : 'No stack');
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
};

/**
 * Clear chat history for a service (all sessions)
 */
export const clearChatHistory: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }, _sender, sendResponse) => {
  try {
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }

    const connector = await getConnector(service);
    await connector.clearHistory();
    sendResponse();
  } catch (error) {
    console.error('Error clearing chat history:', error);
    sendResponse();
  }
};

/**
 * Get available models for a service
 */
export const getModels: RequestHandler<{ serviceId: string }, { success: boolean; models?: LLMModel[]; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    const connector = await getConnector(service);
    const models = await connector.getModels();
    sendResponse({ success: true, models });
  } catch (error) {
    console.error('Error getting models:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
};

/**
 * Get chat sessions for a service
 */
export const getChatHistory: RequestHandler<{ serviceId: string }, { success: boolean; history?: ChatSession[]; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    const connector = await getConnector(service);
    const history = await connector.getHistory();
    sendResponse({ success: true, history });
  } catch (error) {
    console.error('Error getting chat history:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
};

export const chatHandlers = {
  sendMessage,
  clearChatHistory,
  getModels,
  getChatHistory
};

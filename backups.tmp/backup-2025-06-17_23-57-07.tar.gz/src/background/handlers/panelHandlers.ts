/* global console */
import { storageManager } from '../../storage/storageManager';
import { RequestHandler } from './types';
import { Service } from '../../types';
import { SERVERS_KEY } from '../../utils/settingsIO';

interface SetActiveServicePayload {
  serviceId: string;
}

interface HidePanelPayload {
  tabId: number;
}

interface OpenServiceInTabPayload {
  serviceId: string;
}

/**
 * Sets the active service in storage. This determines which service the panel will display.
 * After setting, it broadcasts a message to notify other parts of the extension.
 */
export const setActiveService: RequestHandler<SetActiveServicePayload, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    const services = await storageManager.get<Service[]>(SERVERS_KEY, []);
    const serviceToActivate = services.find(s => s.id === serviceId);
    await storageManager.set('activeService', serviceToActivate || null);
    chrome.runtime.sendMessage({ action: 'activeServiceChanged', payload: serviceToActivate });
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
  return true;
};

/**
 * Gets the currently active service from storage.
 */
export const getActiveService: RequestHandler<undefined, { success: boolean; service?: Service | null; error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    const service = await storageManager.get<Service | null>('activeService', null);
    sendResponse({ success: true, service });
  } catch (error) {
    sendResponse({ success: false, error: 'Failed to get active service' });
  }
  return true;
};

/**
 * Hides the side panel for a specific tab.
 */
export const hidePanel: RequestHandler<HidePanelPayload, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { tabId } = payload;
    if (tabId) {
      await chrome.sidePanel.setOptions({ tabId, enabled: false });
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: 'hidePanel called without a tabId.' });
    }
  } catch (error) {
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
  return true;
};

/**
 * Opens the extension's options page.
 */
export const openOptionsPage: RequestHandler<undefined, { success: boolean; error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    await chrome.runtime.openOptionsPage();
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
  return true;
};

/**
 * Opens a service's URL in a new tab, loading the extension's tab UI.
 */
export const openServiceInTab: RequestHandler<OpenServiceInTabPayload, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    const services = await storageManager.get<Service[]>(SERVERS_KEY, []);
    const service = services.find((s) => s.id === serviceId);
    if (service) {
      const url = chrome.runtime.getURL(`src/tab/index.html?serviceId=${serviceId}`);
      await chrome.tabs.create({ url });
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: `Service with id ${serviceId} or its URL not found.` });
    }
  } catch (error) {
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
  return true;
};

/**
 * Handles panel state change notifications.
 */
export const panelStateChanged: RequestHandler<{ enabled?: boolean }, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const enabled = payload?.enabled ?? false;
    chrome.runtime.sendMessage({
      action: 'panelStateChanged',
      payload: { enabled }
    });
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
  return true;
};

/**
 * Returns the current panel state (open/closed). For now, always returns false (closed) as a placeholder.
 */
export const getPanelState: RequestHandler<undefined, { success: boolean; isOpen: boolean }> = async (_payload, _sender, sendResponse) => {
  sendResponse({ success: true, isOpen: false });
  return true;
};

/**
 * Opens the service in a new tab.
 */
export const openInTab: RequestHandler<{ serviceId: string }, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const url = chrome.runtime.getURL(`src/tab/index.html?serviceId=${payload.serviceId}`);
    chrome.tabs.create({ url });
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
  return true;
};

export const panelHandlers = {
  setActiveService,
  getActiveService,
  hidePanel,
  openServiceInTab,
  panelStateChanged,
  getPanelState,
  openOptionsPage,
  openInTab,
};

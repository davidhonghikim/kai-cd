// Core imports
import { 
  SERVICE_TYPES, 
  SERVICE_CATEGORIES,
  type ServiceType,
  type ServiceCategory,
  type Service,
  type LLMModel,
  type ChatMessage
} from "@/config/types";
import { getServiceMetadata } from "@/config/services";

// Connector imports
import { BaseConnector } from "@/services/base/BaseConnector";
import { LLMConnector } from './llm/LLMConnector';
import { N8NConnector } from './automation/n8nConnector';
import { TailscaleConnector } from './network/tailscaleConnector';
import { OpenAICompatibleConnector } from './llm/openAICompatibleConnector';

// LLM Connector implementations
import { OllamaConnector } from './llm/ollamaConnector';

// Types
type Connector = BaseConnector<any>;

// Stub implementations for missing connectors
class ImageGenConnector extends BaseConnector<Service> {
  constructor(service: Service) {
    super(service);
  }
  
  async connect(): Promise<boolean> {
    this._isConnected = true;
    return true;
  }
  
  async disconnect(): Promise<void> {
    this._isConnected = false;
  }
  
  async checkStatus() {
    return { isOnline: this._isConnected };
  }
}

class UIServiceConnector extends BaseConnector<Service> {
  constructor(service: Service) {
    super(service);
  }
  
  async connect(): Promise<boolean> {
    return true;
  }
  
  async disconnect(): Promise<void> {
    // No-op
  }
  
  async checkStatus() {
    return { isOnline: true };
  }
}

/**
 * Service Factory creates and manages service connectors based on service type
 */
export class ServiceFactory {
  private static instance: ServiceFactory;
  private connectors: Map<string, Connector>;

  private constructor() {
    this.connectors = new Map();
  }

  /**
   * Get the singleton instance of ServiceFactory
   */
  public static getInstance(): ServiceFactory {
    if (!ServiceFactory.instance) {
      ServiceFactory.instance = new ServiceFactory();
    }
    return ServiceFactory.instance;
  }

  /**
   * Get a service connector by service ID
   */
  public async getConnector(service: Service): Promise<BaseConnector | null> {
    if (!service || !service.id) {
      console.error('Invalid service object');
      return null;
    }

    // Return existing connector if available
    if (this.connectors.has(service.id)) {
      return this.connectors.get(service.id) || null;
    }

    const connector = await this.createConnector(service);
    if (connector) {
      this.connectors.set(service.id, connector);
    }
    return connector;
  }

  private async createConnector(service: Service): Promise<Connector> {
    let connector: Connector;
    const serviceType = service.type as ServiceType;
    
    // Handle special service types
    if (serviceType === SERVICE_TYPES.UI_SERVICE) {
      return this.createUIConnector(service);
    }
    
    if (serviceType === SERVICE_TYPES.IMAGE_GEN) {
      return this.createImageConnector(service);
    }
    
    // For all other service types, get the metadata
    const serviceMetadata = getServiceMetadata(serviceType);
    
    if (!serviceMetadata) {
      throw new Error(`No metadata found for service type: ${serviceType}`);
    }

    try {
      // Handle different service types
      if (serviceType === SERVICE_TYPES.OLLAMA) {
        connector = new OllamaConnector(service);
      } else if (serviceType === SERVICE_TYPES.N8N) {
        connector = new N8NConnector(service);
      } else if (serviceType === SERVICE_TYPES.TAILSCALE) {
        connector = new TailscaleConnector(service);
      } else if (serviceType === SERVICE_TYPES.LLAMA_CPP || 
                 serviceType === SERVICE_TYPES.VLLM ||
                 serviceType === SERVICE_TYPES.LLM_STUDIO ||
                 serviceType === SERVICE_TYPES.OPENAI_COMPATIBLE) {
        connector = new OpenAICompatibleConnector(service);
      } else {
        // For any other service type, get the default connector
        return this.getDefaultConnector(serviceType);
      }

      // Try to connect if the service is marked as active
      if (service.isActive) {
        await connector.connect();
      }

      return connector;
    } catch (error) {
      console.error(`Failed to create connector for service ${service.id}:`, error);
      throw error;
    }
  }

  /**
   * Create an LLM connector based on service type
   */
  private createLLMConnector(service: Service): LLMConnector {
    const { type } = service;
    
    // Import connectors dynamically to avoid circular dependencies
    switch (type) {
      case SERVICE_TYPES.OLLAMA:
        const { OllamaConnector } = require('./llm/ollamaConnector');
        return new OllamaConnector(service);
      case SERVICE_TYPES.LLAMA_CPP:
      case SERVICE_TYPES.VLLM:
      case SERVICE_TYPES.LLM_STUDIO:
      case SERVICE_TYPES.OPENAI_COMPATIBLE:
        return new OpenAICompatibleConnector(service);
      default:
        throw new Error(`Unsupported LLM service type: ${type}`);
    }
  }

  /**
   * Create an image generation connector based on service type
   */
  private createImageConnector(service: Service): ImageGenConnector {
    return new ImageGenConnector(service);
  }

  /**
   * Create a UI service connector
   */
  private createUIConnector(service: Service): UIServiceConnector {
    console.warn(`UI connector for ${service.type} is not implemented`);
    return new UIServiceConnector(service);
  }

  /**
   * Remove a connector from the cache
   */
  public removeConnector(serviceId: string): void {
    if (this.connectors.has(serviceId)) {
      const connector = this.connectors.get(serviceId);
      if (connector && 'disconnect' in connector) {
        connector.disconnect().catch(console.error);
      }
      this.connectors.delete(serviceId);
    }
  }

  /**
   * Clear all connectors
   */
  public clearConnectors(): void {
    this.connectors.forEach((connector, serviceId) => {
      if (connector && 'disconnect' in connector) {
        connector.disconnect().catch(console.error);
      }
    });
    this.connectors.clear();
  }

  /**
   * Get all active connectors
   */
  public getActiveConnectors(): Array<{
    serviceId: string;
    connector: BaseConnector<any>;
  }> {
    return Array.from(this.connectors.entries()).map(([serviceId, connector]) => ({
      serviceId,
      connector
    }));
  }

  /**
   * Check if a service type is supported
   */
  public isServiceTypeSupported(type: string): type is ServiceType {
    return Object.values(SERVICE_TYPES).includes(type as ServiceType);
  }

  /**
   * Get the category of a service type
   */
  public getServiceCategory(type: ServiceType): ServiceCategory {
    const metadata = getServiceMetadata(type);
    return metadata.category;
  }

  /**
   * Get a default connector for a given service type
   */
  private getDefaultConnector(type: ServiceType | string): Connector {
        const category = this.isServiceTypeSupported(type)
      ? getServiceMetadata(type).category
      : SERVICE_CATEGORIES.UI;

    // Create a minimal service object for the connector
    const service: Service = {
      id: `default-${type}`,
      name: `Default ${type}`,
      type: type as ServiceType, // Cast to ServiceType since we handle special cases
      url: '',
      isActive: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      category,
    };

    // Handle UI service specially
    if (type === 'ui-service') {
      return new UIServiceConnector(service);
    }
    
    // For all other service types, use the appropriate connector
    const serviceType = type as ServiceType;
    switch (serviceType) {
      case SERVICE_TYPES.OLLAMA:
        return new OllamaConnector(service);
      case SERVICE_TYPES.LLAMA_CPP:
      case SERVICE_TYPES.VLLM:
      case SERVICE_TYPES.LLM_STUDIO:
      case SERVICE_TYPES.OPENAI_COMPATIBLE:
        return new OpenAICompatibleConnector(service);
      case SERVICE_TYPES.N8N:
        return new N8NConnector(service);
      case SERVICE_TYPES.TAILSCALE:
        return new TailscaleConnector(service);
      default:
        // For any other service type, return a UIServiceConnector as a fallback
        return new UIServiceConnector(service);
    }
  }
}

// Export a singleton instance
export const serviceFactory = ServiceFactory.getInstance();

// Re-export connector interfaces and types
export * from './llm/LLMConnector';

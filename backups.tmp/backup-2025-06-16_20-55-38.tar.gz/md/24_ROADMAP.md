# ChatDemon vs. Open-WebUI: Feature Comparison & Implementation Plan

This document outlines a strategic plan to evolve ChatDemon by adopting the successful UI/UX patterns and features of the Open-WebUI project. The goal is to enhance ChatDemon's usability and functionality without introducing new external dependencies, leveraging our existing React-based architecture.

---

## 1. High-Level Comparison

| Aspect                | ChatDemon (Current)                                       | Open-WebUI (Reference)                                                              | Opportunity for ChatDemon                                                                                                                              |
| --------------------- | --------------------------------------------------------- | ----------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Core UI/UX**        | Functional, sidebar-based navigation. Basic chat interface. | Polished, modern, and highly interactive. Features a dedicated chat view with advanced controls, modals for settings, and a command bar (`cmd+k`). | Redesign the main chat view to be more immersive. Implement a global command palette for quick actions. Improve modals and settings panels for better UX. |
| **Architecture**      | React-based browser extension. Uses `chrome.storage` for state. | SvelteKit web application. Uses stores for state management and a route-based structure. | Refactor state management to be more robust. While we can't switch from React, we can adopt better component structure and state flow patterns.         |
| **Feature: Chat**     | Basic message exchange.                                   | Advanced chat with document uploads (RAG), web browsing, prompt templates, multi-modal support, and detailed conversation history. | Implement key features sequentially: 1. Prompt templates. 2. Improved conversation history. 3. Local file handling for basic RAG.                    |
| **Feature: Models**   | Simple model list.                                        | Detailed model management, including downloading, editing, and creating models (`Modelfile`). | Enhance the model management panel to allow for more detailed views and potential interactions (like pulling a new model).                           |
| **Feature: Settings** | A single options page.                                    | Granular control via modals and a dedicated admin-level settings area.              | Reorganize settings into logical groups. Use modals for context-specific settings to avoid navigating away from the main view.                     |

---

## 2. Phased Implementation Plan

This plan breaks down the refactoring effort into manageable phases.

### Phase 1: UI/UX Foundation Refactor

*Goal: Modernize the look and feel of the main application view.*

1.  **Redesign Chat View (`src/sidepanel/ChatView.tsx`):**
    *   Create a more spacious, centered chat interface similar to Open-WebUI's.
    *   Improve the message component UI (`ChatMessage.tsx`) with better formatting for user vs. AI messages, and include actions like copy, edit, and retry.
    *   Redesign the chat input area to be more prominent and to support multi-line input more gracefully.
2.  **Implement a Command Palette:**
    *   Create a new reusable component (`src/components/CommandPalette.tsx`).
    *   Hook it up to a global keyboard shortcut (e.g., `Cmd+K`).
    *   Initial commands: "Switch Service," "New Chat," "View Settings."
3.  **Refactor Settings Modals:**
    *   Instead of navigating to a full `options.html` page, move the most common service settings into a modal component (`src/components/ServiceSettingsModal.tsx`).
    *   This keeps the user in the main chat context.

### Phase 2: Core Feature Enhancement

*Goal: Bring key Open-WebUI features to ChatDemon.*

1.  **Prompt Templates:**
    *   Create a new storage key for `prompt_templates`.
    *   Build a UI (`src/components/PromptTemplateManager.tsx`) to let users create, save, and use predefined prompts.
    *   Integrate a dropdown or a `/` command in the chat input to access templates.
2.  **Improved Conversation History:**
    *   Enhance the `storageManager` to save entire conversations, not just individual messages.
    *   Redesign the conversation history UI in the sidebar to be more intuitive, with options to name, search, and delete chats.
3.  **Local RAG (Retrieval-Augmented Generation):**
    *   **No new dependencies constraint:** We cannot use complex libraries like LangChain or LlamaIndex.
    *   **Plan:**
        *   Add a file upload button to the chat input.
        *   When a user uploads a `.txt` or `.md` file, read its content in the frontend.
        *   Prepend the file's content to the user's *next* prompt as context.
        *   This is a simplified, "manual" RAG that respects the project constraints.

### Phase 3: Advanced Functionality

*Goal: Add power-user features.*

1.  **Enhanced Model Management:**
    *   Create a dedicated "Model Management" view.
    *   Implement functionality to pull new models from Ollama by calling the `/api/pull` endpoint.
    *   Display detailed model information (parameters, quantization) by calling `/api/show`.
2.  **Multi-Modal Support (Images):**
    *   Update the chat input to accept image pastes or uploads.
    *   Convert the image to a base64 string on the client-side.
    *   Update the `chat` method in the `ollamaConnector.ts` to send the image data in the format Ollama expects (`"images": [base64_string]`). This is already supported by the API.

---

## 3. Documentation Update

*   **Bugs:** The primary bug regarding IP address handling and CORS is now considered **resolved**. The root cause was an incorrect `Authorization` header being sent, which was fixed by overriding the `fetch` method in the `OllamaConnector`.
*   **Roadmap:** This document will serve as the new strategic roadmap.
*   **TODO:** The action items from the implementation plan will be added to the project's `TODO.md`.

## [x] Granular Endpoint Editing & IP History ✅
- Service edit form now has separate fields for IP, port, and endpoint path.
- IP field uses a dropdown with history/autocomplete.
- Changes are saved and reflected in the service list.
- IP history is stored and suggested.

## [x] Advanced Settings Save/Reset/Cancel ✅
- Save button persists changes.
- Reset button restores defaults.
- Cancel button discards unsaved changes.
- All section components now use parent state for editing.

// ... add next steps if any remain ... 
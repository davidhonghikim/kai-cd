import { BaseConnector } from "@/services/base/BaseConnector";
import { LLMModel, ChatMessage, Service } from "@/config/types";
import { ILLMConnector, StreamChunk, StreamCallback, GenerationParams } from '@/config/types';
 // Extend the Service type to include LLM-specific properties
declare module '../../config/types' {
  interface Service {
    models?: LLMModel[];
    defaultModel?: string;
  }
}
 // Base class for LLM service connectors
export abstract class LLMConnector extends BaseConnector<Service> implements ILLMConnector {
  protected models: LLMModel[] = [];
  protected abortController: AbortController | null = null;
   constructor(service: Service) {
    super(service);
  }
   // Abstract methods that must be implemented by subclasses
  abstract connect(): Promise<boolean>;
  abstract disconnect(): Promise<void>;
  abstract getModels(): Promise<LLMModel[]>;
  abstract chat(
    messages: ChatMessage[],
    model: string,
    options?: GenerationParams
  ): Promise<ChatMessage>;
  abstract embed(texts: string[], model: string): Promise<number[][]>;
  abstract tokenize(text: string, model: string): Promise<number[]>;
  abstract detokenize(tokens: number[], model: string): Promise<string>;
  abstract getContextSize(model: string): Promise<number>;
   // Default implementations
  async getModel(modelId: string): Promise<LLMModel | null> {
    const models = await this.getModels();
    return models.find(m => m.id === modelId) || null;
  }
   async installModel(modelId: string, options: any = {}): Promise<void> {
    throw new Error('Model installation not supported by this service');
  }
   async deleteModel(modelId: string): Promise<void> {
    throw new Error('Model deletion not supported by this service');
  }
   async countTokens(
    input: string | ChatMessage | ChatMessage[],
    model: string
  ): Promise<number> {
    if (typeof input === 'string') {
      return (await this.tokenize(input, model)).length;
    } else if (Array.isArray(input)) {
      const tokens = await Promise.all(
        input.map(msg => this.tokenize(msg.content, model))
      );
      return tokens.flat().length;
    } else {
      return (await this.tokenize(input.content, model)).length;
    }
  }
   async isModelSupported(model: string): Promise<boolean> {
    try {
      const models = await this.getModels();
      return models.some(m => m.id === model);
    } catch (error) {
      console.error('Error checking model support:', error);
      return false;
    }
  }
   async getDefaultParams(model: string): Promise<Record<string, any>> {
    return {
      temperature: 0.7,
      maxTokens: 2000,
      topP: 1.0,
      frequencyPenalty: 0,
      presencePenalty: 0,
      stop: [],
    };
  }
   // Implement ILLMConnector methods
  getService(): Service {
    return this.service;
  }
   async getStatus() {
    try {
      const status = await this.checkStatus();
      if (status.error) {
        return {
          isOnline: false,
          status: 'error' as const,
          message: status.error,
          details: status.details
        };
      }
      return {
        isOnline: status.isOnline,
        status: (status.isOnline ? 'online' : 'offline') as 'online' | 'offline',
        message: status.isOnline ? 'Service is online' : 'Service is offline',
        details: status.details
      };
    } catch (error) {
      return {
        isOnline: false,
        status: 'error' as const,
        message: error instanceof Error ? error.message : 'Unknown error',
        details: undefined
      };
    }
  }
     // Override BaseConnector methods
  getDisplayName(): string {
    return this.service.name || 'LLM Connector';
  }
     getType(): string {
    return this.service.type || 'llm';
  }
     getCategory(): string {
    return 'llm';
  }
      async checkStatus() {
    try {
      await this.getModels();
      return {
        isOnline: true,
        details: this.service,
      };
    } catch (error) {
      return {
        isOnline: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
   // Helper methods
  protected createAbortController() {
    this.abortController = new AbortController();
    return this.abortController;
  }
   protected getAbortSignal() {
    return this.abortController?.signal;
  }
   protected abortRequest() {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }
   // Helper method for streaming responses
  public async *streamResponse(
    response: Response,
    onChunk?: (chunk: StreamChunk) => void
  ): AsyncGenerator<StreamChunk> {
    if (!response.body) {
      throw new Error('Response body is null');
    }
         const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
         try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
                 buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
                 for (const line of lines) {
          if (!line.trim()) continue;
                     try {
            const chunk = this.parseStreamChunk(line);
            if (chunk) {
              if (onChunk) onChunk(chunk);
              yield chunk;
            }
          } catch (error) {
            console.error('Error parsing stream chunk:', error);
            yield {
              isComplete: true,
              error: error instanceof Error ? error.message : 'Error parsing stream',
            };
            return;
          }
        }
      }
             // Process any remaining data in the buffer
      if (buffer.trim()) {
        try {
          const chunk = this.parseStreamChunk(buffer);
          if (chunk) {
            if (onChunk) onChunk(chunk);
            yield chunk;
          }
        } catch (error) {
          console.error('Error parsing final stream chunk:', error);
          yield {
            isComplete: true,
            error: error instanceof Error ? error.message : 'Error parsing final chunk',
          };
        }
      }
             // Signal completion
      const completionChunk: StreamChunk = { isComplete: true };
      if (onChunk) onChunk(completionChunk);
      yield completionChunk;
           } finally {
      reader.releaseLock();
    }
  }
     protected parseStreamChunk(chunk: string): StreamChunk | null {
    try {
      // Remove 'data: ' prefix if present
      const data = chunk.startsWith('data: ') ? chunk.slice(6) : chunk;
             // Handle error
      if (data === '[DONE]') {
        return { isComplete: true };
      }
             const parsed = JSON.parse(data);
             // Handle error
      if (parsed.error) {
        return {
          isComplete: true,
          error: parsed.error.message || 'Unknown error',
        };
      }
             // Extract content and metadata
      const content = parsed.choices?.[0]?.delta?.content || '';
      const isComplete = parsed.choices?.[0]?.finish_reason === 'stop';
             return {
        content,
        isComplete,
        metadata: {
          ...parsed,
          choices: parsed.choices?.map((choice: any) => ({
            ...choice,
            delta: {
              ...choice.delta,
              content,
            },
          })),
        },
      };
    } catch (error) {
      console.error('Error parsing stream chunk:', error);
      return {
        isComplete: true,
        error: error instanceof Error ? error.message : 'Invalid stream chunk',
      };
    }
  }
  // Default implementation of complete method
  async complete(
    prompt: string,
    model: string,
    options: GenerationParams = {}
  ): Promise<string> {
    const messages: ChatMessage[] = [
      {
        id: `msg_${Date.now()}`,
        role: 'user',
        content: prompt,
        timestamp: Date.now(),
      },
    ];
    
    const response = await this.chat(messages, model, {
      ...options,
      stream: false,
    });
    
    return response.content;
  }
}

export default LLMConnector;

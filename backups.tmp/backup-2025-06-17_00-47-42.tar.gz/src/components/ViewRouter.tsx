import React from 'react';
import { Service, SERVICE_TYPES, SERVICE_TYPE_TO_CATEGORY, SERVICE_CATEGORIES } from '@/config/types';
import ChatInterface from './ChatInterface';
import IframeView from './IframeView';
import A1111View from '@/views/A1111View';
import ComfyUIView from '@/views/ComfyUIView';

interface ViewRouterProps {
  service: Service;
  isTab?: boolean;
}

const ViewRouter: React.FC<ViewRouterProps> = ({ service, isTab = false }) => {
  if (!service) {
    console.error('ViewRouter: No service loaded', service);
    return <div style={{ padding: 32, color: 'red' }}>Error: No service loaded. Please select a service.</div>;
  }
  if (!service.type) {
    console.error('ViewRouter: Service type missing', service);
    return <div style={{ padding: 32, color: 'red' }}>Error: Service type missing. Please check your configuration.</div>;
  }
  if (!service.url) {
    console.error('ViewRouter: Service URL missing', service);
    return <div style={{ padding: 32, color: 'red' }}>Error: Service URL missing. Please check your configuration.</div>;
  }
  const category = SERVICE_TYPE_TO_CATEGORY[service.type];

  // UI-based services should always show their iframe
  if (category === SERVICE_CATEGORIES.UI || category === SERVICE_CATEGORIES.AUTOMATION) {
    return <IframeView url={service.url} serviceName={service.name} service={service} isTab={isTab} />;
  }

  // Image services have different views for tab vs panel
  if (category === SERVICE_CATEGORIES.IMAGE) {
    if (isTab) {
      // Always show the service's full UI as an iframe in a tab
      return <IframeView url={service.url} serviceName={service.name} service={service} isTab={isTab} />;
    }
    // For panels, show a dedicated quick-use UI for A1111 and ComfyUI
    switch (service.type) {
      case SERVICE_TYPES.A1111:
        return <A1111View service={service} isTab={isTab} />;
      case SERVICE_TYPES.COMFY_UI:
        return <ComfyUIView service={service} isTab={isTab} />;
      default:
        return <IframeView url={service.url} serviceName={service.name} service={service} isTab={isTab} />;
    }
  }

  // For OpenWebUI, always use IframeView in a tab
  if (service.type === SERVICE_TYPES.OPEN_WEBUI && isTab) {
    return <IframeView url={service.url} serviceName={service.name} service={service} isTab={isTab} />;
  }

  // LLM services use the ChatInterface
  if (category === SERVICE_CATEGORIES.LLM) {
    return <ChatInterface service={service} isPanel={!isTab} />;
  }

  // Default to iframe view for any other service type
  return <IframeView url={service.url} serviceName={service.name} service={service} isTab={isTab} />;
};

export default ViewRouter;

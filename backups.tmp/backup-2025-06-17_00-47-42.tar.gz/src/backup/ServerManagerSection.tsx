import React, { useState, useEffect } from 'react';
import { Service, ServiceStatus } from '../../../types';
import { storageManager } from '../../../storage/storageManager';
import { sendMessage } from '../../../utils/messaging';
import styles from './ServerManagerSection.module.css';
import ServerFormModal from './ServerFormModal';

interface ServerManagerSectionProps {
  onUpdate: (settings: Record<string, any>) => void;
}

const ServerManagerSection: React.FC<ServerManagerSectionProps> = ({ onUpdate }) => {
  const [servers, setServers] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedServer, setSelectedServer] = useState<Service | null>(null);
  const [isAddingServer, setIsAddingServer] = useState(false);
  const [checkingStatus, setCheckingStatus] = useState<Record<string, boolean>>({});

  useEffect(() => {
    loadServers();
  }, []);

  const loadServers = async () => {
    try {
      setLoading(true);
      const loadedServers = await storageManager.get<Service[]>('servers', []);
      setServers(loadedServers);
      setError(null);
    } catch (err) {
      setError('Failed to load servers. Please try again.');
      console.error('Error loading servers:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddServer = () => {
    setSelectedServer(null);
    setIsAddingServer(true);
  };

  const handleEditServer = (server: Service) => {
    setSelectedServer(server);
    setIsAddingServer(true);
  };

  const handleDeleteServer = async (serverId: string) => {
    if (!window.confirm('Are you sure you want to delete this server?')) {
      return;
    }

    try {
      const updatedServers = servers.filter(s => s.id !== serverId);
      await storageManager.set('servers', updatedServers);
      setServers(updatedServers);
      onUpdate({ servers: updatedServers });
    } catch (err) {
      setError('Failed to delete server. Please try again.');
      console.error('Error deleting server:', err);
    }
  };

  const handleCheckStatus = async (server: Service) => {
    try {
      setCheckingStatus(prev => ({ ...prev, [server.id]: true }));
      const response = await sendMessage('checkServerStatus', { server });
      
      if (response.success) {
        const updatedServers = servers.map(s => 
          s.id === server.id ? { ...s, status: response.status as ServiceStatus } : s
        );
        setServers(updatedServers);
        await storageManager.set('servers', updatedServers);
        onUpdate({ servers: updatedServers });
      } else {
        throw new Error(response.error || 'Failed to check server status');
      }
    } catch (err) {
      console.error('Error checking server status:', err);
      setError(`Failed to check status for ${server.name}. Please try again.`);
    } finally {
      setCheckingStatus(prev => ({ ...prev, [server.id]: false }));
    }
  };

  const handleSubmit = async (serverData: Service) => {
    try {
      let updatedServers: Service[];
      if (selectedServer) {
        updatedServers = servers.map(s => 
          s.id === selectedServer.id ? { ...serverData, id: s.id } : s
        );
      } else {
        updatedServers = [...servers, { ...serverData, id: Date.now().toString() }];
      }
      await storageManager.set('servers', updatedServers);
      setServers(updatedServers);
      setIsAddingServer(false);
      setSelectedServer(null);
      onUpdate({ servers: updatedServers });
    } catch (err) {
      setError('Failed to save server. Please try again.');
      console.error('Error saving server:', err);
    }
  };

  if (loading) {
    return (
      <div className={styles.loadingContainer}>
        <div className={styles.spinner}></div>
        <p className={styles.loadingText}>Loading servers...</p>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.headerContent}>
          <h3>Server Manager</h3>
          <p className={styles.description}>
            Manage your server connections and endpoints
          </p>
        </div>
        <button 
          className={styles.addButton}
          onClick={handleAddServer}
        >
          Add Server
        </button>
      </div>

      {error && (
        <div className={styles.error}>
          <p>{error}</p>
          <button onClick={loadServers}>Retry</button>
        </div>
      )}

      {servers.length === 0 ? (
        <div className={styles.emptyState}>
          <div className={styles.emptyStateIcon}>📡</div>
          <p>No servers configured</p>
          <p className={styles.emptyStateDescription}>
            Click "Add Server" to configure your first server connection
          </p>
        </div>
      ) : (
        <div className={styles.serverList}>
          {servers.map(server => (
            <div key={server.id} className={styles.serverCard}>
              <div className={styles.serverInfo}>
                <div className={styles.serverHeader}>
                  <h4>{server.name}</h4>
                  <span className={`${styles.status} ${styles[server.status || 'unknown']}`}>
                    {server.status || 'Unknown'}
                  </span>
                </div>
                <p className={styles.serverUrl}>{server.url}</p>
                {server.endpoints && Array.isArray(server.endpoints) && server.endpoints.length > 0 && (
                  <div className={styles.endpoints}>
                    <span className={styles.endpointsLabel}>Endpoints:</span>
                    {(server.endpoints as string[]).map((endpoint: string, index: number) => (
                      <span key={index} className={styles.endpoint}>
                        {endpoint}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className={styles.serverActions}>
                <button 
                  className={styles.actionButton}
                  onClick={() => handleCheckStatus(server)}
                  disabled={checkingStatus[server.id]}
                >
                  {checkingStatus[server.id] ? (
                    <span className={styles.spinner}></span>
                  ) : (
                    'Check Status'
                  )}
                </button>
                <button 
                  className={styles.actionButton}
                  onClick={() => handleEditServer(server)}
                >
                  Edit
                </button>
                <button 
                  className={`${styles.actionButton} ${styles.deleteButton}`}
                  onClick={() => handleDeleteServer(server.id)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <ServerFormModal
        show={isAddingServer}
        onClose={() => {
          setIsAddingServer(false);
          setSelectedServer(null);
        }}
        onSubmit={handleSubmit}
        server={selectedServer}
      />
    </div>
  );
};

export default ServerManagerSection; 
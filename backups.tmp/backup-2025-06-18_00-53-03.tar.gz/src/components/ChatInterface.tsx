import React, { useState, useEffect, useRef } from 'react';
import { Service, LLMModel } from '@/types';
import { sendMessage } from '@/utils/chrome';
import styles from '@/styles/components/ChatInterface.module.css';
import { v4 as uuidv4 } from 'uuid';
import { getChatSessions, saveChatSession, getCurrentSessionId, setCurrentSessionId } from '@/background/utils/storage';
import type { ChatMessage, ChatSession } from '@/types';
import ChatMessageComponent from './ChatMessage';

interface ChatInterfaceProps {
  service: Service;
  generationOptions?: {
    temperature: number;
    maxTokens: number;
    tools: {
      webSearch: boolean;
      codeInterpreter: boolean;
      fileUpload: boolean;
    };
  };
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ service, generationOptions }) => {
  const [models, setModels] = useState<LLMModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionIdState] = useState<string | null>(null);
  const [sendOnlyPrompt, setSendOnlyPrompt] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [modelsLoading, setModelsLoading] = useState(true);
  const [modelsError, setModelsError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const fetchModels = async () => {
      setModelsLoading(true);
      setModelsError(null);
      if (service) {
        try {
          console.log('[ChatInterface] Fetching models for service:', service.id, service.name);
          const fetchedModels = await sendMessage<LLMModel[]>('getModels', { serviceId: service.id });
          console.log('[ChatInterface] Received models:', fetchedModels);
          setModels(fetchedModels || []);
          setSelectedModel((fetchedModels && fetchedModels[0]?.id) || '');
          console.log('[ChatInterface] Set selected model to:', (fetchedModels && fetchedModels[0]?.id) || '');
        } catch (error) {
          console.error('[ChatInterface] Error fetching models:', error);
          setModelsError("Failed to fetch models");
          setModels([]);
        } finally {
          setModelsLoading(false);
        }
      }
    };
    fetchModels();
  }, [service]);

  useEffect(() => {
    const loadSessions = async () => {
      const allSessions = await getChatSessions(service.id);
      setSessions(allSessions.filter(s => s.messages && s.messages.length > 0));
      
      let sessionId = await getCurrentSessionId(service.id);
      if (!sessionId && allSessions.length > 0) {
        sessionId = allSessions[allSessions.length - 1].id;
        await setCurrentSessionId(service.id, sessionId);
      }
      setCurrentSessionIdState(sessionId);
      
      if (sessionId) {
        const session = allSessions.find(s => s.id === sessionId);
        if (session) {
          setMessages(session.messages);
        }
      }
    };
    
    loadSessions();
  }, [service.id]);

  useEffect(() => {
    // Restore last selected model for this service
    if (service) {
      const key = `lastModel_${service.id}`;
      const lastModel = localStorage.getItem(key);
      if (lastModel) {
        setSelectedModel(lastModel);
      }
    }
  }, [service]);

  const handleModelChange = (modelId: string) => {
    console.log('[ChatInterface] Model changed to:', modelId);
    setSelectedModel(modelId);
    if (service) {
      localStorage.setItem(`lastModel_${service.id}`, modelId);
    }
  };

  const handleNewChat = async () => {
    if (!service) return;
    setCurrentSessionIdState(null);
    setMessages([]);
  };

  const handleStopGeneration = async () => {
    try {
      await sendMessage('abortRequest', { serviceId: service.id });
      setIsLoading(false);
    } catch (error) {
      console.error('Error stopping generation:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!prompt.trim() || isLoading) return;
    
    console.log('[ChatInterface] Sending message with model:', selectedModel);
    console.log('[ChatInterface] Available models:', models);
    console.log('[ChatInterface] Generation options:', generationOptions);
    
    setIsLoading(true);
    let sessionId = currentSessionId || uuidv4();
    let session = sessions.find(s => s.id === sessionId);
    if (!session) {
      session = { 
        id: sessionId, 
        createdAt: Date.now(), 
        updatedAt: Date.now(),
        messages: [] 
      };
      setCurrentSessionIdState(sessionId);
    }
    
    const newMessage: ChatMessage = {
      id: uuidv4(),
      role: 'user',
      content: prompt,
      timestamp: Date.now()
    };
    
    let updatedMessages = [...(session?.messages || []), newMessage];
    setMessages(updatedMessages);
    setPrompt('');
    
    try {
      const toSend = sendOnlyPrompt ? [newMessage] : updatedMessages;
      console.log('[ChatInterface] Sending message with:', { 
        serviceId: service.id, 
        messageCount: toSend.length, 
        model: selectedModel,
        options: generationOptions
      });
      
      const fullHistory = await sendMessage('sendMessage', {
        serviceId: service.id,
        messages: toSend,
        model: selectedModel,
        sessionId: sessionId as string,
        options: generationOptions
      });
      
      console.log('[ChatInterface] Received fullHistory:', fullHistory);
      console.log('[ChatInterface] fullHistory type:', typeof fullHistory);
      console.log('[ChatInterface] fullHistory length:', Array.isArray(fullHistory) ? fullHistory.length : 'not an array');
      console.log('[ChatInterface] fullHistory content:', fullHistory);
      
      // Ensure we have the full response
      if (Array.isArray(fullHistory) && fullHistory.length > 0) {
        const lastMessage = fullHistory[fullHistory.length - 1];
        console.log('[ChatInterface] Last message:', lastMessage);
        console.log('[ChatInterface] Last message content:', lastMessage.content);
        console.log('[ChatInterface] Last message content length:', lastMessage.content?.length);
      }
      
      setMessages(fullHistory);
      // Print all messages for debugging
      console.log('[ChatInterface] All messages:', fullHistory.map((m: ChatMessage) => m.content));
      
      const updatedSession: ChatSession = {
        ...(session || {}),
        id: sessionId,
        createdAt: session?.createdAt || Date.now(),
        updatedAt: session?.updatedAt || Date.now(),
        messages: fullHistory
      };
      await saveChatSession(service.id, updatedSession);
      const allSessions = await getChatSessions(service.id);
      setSessions(allSessions.filter(s => s.messages && s.messages.length > 0));
      setCurrentSessionIdState(sessionId);
    } catch (error) {
      console.error('Error sending message:', error);
      let displayMessage = 'An unknown error occurred.';
      if (error instanceof Error) {
        if (error.message.includes('403')) {
          displayMessage = 'Access Denied (Error 403). Please check if an API key is required and correctly configured for this service in the settings.';
        } else if (error.message.includes('cancelled')) {
          displayMessage = 'Request was cancelled.';
        } else {
          displayMessage = error.message;
        }
      }
      setMessages(prev => [...prev, { id: uuidv4(), role: 'assistant', content: `Error: ${displayMessage}`, timestamp: Date.now() }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Action handlers for ChatMessage component
  const handleEditMessage = (messageId: string, newContent: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, content: newContent } : msg
    ));
  };

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    // Could add a toast notification here
  };

  const handleContinueResponse = async (messageId: string) => {
    const message = messages.find(msg => msg.id === messageId);
    if (!message || message.role !== 'assistant') return;
    
    setIsLoading(true);
    try {
      const response = await sendMessage('sendMessage', {
        serviceId: service.id,
        messages: [...messages, { role: 'user', content: 'Continue', id: uuidv4(), timestamp: Date.now() }],
        model: selectedModel,
        sessionId: currentSessionId || uuidv4(),
      });
      setMessages(response);
    } catch (error) {
      console.error('Error continuing response:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegenerateResponse = async (messageId: string) => {
    const messageIndex = messages.findIndex(msg => msg.id === messageId);
    if (messageIndex === -1 || messages[messageIndex].role !== 'assistant') return;
    
    // Remove the assistant message and regenerate
    const messagesBeforeAssistant = messages.slice(0, messageIndex);
    setMessages(messagesBeforeAssistant);
    
    setIsLoading(true);
    try {
      const response = await sendMessage('sendMessage', {
        serviceId: service.id,
        messages: messagesBeforeAssistant,
        model: selectedModel,
        sessionId: currentSessionId || uuidv4(),
      });
      setMessages(response);
    } catch (error) {
      console.error('Error regenerating response:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRateResponse = (messageId: string, rating: 'good' | 'bad') => {
    console.log(`Rating message ${messageId} as ${rating}`);
    // Could send rating to backend or store locally
  };

  const handleGenerateImage = (prompt: string) => {
    console.log('Generate image from prompt:', prompt);
    // Could open image generation service or send to background
  };

  const handleReadAloud = (content: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(content);
      speechSynthesis.speak(utterance);
    }
  };

  const handleDeleteMessage = (messageId: string) => {
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
  };

  return (
    <div className={styles.chatContainer}>
      {/* Model selector and controls */}
      <div className={styles.chatHeader}>
        <div className={styles.modelSelector}>
          {modelsLoading ? (
            <span className={styles.modelLoading}>Loading models...</span>
          ) : modelsError ? (
            <span className={styles.modelError}>{modelsError}</span>
          ) : (
            <select
              className={styles.modelSelect}
              value={selectedModel}
              onChange={(e) => handleModelChange(e.target.value)}
            >
              {models.map((model) => (
                <option key={model.id} value={model.id}>
                  {model.name}
                </option>
              ))}
            </select>
          )}
        </div>
        
        <div className={styles.chatControls}>
          <button onClick={handleNewChat} className={styles.newChatButton}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            New Chat
          </button>
        </div>
      </div>

      {/* Messages area */}
      <div className={styles.messagesContainer}>
        {messages.length === 0 ? (
          <div className={styles.welcomeMessage}>
            <div className={styles.welcomeIcon}>
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
            </div>
            <h2 className={styles.welcomeTitle}>Welcome to {service.name}</h2>
            <p className={styles.welcomeText}>
              Start a conversation with your AI assistant. You can ask questions, get help with tasks, or just chat.
            </p>
          </div>
        ) : (
          <div className={styles.messagesList}>
            {messages.map((msg, index) => (
              <ChatMessageComponent
                key={msg.id || index}
                message={msg}
                onEdit={handleEditMessage}
                onCopy={handleCopyMessage}
                onContinue={handleContinueResponse}
                onRegenerate={handleRegenerateResponse}
                onRate={handleRateResponse}
                onGenerateImage={handleGenerateImage}
                onReadAloud={handleReadAloud}
                onDelete={handleDeleteMessage}
                showActions={true}
                isLastMessage={msg.role === 'assistant' && index === messages.length - 1}
              />
            ))}
            
            {isLoading && (
              <div className={styles.loadingMessage}>
                <div className={styles.loadingIndicator}>
                  <div className={styles.loadingDots}>
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                  <span>Assistant is typing...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input area */}
      <div className={styles.inputArea}>
        <div className={styles.inputContainer}>
          <div className={styles.inputOptions}>
            <label className={styles.optionLabel}>
              <input 
                type="checkbox" 
                checked={sendOnlyPrompt} 
                onChange={(e) => setSendOnlyPrompt(e.target.checked)} 
                className={styles.optionCheckbox}
              />
              Send only current prompt
            </label>
          </div>
          
          <div className={styles.inputWrapper}>
            <textarea
              className={styles.messageInput}
              placeholder="Type your message here..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyPress={handleKeyPress}
              rows={1}
              disabled={isLoading}
            />
            <div className={styles.inputButtons}>
              {isLoading ? (
                <button 
                  onClick={handleStopGeneration} 
                  className={`${styles.sendButton} ${styles.stopButton}`}
                  title="Stop Generation"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="6" y="6" width="12" height="12"></rect>
                  </svg>
                </button>
              ) : (
                <button 
                  onClick={handleSendMessage} 
                  className={styles.sendButton}
                  disabled={!prompt.trim()}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22,2 15,22 11,13 2,9"></polygon>
                  </svg>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
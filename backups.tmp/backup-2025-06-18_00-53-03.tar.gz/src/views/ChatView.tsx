import React, { useState, useRef } from 'react';
import { Service } from '@/types';
import ChatInterface from '@/components/ChatInterface';
import ViewHeader from '@/components/ViewHeader';
import styles from '@/styles/views/ChatView.module.css';

interface ChatViewProps {
  service: Service;
  isTab?: boolean;
}

const ChatView: React.FC<ChatViewProps> = ({ service, isTab = false }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [showModelSettings, setShowModelSettings] = useState(false);
  const [showPromptModal, setShowPromptModal] = useState(false);
  
  // Slider states
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(2048);
  
  // Checkbox states
  const [webSearch, setWebSearch] = useState(false);
  const [codeInterpreter, setCodeInterpreter] = useState(false);
  const [fileUpload, setFileUpload] = useState(false);
  
  const containerRef = useRef<HTMLDivElement>(null);

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const handleRefresh = () => {
    window.location.reload();
  };

  const handleClose = () => {
    if (isTab) {
      window.close();
    } else {
      chrome.runtime.sendMessage({ action: 'closePanel' });
    }
  };

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };

  const toggleControls = () => {
    setShowControls(!showControls);
  };

  const handleModelSettings = () => {
    setShowModelSettings(!showModelSettings);
  };

  const handlePromptModal = () => {
    setShowPromptModal(!showPromptModal);
  };

  // Create generation options object to pass to ChatInterface
  const generationOptions = {
    temperature,
    maxTokens,
    tools: {
      webSearch,
      codeInterpreter,
      fileUpload
    }
  };

  return (
    <div 
      ref={containerRef}
      className={`${styles.container} ${isFullscreen ? styles.fullscreen : ''} ${isTab ? styles.tabView : styles.panelView}`}
    >
      {/* Header with controls */}
      <ViewHeader service={service} isTab={isTab} />
      <header className={styles.header}>
        <div className={styles.headerControls}>
          <button onClick={toggleSidebar} className={styles.headerButton} title="Toggle Sidebar">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="3" y1="6" x2="21" y2="6"></line>
              <line x1="3" y1="12" x2="21" y2="12"></line>
              <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
          </button>
          <button onClick={toggleControls} className={styles.headerButton} title="Toggle Controls">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="3"></circle>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
            </svg>
          </button>
          <button onClick={handleFullscreen} className={styles.headerButton} title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {isFullscreen ? (
                <>
                  <polyline points="4,14 10,14 10,20"></polyline>
                  <polyline points="20,10 14,10 14,4"></polyline>
                  <line x1="14" y1="10" x2="21" y2="3"></line>
                  <line x1="3" y1="21" x2="10" y2="14"></line>
                </>
              ) : (
                <>
                  <polyline points="15,3 21,3 21,9"></polyline>
                  <polyline points="9,21 3,21 3,15"></polyline>
                  <line x1="21" y1="3" x2="14" y2="10"></line>
                  <line x1="3" y1="21" x2="10" y2="14"></line>
                </>
              )}
            </svg>
          </button>
          <button onClick={handleRefresh} className={styles.headerButton} title="Refresh">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="23,4 23,10 17,10"></polyline>
              <polyline points="1,20 1,14 7,14"></polyline>
              <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"></path>
            </svg>
          </button>
          <button onClick={handleClose} className={styles.headerButton} title="Close">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </header>
      {/* Main content area with collapsible layout */}
      <div className={styles.mainContent}>
        {/* Sidebar */}
        {showSidebar && (
          <aside className={styles.sidebar}>
            <div className={styles.sidebarContent}>
              <div className={styles.sidebarSection}>
                <h3 className={styles.sidebarTitle}>Chat History</h3>
                <div className={styles.chatHistory}></div>
              </div>
              <div className={styles.sidebarSection}>
                <h3 className={styles.sidebarTitle}>Settings</h3>
                <div className={styles.settingsList}>
                  <button onClick={handleModelSettings} className={styles.settingsButton}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="3"></circle>
                      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                    </svg>
                    Model Settings
                  </button>
                  <button onClick={handlePromptModal} className={styles.settingsButton}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
                    </svg>
                    Prompts
                  </button>
                </div>
              </div>
            </div>
          </aside>
        )}
        {/* Chat area */}
        <main className={`${styles.chatArea} ${!showSidebar ? styles.fullWidth : ''}`}>
          <ChatInterface service={service} generationOptions={generationOptions} />
        </main>
        {/* Controls panel */}
        {showControls && (
          <aside className={styles.controlsPanel}>
            <div className={styles.controlsContent}>
              <div className={styles.controlsSection}>
                <h3 className={styles.controlsTitle}>Parameters</h3>
                <div className={styles.parameterGroup}>
                  <label className={styles.parameterLabel}>
                    Temperature
                    <input 
                      type="range" 
                      min="0" 
                      max="2" 
                      step="0.1" 
                      value={temperature}
                      onChange={(e) => setTemperature(parseFloat(e.target.value))}
                      className={styles.parameterSlider}
                    />
                    <span className={styles.parameterValue}>{temperature}</span>
                  </label>
                </div>
                <div className={styles.parameterGroup}>
                  <label className={styles.parameterLabel}>
                    Max Tokens
                    <input 
                      type="range" 
                      min="1" 
                      max="4096" 
                      step="1" 
                      value={maxTokens}
                      onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                      className={styles.parameterSlider}
                    />
                    <span className={styles.parameterValue}>{maxTokens}</span>
                  </label>
                </div>
              </div>
              <div className={styles.controlsSection}>
                <h3 className={styles.controlsTitle}>Tools</h3>
                <div className={styles.toolsList}>
                  <label className={styles.toolItem}>
                    <input 
                      type="checkbox" 
                      className={styles.toolCheckbox}
                      checked={webSearch}
                      onChange={(e) => setWebSearch(e.target.checked)}
                    />
                    <span>Web Search</span>
                  </label>
                  <label className={styles.toolItem}>
                    <input 
                      type="checkbox" 
                      className={styles.toolCheckbox}
                      checked={codeInterpreter}
                      onChange={(e) => setCodeInterpreter(e.target.checked)}
                    />
                    <span>Code Interpreter</span>
                  </label>
                  <label className={styles.toolItem}>
                    <input 
                      type="checkbox" 
                      className={styles.toolCheckbox}
                      checked={fileUpload}
                      onChange={(e) => setFileUpload(e.target.checked)}
                    />
                    <span>File Upload</span>
                  </label>
                </div>
              </div>
            </div>
          </aside>
        )}
      </div>
      
      {/* Model Settings Modal */}
      {showModelSettings && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <h3>Model Settings</h3>
              <button onClick={handleModelSettings} className={styles.modalClose}>×</button>
            </div>
            <div className={styles.modalContent}>
              <p>Model settings configuration will be implemented here.</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Prompt Modal */}
      {showPromptModal && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <h3>Prompt Management</h3>
              <button onClick={handlePromptModal} className={styles.modalClose}>×</button>
            </div>
            <div className={styles.modalContent}>
              <p>Prompt management interface will be implemented here.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatView;

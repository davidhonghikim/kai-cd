import React, { useState } from 'react';
import ViewHeader from './ViewHeader';
import styles from '@/styles/components/IframeView.module.css';

interface IframeViewProps {
  url: string;
  service?: any; // Add service prop for ViewHeader
  isTab?: boolean;
}

export const IframeView: React.FC<IframeViewProps> = ({
  url,
  service,
  isTab = false
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const handleLoad = () => {
    setIsLoading(false);
    setHasError(false);
  };

  const handleError = () => {
    setIsLoading(false);
    setHasError(true);
  };

  return (
    <div className={styles.container}>
      {service && <ViewHeader service={service} isTab={isTab} />}
      
      <div className={styles.iframeContainer}>
        {isLoading && (
          <div className={styles.loadingOverlay}>
            <div className={styles.loadingSpinner} />
            <div>Loading...</div>
          </div>
        )}

        {hasError && (
          <div className={styles.errorOverlay}>
            <div>Failed to load content</div>
            <button onClick={() => window.location.reload()} className={styles.button}>
              Retry
            </button>
          </div>
        )}

        <iframe
          src={url}
          className={styles.iframe}
          onLoad={handleLoad}
          onError={handleError}
          data-testid="service-iframe"
        />
      </div>
    </div>
  );
};

export default IframeView; 
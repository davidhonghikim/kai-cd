import React from 'react';
import { Service } from '@/types';
import ChatView from '../views/ChatView';
import A1111View from '../views/A1111View';
import ComfyUIView from '../views/ComfyUIView';
import OpenWebUIView from '../views/OpenWebUIView';
import { SERVICE_TYPES } from '@/config/constants';

interface ViewRouterProps {
  service: Service;
  isTab?: boolean;
}

const IframeView: React.FC<{ service: Service }> = ({ service }) => (
  <iframe
    src={service.url}
    style={{ width: '100%', height: '100%', border: 'none' }}
    title={service.name}
  />
);

const ViewRouter: React.FC<ViewRouterProps> = ({ service, isTab = false }) => {
  // Services that have their own full web UI
  const servicesWithNativeUI: Service['type'][] = [
    SERVICE_TYPES.OPEN_WEBUI,
    SERVICE_TYPES.A1111,
    SERVICE_TYPES.COMFY_UI,
    SERVICE_TYPES.N8N,
  ];

  // Logic for Tab View
  if (isTab) {
    if (servicesWithNativeUI.includes(service.type)) {
      // For services with their own UI, embed them in an iframe in the tab
      return <IframeView service={service} />;
    }
    // For API-only services, use our custom rich chat view in the tab
    return <ChatView service={service} />;
  }

  // Logic for Side Panel View (condensed, quick-action views)
  switch (service.type) {
    case SERVICE_TYPES.OLLAMA:
    case SERVICE_TYPES.OPENAI_COMPATIBLE:
      return <ChatView service={service} />;

    case SERVICE_TYPES.A1111:
      return <A1111View service={service} />;

    case SERVICE_TYPES.COMFY_UI:
      return <ComfyUIView service={service} />;

    case SERVICE_TYPES.OPEN_WEBUI:
      return <OpenWebUIView service={service} />;

    case SERVICE_TYPES.N8N:
      return (
        <div className="n8n-panel-view">
          <h2>N8N Quick Access</h2>
          <p>Access your automation workflows</p>
          <button onClick={() => window.open(service.url, '_blank')}>
            Open N8N Interface
          </button>
        </div>
      );

    default:
      // Fallback for any other service type is to just show their UI in an iframe
      return <IframeView service={service} />;
  }
};

export default ViewRouter;

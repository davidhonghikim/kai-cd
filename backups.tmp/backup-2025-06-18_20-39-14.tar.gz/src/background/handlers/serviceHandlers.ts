/* eslint-disable @typescript-eslint/no-unused-vars */
import { storageManager } from '@/storage/storageManager';
import { SERVERS_KEY } from '@/utils/settingsIO';
import { Service } from '@/types';
// @ts-ignore
import { v4 as uuidv4 } from 'uuid';
import { RequestHandler } from './types';
import { getStoredServices } from '../utils/storage';
import { connectorManager } from '../connectors';

export const handleGetServices: RequestHandler<undefined, { success: boolean, services: Service[], error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    sendResponse({ success: true, services });
  } catch (error) {
    sendResponse({ success: false, services: [], error: 'Failed to get services' });
  }
};

export const handleAddService: RequestHandler<Partial<Service>, { success: boolean, service: Service, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const newService: Service = {
      id: uuidv4(),
      name: payload.name || 'New Service',
      type: payload.type || 'ollama',
      url: payload.url || '',
      apiKey: payload.apiKey,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isActive: false,
      status: 'unknown',
      category: 'LLM',
      requiresApiKey: false,
      enabled: true,
    };
    const updatedServices = [...services, newService];
    await storageManager.set(SERVERS_KEY, updatedServices);
    sendResponse({ success: true, service: newService });
  } catch (error) {
    sendResponse({ success: false, service: {} as Service, error: 'Failed to add service' });
  }
};

export const handleUpdateService: RequestHandler<Service, { success: boolean, service: Service, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const index = services.findIndex(s => s.id === payload.id);
    if (index === -1) {
      throw new Error('Service not found');
    }
    const updatedServices = [...services];
    updatedServices[index] = payload;
    await storageManager.set(SERVERS_KEY, updatedServices);
    sendResponse({ success: true, service: payload });
  } catch (error) {
    sendResponse({ success: false, service: {} as Service, error: 'Failed to update service' });
  }
};

export const handleDeleteService: RequestHandler<{ id: string }, { success: boolean, error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const updatedServices = services.filter(s => s.id !== payload.id);
    await storageManager.set(SERVERS_KEY, updatedServices);
    connectorManager.removeConnector(payload.id);
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: 'Failed to delete service' });
  }
};

export const serviceHandlers = {
  getServices: handleGetServices,
  addService: handleAddService,
  updateService: handleUpdateService,
  deleteService: handleDeleteService,
}; 
import React from 'react';
import { useChatSession } from '@/hooks/useChatSession';
import ChatInterface from '@/components/ChatInterface';
import styles from '@/styles/views/ChatView.module.css';
import { Service } from '@/types';

interface ChatViewProps {
  service: Service;
}

const ChatView: React.FC<ChatViewProps> = ({ service }) => {
  const {
    activeSession,
    models,
    isLoading,
    error,
    createNewSession,
    sendMessage,
  } = useChatSession(service.id);

  if (isLoading) {
    return (
      <div className={styles.chatViewContainer}>
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner}></div>
          <p>Loading chat session...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.chatViewContainer}>
        <div className={styles.errorContainer}>
          <div className={styles.errorIcon}>⚠️</div>
          <h3>Error</h3>
          <p>{error}</p>
          <button 
            className={styles.retryButton}
            onClick={() => window.location.reload()}
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!activeSession) {
    return (
      <div className={styles.chatViewContainer}>
        <div className={styles.welcomeContainer}>
          <h2>Welcome to {service.name}</h2>
          <p>Start a new conversation with the AI assistant</p>
          
          <div className={styles.modelSelector}>
            <h3>Available Models</h3>
            <div className={styles.modelGrid}>
              {models.length > 0 ? (
                models.map(model => (
                  <div 
                    key={model.id} 
                    className={styles.modelCard}
                    onClick={() => createNewSession(service.id)}
                  >
                    <h4>{model.name}</h4>
                    <button>Start Chat</button>
                  </div>
                ))
              ) : (
                <div className={styles.noModels}>
                  <p>No models available</p>
                  <button 
                    className={styles.primaryButton}
                    onClick={() => createNewSession(service.id)}
                  >
                    Start New Chat
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.chatViewContainer}>
      <ChatInterface
        messages={activeSession.messages}
        onSendMessage={sendMessage}
        models={models}
        selectedModel={activeSession.model || (models.length > 0 ? models[0].id : '')}
        onModelChange={(modelId) => console.log('Model changed to:', modelId)}
        isLoading={isLoading}
      />
    </div>
  );
};

export default ChatView;

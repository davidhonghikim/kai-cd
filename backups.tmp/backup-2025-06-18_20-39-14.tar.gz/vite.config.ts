import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');

  return {
    plugins: [react()],
    resolve: {
      alias: {
        '@': resolve(__dirname, './src'),
      },
    },
    build: {
      rollupOptions: {
        input: {
          popup: resolve(__dirname, 'src/popup/index.html'),
          options: resolve(__dirname, 'src/options/index.html'),
          sidepanel: resolve(__dirname, 'src/sidepanel/index.html'),
          tab: resolve(__dirname, 'src/tab/index.html'),
          background: resolve(__dirname, 'src/background/main.ts'),
        },
        output: {
          entryFileNames: (chunkInfo) => {
            if (chunkInfo.name === 'background') {
              return '[name].js';
            }
            return `assets/${chunkInfo.name}.js`;
          },
          chunkFileNames: 'assets/chunks/[name].js',
          assetFileNames: (assetInfo) => {
            if (assetInfo.name?.endsWith('.html')) {
              return '[name].html';
            }
            return `assets/[name].[ext]`;
          },
        },
      },
      outDir: 'dist',
      emptyOutDir: true,
    },
    server: {
      port: Number(env.VITE_PORT) || 5173,
      watch: {
        ignored: ['**/dist/**', '**/.git/**'],
      },
    },
  };
}); 
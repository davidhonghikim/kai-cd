import { ChatSession, ChatMessage } from '@/types';

/**
 * Generate a smart title for a chat session based on the conversation content
 * Similar to how OWU and ChatGPT title conversations
 */
export const generateSessionTitle = (messages: ChatMessage[]): string => {
  if (!messages || messages.length === 0) {
    return 'New Chat';
  }

  // Find the first user message to use as title
  const firstUserMessage = messages.find(msg => msg.role === 'user');
  if (!firstUserMessage) {
    return 'New Chat';
  }

  let title = firstUserMessage.content.trim();
  
  // Truncate if too long (like OWU does)
  if (title.length > 50) {
    title = title.substring(0, 50).trim() + '...';
  }
  
  // Remove markdown formatting for cleaner titles
  title = title.replace(/[*_`#]/g, '');
  
  // Remove URLs
  title = title.replace(/https?:\/\/[^\s]+/g, '');
  
  // Clean up extra whitespace
  title = title.replace(/\s+/g, ' ').trim();
  
  return title || 'New Chat';
};

/**
 * Sort sessions by date (newest first, like OWU)
 */
export const sortSessionsByDate = (sessions: ChatSession[]): ChatSession[] => {
  return [...sessions].sort((a, b) => {
    // Sort by updatedAt first, then by createdAt
    const aTime = a.updatedAt || a.createdAt;
    const bTime = b.updatedAt || b.createdAt;
    return bTime - aTime;
  });
};

/**
 * Check if a session has meaningful content (not just empty or error messages)
 */
export const hasValidContent = (session: ChatSession): boolean => {
  if (!session.messages || session.messages.length === 0) {
    return false;
  }
  
  // Check if there's at least one user message and one assistant response
  const userMessages = session.messages.filter(msg => msg.role === 'user');
  const assistantMessages = session.messages.filter(msg => msg.role === 'assistant');
  
  if (userMessages.length === 0) {
    return false;
  }
  
  // Check if assistant messages have real content (not just errors)
  const hasValidAssistantResponse = assistantMessages.some(msg => 
    msg.content && 
    !msg.content.startsWith('Error:') && 
    msg.content.trim().length > 0
  );
  
  return hasValidAssistantResponse;
};

/**
 * Format date for display in session list
 */
export const formatSessionDate = (timestamp: number): string => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
  
  if (diffInHours < 24) {
    // Today - show time
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } else if (diffInHours < 48) {
    // Yesterday
    return 'Yesterday';
  } else if (diffInHours < 168) { // 7 days
    // This week - show day name
    return date.toLocaleDateString([], { weekday: 'short' });
  } else {
    // Older - show date
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }
}; 
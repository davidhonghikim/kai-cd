import React, { useState, useRef } from 'react';
import { Service } from '@/types';
import ChatInterface from '@/components/ChatInterface';
import ViewHeader from '@/components/ViewHeader';
import styles from '@/styles/views/ChatView.module.css';

interface ChatViewProps {
  service: Service;
  isTab?: boolean;
}

const ChatView: React.FC<ChatViewProps> = ({ service, isTab = false }) => {
  const [showModelSettings, setShowModelSettings] = useState(false);
  const [showPromptModal, setShowPromptModal] = useState(false);
  
  // Slider states - only values, no setters needed
  const temperature = 0.7;
  const maxTokens = 2048;
  
  // Checkbox states - only values, no setters needed
  const webSearch = false;
  const codeInterpreter = false;
  const fileUpload = false;
  
  const containerRef = useRef<HTMLDivElement>(null);

  const handleModelSettings = () => {
    setShowModelSettings(!showModelSettings);
  };

  const handlePromptModal = () => {
    setShowPromptModal(!showPromptModal);
  };

  // Create generation options object to pass to ChatInterface
  const generationOptions = {
    temperature,
    maxTokens,
    tools: {
      webSearch,
      codeInterpreter,
      fileUpload
    }
  };

  return (
    <div 
      ref={containerRef}
      className={`${styles.container} ${isTab ? styles.tabView : styles.panelView}`}
    >
      {/* Header */}
      <ViewHeader service={service} isTab={isTab} />
      
      {/* Main content area */}
      <div className={styles.mainContent}>
        {/* Chat area */}
        <main className={styles.chatArea}>
          <ChatInterface service={service} generationOptions={generationOptions} />
        </main>
      </div>
      
      {/* Model Settings Modal */}
      {showModelSettings && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <h3>Model Settings</h3>
              <button onClick={handleModelSettings} className={styles.modalClose}>×</button>
            </div>
            <div className={styles.modalContent}>
              <p>Model settings configuration will be implemented here.</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Prompt Modal */}
      {showPromptModal && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <h3>Prompt Management</h3>
              <button onClick={handlePromptModal} className={styles.modalClose}>×</button>
            </div>
            <div className={styles.modalContent}>
              <p>Prompt management interface will be implemented here.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatView;

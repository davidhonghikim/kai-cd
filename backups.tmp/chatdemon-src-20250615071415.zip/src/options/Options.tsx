import React, { useState, useEffect } from 'react';
import type { Service } from '../config/types';
import { sendMessage } from '../utils/chrome';
import ServiceForm from './ServiceForm';
import ServiceDetails from './ServiceDetails';
import { SERVICE_TYPES, SERVICE_CATEGORIES } from '../config/constants';

type ServiceStatus = {
  [key: string]: {
    state: 'online' | 'offline' | 'checking' | 'unknown';
    details?: any;
    message?: string;
  }
};

const Options: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [editingService, setEditingService] = useState<Partial<Service> | null>(null);
  const [viewingService, setViewingService] = useState<Service | null>(null);
  const [statuses, setStatuses] = useState<ServiceStatus>({});

  const loadServices = async () => {
    try {
      const allServices = await sendMessage<Service[]>('getServices');
      setServices(allServices || []);
    } catch (error) {
      console.error('Failed to load services:', error);
      setServices([]);
    }
  };

  useEffect(() => {
    loadServices();
  }, []);

  const handleCheckStatus = async (serviceId: string) => {
    setStatuses(prev => ({ ...prev, [serviceId]: { state: 'checking' } }));
    try {
      const status = await sendMessage('checkStatus', { serviceId });
      setStatuses(prev => ({
        ...prev,
        [serviceId]: {
          state: status.isOnline ? 'online' : 'offline',
          details: status.details,
          message: status.error,
        }
      }));
    } catch (error) {
      console.error('Failed to check status:', error);
      setStatuses(prev => ({
        ...prev,
        [serviceId]: {
          state: 'offline',
          message: error instanceof Error ? error.message : 'An unknown error occurred.'
        }
      }));
    }
  };

  const handleSaveService = async (serviceData: Partial<Service>) => {
    try {
      const action = serviceData.id ? 'updateService' : 'addService';
      await sendMessage(action, serviceData);
      setEditingService(null);
      loadServices();
    } catch (error) {
      console.error('Failed to save service:', error);
      alert(`Error saving service: ${error instanceof Error ? error.message : error}`);
    }
  };

  const handleRemoveService = async (serviceId: string) => {
    if (window.confirm('Are you sure you want to delete this service?')) {
      try {
        await sendMessage('removeService', { id: serviceId });
        loadServices();
      } catch (error) {
        console.error('Failed to remove service:', error);
        alert(`Error removing service: ${error instanceof Error ? error.message : error}`);
      }
    }
  };

  const handleAddNew = () => {
    setEditingService({
      name: '',
      type: SERVICE_TYPES.OLLAMA,
      url: '',
      apiKey: '',
      category: SERVICE_CATEGORIES.LLM,
    });
  };

  return (
    <div className="optionsContainer">
      <header className="header">
        <h1>ChatDemon Settings</h1>
        <button onClick={handleAddNew} className="primaryButton">Add New Service</button>
      </header>

      {editingService && (
        <ServiceForm
          // @ts-ignore
          initialData={editingService}
          onSave={handleSaveService}
          onCancel={() => setEditingService(null)}
          isNew={!editingService.id}
        />
      )}

      {viewingService && (
        <ServiceDetails service={viewingService} onClose={() => setViewingService(null)} />
      )}

      <div className="serviceList">
        {services.map(service => (
          <div key={service.id} className="serviceItem">
            <div className="serviceInfo">
              <span className={`statusIndicator ${statuses[service.id]?.state || 'unknown'}`}></span>
              <div>
                <strong className="serviceName">{service.name}</strong>
                <span className="serviceType">{service.type} - {service.url}</span>
                {statuses[service.id]?.state === 'online' && (
                  <span className="statusDetails">
                    Models: {statuses[service.id]?.details?.modelCount ?? '...'}
                  </span>
                )}
                {statuses[service.id]?.state === 'offline' && statuses[service.id]?.message && (
                  <span className="statusDetails errorText">
                    {statuses[service.id]?.message}
                  </span>
                )}
              </div>
            </div>
            <div className="serviceActions">
              <button onClick={() => handleCheckStatus(service.id)} disabled={statuses[service.id]?.state === 'checking'}>
                {statuses[service.id]?.state === 'checking' ? 'Checking...' : 'Check Status'}
              </button>
              <button onClick={() => setViewingService(service)}>Details</button>
              <button onClick={() => setEditingService(service)}>Edit</button>
              <button onClick={() => handleRemoveService(service.id)} className="dangerButton">Remove</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Options; 
import React, { useState, useEffect } from 'react';
import type { Service, ServiceType } from '../config/types';
import {
  SERVICE_TYPES,
  getDefaultServiceUrl,
  SERVICE_DISPLAY_NAMES,
  SERVICE_TYPE_TO_CATEGORY,
} from '../config/constants';

interface ServiceFormProps {
  initialData: Partial<Service>;
  onSave: (serviceData: Partial<Service>) => void;
  onCancel: () => void;
  isNew: boolean;
}

const ServiceForm: React.FC<ServiceFormProps> = ({ initialData, onSave, onCancel, isNew }) => {
  const [formState, setFormState] = useState<Partial<Service>>(initialData);

  useEffect(() => {
    setFormState(initialData);
  }, [initialData]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormState((prev) => {
      const newState: Partial<Service> = { ...prev, [name]: value };
      if (name === 'type') {
        const serviceType = value as ServiceType;
        if (isNew) {
          newState.url = getDefaultServiceUrl(serviceType) || prev.url;
        }
        newState.category = SERVICE_TYPE_TO_CATEGORY[serviceType];
      }
      return newState;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.url) {
      alert('Service Name and URL are required.');
      return;
    }
    onSave(formState);
  };

  return (
    <form onSubmit={handleSubmit} className="serviceForm">
      <input
        type="text"
        name="name"
        placeholder="Service Name"
        value={formState.name || ''}
        onChange={handleInputChange}
        required
      />
      <select name="type" value={formState.type} onChange={handleInputChange} required>
        <option value="" disabled>-- Select a Service Type --</option>
        {(Object.keys(SERVICE_DISPLAY_NAMES) as Array<keyof typeof SERVICE_DISPLAY_NAMES>).map((type) => (
          <option key={type} value={type}>
            {SERVICE_DISPLAY_NAMES[type] || type}
          </option>
        ))}
      </select>
      <input
        type="text"
        name="url"
        placeholder="Full Base URL (e.g., http://host:port/v1)"
        value={formState.url || ''}
        onChange={handleInputChange}
        required
      />
      <input
        type="password"
        name="apiKey"
        placeholder="API Key (optional)"
        value={formState.apiKey || ''}
        onChange={handleInputChange}
      />
      <div>
        <button type="submit">{isNew ? 'Add Service' : 'Save Changes'}</button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
};

export default ServiceForm; 
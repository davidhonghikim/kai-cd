import React, { useState, useEffect } from 'react';
import type { Service } from '@/config/types';
import { sendMessage } from '@/utils/chrome';
import ViewRouter from '@/components/ViewRouter';
import styles from '@/styles/components/sidepanel/SidePanel.module.css';

const SidePanel: React.FC = () => {
  const [activeService, setActiveService] = useState<Service | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initialize = async () => {
      setIsLoading(true);
      try {
        const service = await sendMessage<Service | null>('getActiveService', null);
        setActiveService(service);
      } catch (error) {
        console.error('Failed to initialize side panel:', error);
      }
      setIsLoading(false);
    };
    initialize();
  }, []);

  const renderContent = () => {
    if (isLoading) return <p>Loading...</p>;

    if (!activeService) {
      return (
        <div className={styles.placeholder}>
          <h2>Select a Service</h2>
          <p>Open the extension popup to select an active service.</p>
        </div>
      );
    }

    return <ViewRouter service={activeService} />;
  };

  return <div className={styles.sidePanel}>{renderContent()}</div>;
};

export default SidePanel;
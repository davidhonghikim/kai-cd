import { setActiveService } from './serviceHandlers';

/**
 * Opens the side panel for a specific service and tab.
 * This sets the panel's content and makes it visible.
 */
export async function openSidePanel({ serviceId, tabId }: { serviceId: string; tabId: number }) {
  if (!tabId) {
    throw new Error('No tabId provided to openSidePanel');
  }

  // Set the active service so the side panel knows what to display
  await setActiveService({ serviceId });

  // The side panel's content is always served from 'sidepanel.html'
  // The path is relative to the extension's root directory.
  await chrome.sidePanel.setOptions({
    tabId,
    path: 'src/sidepanel/sidepanel.html',
    enabled: true,
  });

  // This ensures the panel is visible to the user.
  await chrome.sidePanel.open({ tabId });
}

/**
 * Hides the side panel for a given tab by disabling it.
 */
export async function hideSidePanel({ tabId }: { tabId?: number }) {
    let currentTabId = tabId;
    // If no tabId is provided, get it from the active tab.
    if (!currentTabId) {
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!activeTab || !activeTab.id) {
            throw new Error('Could not determine active tab to hide side panel.');
        }
        currentTabId = activeTab.id;
    }

  // Disable the panel for the given tab
  await chrome.sidePanel.setOptions({
    tabId: currentTabId,
    enabled: false,
  });
}

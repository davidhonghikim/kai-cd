import * as serviceHandlers from './serviceHandlers';
import * as chatHandlers from './chatHandlers';
import * as imageHandlers from './imageHandlers';
import * as promptHandlers from './promptHandlers';
import * as panelHandlers from './panelHandlers';

/**
 * A registry of all available background request handlers.
 */
export const handlers = {
  ...serviceHandlers,
  ...chatHandlers,
  ...imageHandlers,
  ...promptHandlers,
  ...panelHandlers,
};

export type Handlers = typeof handlers;
export type Action = keyof Handlers;

import { Service, ChatMessage, ServiceStatus } from "@/config/types";

export interface RequestHandler<T = any> {
  (payload: any, context: RequestContext): Promise<T>;
}

export interface RequestContext {
  serviceId?: string;
  userId?: string;
  [key: string]: any;
}

export interface ServiceConnector {
  getStatus(): Promise<ServiceStatus>;
  getModels(): Promise<any[]>;
  chat(messages: ChatMessage[], model: string, options?: any): Promise<ChatMessage>;
  generateImage?(prompt: string, options?: any): Promise<{ imageUrl: string; id: string }>;
}

export interface ServiceHandlers {
  [key: string]: RequestHandler;
}

export * from "@/config/types";

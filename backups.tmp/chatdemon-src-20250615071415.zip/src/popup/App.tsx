import React, { useState, useEffect } from 'react';
import styles from '@/styles/components/popup/App.module.css';
import { Service } from '@/config/types';
import { sendMessage } from '@/utils/chrome';

const App: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [panelState, setPanelState] = useState<{ enabled: boolean, service: Service | null }>({ enabled: false, service: null });

  const checkPanelState = async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
          try {
            const options = await chrome.sidePanel.getOptions({ tabId: tab.id });
            const enabled = !!options?.enabled;
            const activeServiceId = await sendMessage('getActiveServiceId');
            const allServices: Service[] = (await sendMessage('getServices')) || [];
            const service = allServices.find(s => s.id === activeServiceId) || null;
            setPanelState({ enabled, service });
          } catch (e) {
            console.warn("Side panel API not available on this page or context.");
            setPanelState({ enabled: false, service: null });
          }
      }
  };

  useEffect(() => {
    const loadData = async () => {
      const allServices: Service[] = (await sendMessage('getServices')) || [];
      setServices(allServices);
      await checkPanelState();
    };
    
    loadData();

    // Listen for tab changes to update panel state
    chrome.tabs.onActivated.addListener(checkPanelState);
    chrome.tabs.onUpdated.addListener(checkPanelState);
    chrome.windows.onFocusChanged.addListener(checkPanelState);

    return () => {
        chrome.tabs.onActivated.removeListener(checkPanelState);
        chrome.tabs.onUpdated.removeListener(checkPanelState);
        chrome.windows.onFocusChanged.removeListener(checkPanelState);
    }
  }, []);

  const openOptionsPage = () => sendMessage('openOptionsPage');

  const handleTogglePanel = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
        console.error("Could not get active tab.");
        return;
    }

    if (panelState.enabled) {
      await sendMessage('hideSidePanel', { tabId: tab.id });
    } else {
      if (services.length === 0) {
        openOptionsPage();
        return;
      }
      await sendMessage(
        'openSidePanel',
        { serviceId: services[0].id, tabId: tab.id },
      );
    }
    await checkPanelState();
  };

  const handleOpenInPanel = async (service: Service) => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
        await sendMessage(
            'openSidePanel',
            { serviceId: service.id, tabId: tab.id } 
        );
        await checkPanelState();
    }
  };

  const handleOpenInTab = (service: Service) => {
    sendMessage(
      'openServiceInTab',
      { serviceId: service.id },
    );
  };

  return (
    <div className={styles.app}>
      <header className={styles.header}>
        <h1>ChatDemon</h1>
        <div className={styles.headerActions}>
            <button
              onClick={handleTogglePanel}
              className={styles.headerButton}
            >
              {panelState.enabled ? 'Hide Panel' : 'Show Panel'}
            </button>
            <button onClick={openOptionsPage} className={styles.headerButton}>
            Manage Services
            </button>
        </div>
      </header>
      <main className={styles.mainContent}>
        {services.length > 0 ? (
          services.map((service) => (
            <div key={service.id} className={styles.serviceCard}>
              <div className={styles.serviceInfo}>
                <span className={styles.serviceName}>{service.name}</span>
                <span className={styles.serviceType}>{service.type}</span>
              </div>
              <div className={styles.serviceActions}>
                <button onClick={() => handleOpenInPanel(service)}>
                    {panelState.enabled && panelState.service?.id === service.id ? 'Reload Panel' : 'Open in Panel'}
                </button>
                <button onClick={() => handleOpenInTab(service)}>Open in Tab</button>
              </div>
            </div>
          ))
        ) : (
          <div className={styles.noServices}>
            <p>No services configured.</p>
            <button onClick={openOptionsPage}>Add a Service</button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App; 
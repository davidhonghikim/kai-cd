import { BaseConnector } from "@/services/base/BaseConnector";
import type { Service } from "@/config/types";

interface TailscaleStatus {
  status: string;
  models?: any[];
}

interface TailscaleService extends Service {
  apiKey: string;
}

export class TailscaleConnector extends BaseConnector<TailscaleStatus> {
  private baseUrl: string;

  constructor(service: Service) {
    super(service);
    this.baseUrl = service.url.endsWith('/') ? service.url.slice(0, -1) : service.url;
  }

  async connect(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/v2/status`);
      const isConnected = response.ok;
      this._isConnected = isConnected;
      return isConnected;
    } catch (error) {
      console.error('Error connecting to Tailscale:', error);
      this._isConnected = false;
      return false;
    }
  }

  async disconnect(): Promise<void> {
    this._isConnected = false;
  }

  async checkStatus(): Promise<{ isOnline: boolean; details?: TailscaleStatus; error?: string }> {
    try {
      const response = await fetch(`${this.baseUrl}/api/v2/status`);
      const isOnline = response.ok;
      
      if (isOnline) {
        const data = await response.json();
        return {
          isOnline: true,
          details: {
            status: 'online',
            models: [
              { id: 'tailscale', name: 'Tailscale Control' }
            ]
          }
        };
      }
      
      return {
        isOnline: false,
        details: {
          status: 'offline',
          models: []
        }
      };
    } catch (error) {
      return {
        isOnline: false,
        details: {
          status: 'error',
          models: []
        },
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  async getModels(): Promise<any[]> {
    // Tailscale doesn't have models in the same way as LLM services
    return [];
  }

  // Tailscale API methods
  async getDevices() {
    try {
      const response = await fetch(`${this.baseUrl}/api/v2/devices`, {
        headers: {
          'Authorization': `Bearer ${this.service.apiKey}`
        }
      });
      
      if (!response.ok) {
        throw new Error(`Failed to get devices: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error getting Tailscale devices:', error);
      throw error;
    }
  }

  // Add more Tailscale API methods as needed
}

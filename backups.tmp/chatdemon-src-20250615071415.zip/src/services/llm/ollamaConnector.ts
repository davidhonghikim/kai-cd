import { LLMConnector } from './LLMConnector';
import type { Service } from '@/config/types';
import { LLMModel, ChatMessage } from "@/config/types";

// Define StreamChunk interface locally since it's not exported from types
interface StreamChunk {
  content?: string;
  isComplete: boolean;
  error?: string;
  metadata?: Record<string, any>;
}

// Ollama API returns models in this format
interface OllamaTag {
  name: string;
  model: string;
  modified_at: string;
  size: number;
  digest: string;
  details: {
    format: string;
    family: string;
    families: string[] | null;
    parameter_size: string;
    quantization_level: string;
  };
}

export class OllamaConnector extends LLMConnector {
  protected defaultHeaders: Record<string, string>;
  
  constructor(service: Service) {
    super(service);
    this.defaultHeaders = this.getDefaultHeaders();
  }
  
  // Get the default headers for API requests
  protected getDefaultHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (this.service.apiKey) {
      headers['Authorization'] = `Bearer ${this.service.apiKey}`;
    }

    return headers;
  }
  
  // Get the service category
  public getCategory(): string {
    return 'llm';
  }
  
  // Connect to the service
  public async connect(): Promise<boolean> {
    try {
      await this.checkConnection();
      this._isConnected = true;
      return true;
    } catch (error) {
      console.error('Failed to connect to Ollama service:', error);
      this._isConnected = false;
      return false;
    }
  }

  // Disconnect from the service
  public async disconnect(): Promise<void> {
    this.cancelStream();
    this._isConnected = false;
  }

  // Check if the service is connected
  public isConnected(): boolean {
    return this._isConnected;
  }

  private async checkConnection(): Promise<boolean> {
    try {
      const response = await fetch(this.service.url, {
        method: 'HEAD',
        mode: 'cors',
      });
      // Check version endpoint for a more reliable connection check
      const versionResponse = await fetch(`${this.service.url}/api/version`);
      return versionResponse.ok;
    } catch (error) {
      console.error(`Ollama connection check failed for ${this.service.name}:`, error);
      throw error; // Re-throw to be handled by connect()
    }
  }

  // Check the status of the Ollama service
  public async checkStatus() {
    try {
      const models = await this.getModels();
      // Return the service with updated models
      return {
        isOnline: true,
        details: {
          ...this.service,
          models: models,
          modelCount: models.length
        }
      };
    } catch (error) {
      return {
        isOnline: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        details: undefined
      };
    }
  }

  // Get list of available models
  public async getModels(): Promise<LLMModel[]> {
    try {
      const response = await this.fetch<{ models: OllamaTag[] }>(
        `${this.service.url}/api/tags`,
        { method: 'GET' }
      );
      
      if (!response.data) {
        throw new Error(response.error || 'Failed to fetch models');
      }
      
      return response.data.models.map(model => ({
        id: model.name,
        name: model.name, // Use model ID as name for consistency
        description: `${model.details.family || 'Unknown'} (${model.details.parameter_size})`,
        contextWindow: this.estimateContextWindow(model.details.parameter_size),
        parameters: this.estimateParameters(model.details.parameter_size),
        supportsChat: true,
        supportsCompletion: true,
        supportsEmbedding: false, // Ollama doesn't support embeddings by default
        createdAt: new Date(model.modified_at).getTime(),
      }));
    } catch (error) {
      console.error(`Ollama getModels failed:`, error);
      throw error;
    }
  }
  
  // Estimate context window based on model parameters
  private estimateContextWindow(parameterSize: string): number {
    // This is a rough estimate based on common model families
    if (parameterSize.includes('70b')) return 8192;
    if (parameterSize.includes('34b')) return 8192;
    if (parameterSize.includes('13b')) return 4096;
    if (parameterSize.includes('7b')) return 4096;
    // Default to a reasonable value
    return 2048;
  }
  
  // Estimate number of parameters based on model size
  private estimateParameters(parameterSize: string): number | undefined {
    // This is a rough estimate based on the parameter size string
    if (parameterSize.includes('70b')) return 70 * 1e9;
    if (parameterSize.includes('34b')) return 34 * 1e9;
    if (parameterSize.includes('13b')) return 13 * 1e9;
    if (parameterSize.includes('7b')) return 7 * 1e9;
    return undefined;
  }

  // Send a chat message and get a response
  public async chat(
    messages: Array<{
      role: 'user' | 'assistant' | 'system' | 'function';
      content: string;
      name?: string;
      function_call?: {
        name: string;
        arguments: string;
      };
    }>,
    model: string,
    options: {
      temperature?: number;
      maxTokens?: number;
      topP?: number;
      frequencyPenalty?: number;
      presencePenalty?: number;
      stop?: string[];
      stream?: boolean;
      onChunk?: (chunk: StreamChunk) => void;
    } = {}
  ): Promise<ChatMessage> {
    const url = new URL('/api/chat', this.service.url).toString();
    const {
      temperature = 0.7,
      maxTokens = 2048,
      topP = 1.0,
      stream = false,
      onChunk,
    } = options;

    // If streaming is requested, handle the streaming response
    if (stream && onChunk) {
      return this.streamChatResponse(
        messages,
        model,
        {
          temperature,
          max_tokens: maxTokens,
          top_p: topP,
        },
        onChunk
      );
    }

    // Standard non-streaming request
    const response = await this.fetch<any>(url, {
      method: 'POST',
      headers: this.defaultHeaders,
      body: JSON.stringify({
        model,
        messages,
        options: {
          temperature,
          top_p: topP,
          num_predict: maxTokens,
        },
      }),
    });

    if (!response.data) {
      throw new Error(response.error || 'Failed to get chat completion');
    }

    const choice = response.data.message;
    if (!choice) {
      throw new Error('No response from model');
    }

    return {
      id: `msg_${Date.now()}`,
      role: 'assistant',
      content: choice.content,
      timestamp: Date.now(),
    };
  }

  private async streamChatResponse(
    messages: Array<{
      role: 'user' | 'assistant' | 'system' | 'function';
      content: string;
      name?: string;
      function_call?: {
        name: string;
        arguments: string;
      };
    }>,
    model: string,
    options: {
      temperature?: number;
      max_tokens?: number;
      top_p?: number;
    },
    onChunk?: (chunk: StreamChunk) => void
  ): Promise<ChatMessage> {
    const url = new URL('/api/chat', this.service.url).toString();
    this.abortController = new AbortController();
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...this.defaultHeaders,
        },
        body: JSON.stringify({
          model,
          messages,
          options,
          stream: true,
        }),
        signal: this.abortController.signal,
      });

      if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`API error: ${response.status} ${response.statusText}\n${errorBody}`);
      }

      if (!response.body) {
        throw new Error('No response body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let content = '';
      let isComplete = false;

      try {
        while (!isComplete) {
          const { done, value } = await reader.read();
          
          if (done) {
            isComplete = true;
            if (onChunk) {
              onChunk({ isComplete: true });
            }
            break;
          }

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n').filter(line => line.trim() !== '');

          for (const line of lines) {
            if (line === 'data: [DONE]') {
              isComplete = true;
              if (onChunk) {
                onChunk({ isComplete: true });
              }
              continue;
            }


            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.slice(6)); // Remove 'data: ' prefix
                
                if (data.message?.content) {
                  const chunkContent = data.message.content;
                  content += chunkContent;
                  
                  if (onChunk) {
                    onChunk({
                      content: chunkContent,
                      isComplete: false,
                      metadata: {
                        ...data,
                        choices: undefined, // Remove large data
                      },
                    });
                  }
                }
                
                // Check if this is the final chunk
                if (data.done) {
                  isComplete = true;
                  if (onChunk) {
                    onChunk({ isComplete: true });
                  }
                }
              } catch (error) {
                console.error('Error parsing stream chunk:', error);
                if (onChunk) {
                  onChunk({
                    isComplete: true,
                    error: error instanceof Error ? error.message : 'Error parsing stream',
                  });
                }
                throw error;
              }
            }
          }
        }
      } finally {
        reader.releaseLock();
      }

      return {
        id: `msg_${Date.now()}`,
        role: 'assistant',
        content,
        timestamp: Date.now(),
      };
    } finally {
      this.abortController = null;
    }
  }

  // Cancel the current streaming request
  public cancelStream(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }
  
  // Generate embeddings for a list of texts
  public async embed(
    texts: string[],
    model: string = 'llama2' // Default to llama2 if no specific model is provided
  ): Promise<number[][]> {
    throw new Error('Embeddings are not supported by Ollama');
  }
  
  // Tokenize text
  public async tokenize(text: string, model: string): Promise<number[]> {
    throw new Error('Tokenization is not directly supported by Ollama');
  }
  
  // Detokenize tokens back to text
  public async detokenize(tokens: number[], model: string): Promise<string> {
    throw new Error('Detokenization is not directly supported by Ollama');
  }
  
  // Count tokens in a message or text
  public async countTokens(
    input: string | { role: string; content: string; name?: string } | Array<{ role: string; content: string; name?: string }>,
    model: string
  ): Promise<number> {
    // Fall back to the base class implementation
    return super.countTokens(typeof input === 'string' ? input : JSON.stringify(input), model);
  }
  
  // Get the context window size for a model
  public async getContextSize(model: string): Promise<number> {
    // Try to get the context size from the model info
    try {
      const modelInfo = await this.getModel(model);
      if (modelInfo?.contextWindow) {
        return modelInfo.contextWindow;
      }
    } catch (error) {
      console.warn('Failed to get model info, using default context size', error);
    }

    // Default context size if model info is not available
    return 2048; // Default context size for most models
  }
} 
import {
  Service,
  ImageGenConnector,
  ImageModel,
  ImageGenSampler,
  ImageGenOptions,
  ImageArtifact,
} from '@/config/types';

export class A1111Connector implements ImageGenConnector {
  public readonly service: Service;
  public readonly id: string;

  constructor(service: Service) {
    this.service = service;
    this.id = service.id;
  }

  private getApiUrl(endpoint: string): string {
    const url = new URL(this.service.url);
    return `${url.protocol}//${url.host}${endpoint}`;
  }

  async connect(): Promise<boolean> {
    const { isOnline } = await this.checkStatus();
    return isOnline;
  }

  async disconnect(): Promise<void> {
    return Promise.resolve();
  }

  isConnected(): boolean {
    return true; // Placeholder
  }

  async checkStatus(): Promise<{ isOnline: boolean; details: any }> {
    try {
      const response = await fetch(this.getApiUrl('/sdapi/v1/progress'));
      if (!response.ok) {
        throw new Error(`A1111 check failed: ${response.statusText}`);
      }
      const models = await this.getModels();
      return { isOnline: true, details: { modelCount: models.length } };
    } catch (error) {
      return { isOnline: false, details: { error: (error as Error).message } };
    }
  }

  getDisplayName(): string {
    return this.service.name;
  }

  getType(): string {
    return this.service.type;
  }

  getCategory(): string {
    return this.service.category;
  }

  getMetadata(): Record<string, any> {
    return {};
  }

  async updateService(service: Partial<Service>): Promise<void> {
    Object.assign(this.service, service);
  }

  async validateConfig(): Promise<{ isValid: boolean; errors?: string[] }> {
    if (!this.service.url) {
      return { isValid: false, errors: ['Service URL is missing'] };
    }
    return { isValid: true };
  }

  async getModels(): Promise<ImageModel[]> {
    const res = await fetch(this.getApiUrl('/sdapi/v1/sd-models'));
    if (!res.ok) throw new Error('Failed to fetch A1111 models.');
    const models = await res.json();
    return models.map((model: any) => ({ 
      id: model.title,
      name: model.model_name,
      filename: model.filename,
      hash: model.hash,
    }));
  }

  async getSamplers(): Promise<ImageGenSampler[]> {
    const res = await fetch(this.getApiUrl('/sdapi/v1/samplers'));
    if (!res.ok) throw new Error('Failed to fetch A1111 samplers.');
    return await res.json();
  }

  async getLoras(): Promise<ImageModel[]> {
    const res = await fetch(this.getApiUrl('/sdapi/v1/loras'));
    if (!res.ok) throw new Error('Failed to fetch A1111 loras.');
    const loras = await res.json();
    return loras.map((lora: any) => ({ id: lora.name, name: lora.name, filename: lora.path }));
  }

  async getEmbeddings(): Promise<ImageModel[]> {
    const res = await fetch(this.getApiUrl('/sdapi/v1/embeddings'));
    if (!res.ok) throw new Error('Failed to fetch A1111 embeddings.');
    const embeddings = await res.json();
    return Object.keys(embeddings.loaded).map(name => ({ id: name, name, filename: '' }));
  }

  async generateImage(prompt: string, options?: ImageGenOptions): Promise<Partial<ImageArtifact>> {
    const payload: any = {
      prompt: prompt,
      negative_prompt: options?.negativePrompt || '',
      seed: options?.seed || -1,
      steps: options?.steps || 20,
      width: options?.width || 512,
      height: options?.height || 512,
      cfg_scale: options?.cfgScale || 7,
      sampler_name: options?.sampler || 'Euler a',
    };

    if (options?.model) {
        payload.override_settings = {
            sd_model_checkpoint: options.model,
        };
    }

    const res = await fetch(this.getApiUrl('/sdapi/v1/txt2img'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`A1111 image generation failed: ${errorText}`);
    }

    const data = await res.json();
    if (data.images && data.images.length > 0) {
      return {
        imageUrl: `data:image/png;base64,${data.images[0]}`,
        prompt,
        ...options
      };
    }

    throw new Error('No image was generated.');
  }
}
import React from 'react';
import type { Service, ServiceType } from '@/config/types';
import A1111View from '@/views/A1111View';
import ComfyUIView from '@/views/ComfyUIView';
import ChatView from '@/views/ChatView';
import styles from '@/styles/components/ViewRouter.module.css';

const llmServiceTypes: ServiceType[] = ['ollama', 'llama-cpp', 'vllm', 'llm-studio', 'openai-compatible'];
const iframeServiceTypes: ServiceType[] = ['open-webui'];
const customViewServiceTypes: ServiceType[] = ['a1111', 'comfy-ui'];

interface ViewRouterProps {
  service: Service;
}

const ViewRouter: React.FC<ViewRouterProps> = ({ service }) => {
  if (customViewServiceTypes.includes(service.type)) {
    if (service.type === 'a1111') return <A1111View service={service} />;
    if (service.type === 'comfy-ui') return <ComfyUIView service={service} />;
  }

  if (iframeServiceTypes.includes(service.type)) {
    return (
      <div className={styles.iframeContainer}>
        <header className={styles.header}>
          <h1>{service.name}</h1>
        </header>
        <iframe src={service.url} title={service.name} className={styles.iframe} />
      </div>
    );
  }

  if (llmServiceTypes.includes(service.type)) {
    return <ChatView service={service} />;
  }

  return (
    <div className={styles.placeholder}>
      <h2>Unsupported Service</h2>
      <p>Service '{service.name}' of type '{service.type}' cannot be displayed in the panel.</p>
    </div>
  );
};

export default ViewRouter;

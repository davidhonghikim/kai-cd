import React from 'react';
import { Theme, themes, applyTheme } from '../../../config/theme';
import styles from '../../../styles/components/settings/UISettingsSection.module.css';

export const UISettingsSection: React.FC = () => {
  const [currentTheme, setCurrentTheme] = React.useState<Theme>(
    (localStorage.getItem('theme') as Theme) || 'system'
  );

  const handleThemeChange = (theme: Theme) => {
    setCurrentTheme(theme);
    applyTheme(theme);
  };

  return (
    <div className={styles.section}>
      <h2 className={styles.sectionTitle}>UI Settings</h2>
      
      <div className={styles.settingGroup}>
        <label className={styles.settingLabel}>Theme</label>
        <div className={styles.themeSelector}>
          {themes.map((theme) => (
            <button
              key={theme}
              className={`${styles.themeButton} ${currentTheme === theme ? styles.active : ''}`}
              onClick={() => handleThemeChange(theme)}
            >
              {theme.charAt(0).toUpperCase() + theme.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className={styles.settingGroup}>
        <label className={styles.settingLabel}>Font Size</label>
        <select
          className={styles.select}
          value={document.documentElement.style.fontSize || '17px'}
          onChange={(e) => {
            document.documentElement.style.fontSize = e.target.value;
            localStorage.setItem('fontSize', e.target.value);
          }}
        >
          <option value="14px">Small</option>
          <option value="17px">Medium</option>
          <option value="20px">Large</option>
        </select>
      </div>

      <div className={styles.settingGroup}>
        <label className={styles.settingLabel}>Animation Speed</label>
        <select
          className={styles.select}
          value={document.documentElement.style.getPropertyValue('--transition') || 'all 0.2s ease-in-out'}
          onChange={(e) => {
            document.documentElement.style.setProperty('--transition', e.target.value);
            localStorage.setItem('animationSpeed', e.target.value);
          }}
        >
          <option value="all 0.1s ease-in-out">Fast</option>
          <option value="all 0.2s ease-in-out">Normal</option>
          <option value="all 0.3s ease-in-out">Slow</option>
        </select>
      </div>
    </div>
  );
}; 
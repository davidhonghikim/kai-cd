import React from 'react';
import ReactDOM from 'react-dom/client';
import Options from './Options';
import { initializeTheme } from '../config/theme';
import '../styles/global.css';

// Initialize theme system
initializeTheme();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Options />
  </React.StrictMode>
); 
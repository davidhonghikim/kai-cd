import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { initializeTheme } from '../config/theme';
import '../styles/global.css';

// Initialize theme system
initializeTheme();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
); 
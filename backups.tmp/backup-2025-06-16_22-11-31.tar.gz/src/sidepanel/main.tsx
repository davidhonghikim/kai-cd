import React from 'react';
import ReactDOM from 'react-dom/client';
import SidePanel from './SidePanel';
import { initializeTheme } from '../config/theme';
import '../styles/global.css';

// Initialize theme system
initializeTheme();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <SidePanel />
  </React.StrictMode>
); 
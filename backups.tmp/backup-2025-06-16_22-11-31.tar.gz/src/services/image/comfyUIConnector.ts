import {
  Service,
  ImageGenConnector,
  ImageModel,
  ImageGenOptions,
  ComfyUIWorkflow,
  ComfyUIWorkflowInput,
  ImageArtifact,
  ImageGenSampler,
} from '@/config/types';
import { v4 as uuidv4 } from 'uuid';

export class ComfyUIConnector implements ImageGenConnector {
  public readonly service: Service;
  private clientId: string;
  public readonly id: string;

  constructor(service: Service) {
    this.service = service;
    this.id = service.id;
    this.clientId = uuidv4();
  }

  private getApiUrl(endpoint: string, isWs: boolean = false): string {
    const url = new URL(this.service.url);
    const protocol = isWs ? (url.protocol === 'https:' ? 'wss:' : 'ws:') : url.protocol;
    return `${protocol}//${url.host}${endpoint}`;
  }

  async connect(): Promise<boolean> {
    const { isOnline } = await this.checkStatus();
    return isOnline;
  }

  async disconnect(): Promise<void> {
    // Stateless, no-op
    return Promise.resolve();
  }

  isConnected(): boolean {
    // Should be based on the last checkStatus result
    return true; // Placeholder
  }

  async checkStatus(): Promise<{ isOnline: boolean; details: any }> {
    try {
      const response = await fetch(this.getApiUrl('/history'));
      if (!response.ok) {
        throw new Error(`ComfyUI check failed: ${response.statusText}`);
      }
      const models = await this.getModels();
      return { isOnline: true, details: { modelCount: models.length } };
    } catch (error) {
      return { isOnline: false, details: { error: (error as Error).message } };
    }
  }

  getDisplayName(): string {
    return this.service.name;
  }

  getType(): string {
    return this.service.type;
  }

  getCategory(): string {
    return this.service.category;
  }

  getMetadata(): Record<string, any> {
    return {};
  }

  async updateService(service: Partial<Service>): Promise<void> {
    // This should ideally be handled by a central service manager
    Object.assign(this.service, service);
  }

  async validateConfig(): Promise<{ isValid: boolean; errors?: string[]; warnings?: string[] }> {
    if (!this.service.url) {
      return { isValid: false, errors: ['Service URL is missing'] };
    }
    return { isValid: true };
  }

  async getModels(): Promise<ImageModel[]> {
    const res = await fetch(this.getApiUrl('/checkpoints'));
    if (!res.ok) throw new Error('Failed to fetch ComfyUI checkpoints.');
    const checkpoints = await res.json();
    return checkpoints.map((name: string) => ({ id: name, name, filename: name }));
  }

  parseWorkflow(workflowJson: string): ComfyUIWorkflowInput[] {
    const inputs: ComfyUIWorkflowInput[] = [];
    const workflow = JSON.parse(workflowJson);
    
    for (const node of workflow.nodes) {
        if (node.type === 'CLIPTextEncode') {
            inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'text', inputName: 'Prompt', inputType: 'text' });
        }
        if (node.type === 'KSampler') {
            inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'seed', inputName: 'Seed', inputType: 'number' });
             inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'steps', inputName: 'Steps', inputType: 'number' });
              inputs.push({ nodeId: node.id, nodeTitle: node.title, inputId: 'cfg', inputName: 'CFG Scale', inputType: 'number' });
        }
    }
    return inputs;
  }
  
  async generateImage(prompt: string, options?: ImageGenOptions): Promise<Partial<ImageArtifact>> {
      throw new Error("ComfyUI requires a full workflow. Use executeWorkflow instead.");
  }

  async getSamplers(): Promise<ImageGenSampler[]> {
    // Samplers are defined within the workflow graph in ComfyUI
    return Promise.resolve([]);
  }

  async getLoras(): Promise<ImageModel[]> {
    // TODO: Implement Lora fetching if API supports it
    return Promise.resolve([]);
  }

  async getEmbeddings(): Promise<ImageModel[]> {
    // TODO: Implement Embedding fetching if API supports it
    return Promise.resolve([]);
  }

  async executeWorkflow(workflowJson: string, userInputs: Record<string, any>): Promise<string> {
    const workflow = JSON.parse(workflowJson);

    for (const node of workflow.nodes) {
        if (userInputs[node.id]) {
            for(const [inputId, value] of Object.entries(userInputs[node.id])) {
                 const widgetIndex = node.inputs.findIndex((i: any) => i.name === inputId);
                 if(widgetIndex !== -1 && node.widgets_values) {
                    node.widgets_values[widgetIndex] = value;
                 }
            }
        }
    }

    const body = {
        prompt: workflow,
        client_id: this.clientId,
    };

    const res = await fetch(this.getApiUrl('/prompt'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });

    if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`ComfyUI execution failed: ${errorText}`);
    }
    const data = await res.json();
    if (!data.prompt_id) {
        throw new Error('ComfyUI did not return a prompt ID.');
    }
    
    return this.getImageFromWebSocket(data.prompt_id);
  }

  private getImageFromWebSocket(promptId: string): Promise<string> {
    return new Promise((resolve, reject) => {
        const ws = new WebSocket(this.getApiUrl(`/ws?clientId=${this.clientId}`, true));

        ws.onopen = () => console.log('ComfyUI WebSocket connected.');
        ws.onerror = (err) => reject(new Error('ComfyUI WebSocket error.'));
        ws.onclose = () => console.log('ComfyUI WebSocket disconnected.');

        ws.onmessage = async (event) => {
            const msg = JSON.parse(event.data);
            if (msg.type === 'executed' && msg.data.node.class_type === 'SaveImage') {
                const filename = msg.data.output.images[0].filename;
                const imageUrl = this.getApiUrl(`/view?filename=${filename}&subfolder=${msg.data.output.images[0].subfolder}&type=${msg.data.output.images[0].type}`);
                
                const imageResponse = await fetch(imageUrl);
                const imageBlob = await imageResponse.blob();
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result as string);
                reader.onerror = (err) => reject(err);
                reader.readAsDataURL(imageBlob);

                ws.close();
            } else if (msg.type === 'execution_error') {
                 reject(new Error(`ComfyUI execution error: ${JSON.stringify(msg.data)}`));
                 ws.close();
            }
        };
    });
  }
} 
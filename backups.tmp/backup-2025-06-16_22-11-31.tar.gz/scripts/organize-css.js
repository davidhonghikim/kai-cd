const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Mapping of old paths to new paths
const cssFilesMap = {
  // Global styles
  'src/options/styles.css': 'src/styles/vendors/options.css',
  'src/popup/styles.css': 'src/styles/vendors/popup.css',
  'src/tab/styles.css': 'src/styles/vendors/tab.css',
  
  // Component styles
  'src/options/Options.module.css': 'src/styles/components/options/Options.module.css',
  'src/popup/AdvancedSettings.module.css': 'src/styles/components/popup/AdvancedSettings.module.css',
  'src/popup/App.module.css': 'src/styles/components/popup/App.module.css',
  'src/popup/ArtifactGallery.module.css': 'src/styles/components/popup/ArtifactGallery.module.css',
  'src/popup/HistoryViewer.module.css': 'src/styles/components/popup/HistoryViewer.module.css',
  'src/popup/Message.module.css': 'src/styles/components/popup/Message.module.css',
  'src/popup/PromptManager.module.css': 'src/styles/components/popup/PromptManager.module.css',
  'src/sidepanel/A1111View.module.css': 'src/styles/components/sidepanel/A1111View.module.css',
  'src/sidepanel/ChatMessage.module.css': 'src/styles/components/sidepanel/ChatMessage.module.css',
  'src/sidepanel/ComfyUIView.module.css': 'src/styles/components/sidepanel/ComfyUIView.module.css',
  'src/sidepanel/SidePanel.module.css': 'src/styles/components/sidepanel/SidePanel.module.css',
  'src/tab/ServiceTab.module.css': 'src/styles/components/tab/ServiceTab.module.css',
  'src/tab/Tab.module.css': 'src/styles/components/tab/Tab.module.css',
};

// Create necessary directories
Object.values(cssFilesMap).forEach(newPath => {
  const dir = path.dirname(newPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Move files to new locations
Object.entries(cssFilesMap).forEach(([oldPath, newPath]) => {
  if (fs.existsSync(oldPath)) {
    fs.renameSync(oldPath, newPath);
    console.log(`Moved ${oldPath} to ${newPath}`);
  }
});

// Function to update import paths in files
function updateImportPaths() {
  const filesToUpdate = [
    'src/options/Options.tsx',
    'src/popup/App.tsx',
    'src/sidepanel/A1111View.tsx',
    'src/sidepanel/ComfyUIView.tsx',
    'src/sidepanel/SidePanel.tsx',
    'src/tab/ServiceTab.tsx',
    // Add other files that import CSS files
  ];

  filesToUpdate.forEach(filePath => {
    if (fs.existsSync(filePath)) {
      let content = fs.readFileSync(filePath, 'utf8');
      
      // Update import paths
      Object.entries(cssFilesMap).forEach(([oldPath, newPath]) => {
        const oldImportPath = oldPath.replace('src/', '../../').replace(/\.css$/, '');
        const newImportPath = newPath.replace('src/', '../../').replace(/\.css$/, '');
        content = content.replace(
          new RegExp(importPathToRegex(oldImportPath), 'g'),
          newImportPath
        );
      });
      
      // Update global.css import
      content = content.replace(
        /'..\/style\/global\.css'/g,
        "'../../styles/global.css'"
      );
      
      fs.writeFileSync(filePath, content, 'utf8');
      console.log(`Updated import paths in ${filePath}`);
    }
  });
}

// Helper function to convert import path to regex
function importPathToRegex(path) {
  return path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Run the updates
updateImportPaths();

console.log('CSS files have been reorganized successfully!');

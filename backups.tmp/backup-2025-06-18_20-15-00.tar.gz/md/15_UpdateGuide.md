# 15_UpdateGuide.md
# ChatDemon Update Guide
**Title:** Update Guide

*(Instructions for users and developers on how to update the extension.*

*   **For Users:** Updates are delivered automatically via the browser store.
*   **For Developers:** Pull the latest changes from GitHub, rebuild the extension, and test thoroughly.
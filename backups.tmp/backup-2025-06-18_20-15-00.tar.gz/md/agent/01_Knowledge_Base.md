# Kai-CD Extension: Knowledge Base

This document provides a technical overview of the Kai-CD browser extension's architecture, key bug fixes, and current state. It is intended to serve as a knowledge base for future development.

## 1. Core Architecture

The extension is built with React, TypeScript, and Vite, and it communicates with a Chrome-compliant browser environment. The architecture is divided into several key areas:

### 1.1. Background Script (`src/background`)

-   **`main.ts`**: The entry point for the extension's background process. It initializes all services, sets up message listeners, and manages the core state.
-   **`handlers/`**: This directory contains handler functions for different message types (e.g., `chatHandlers.ts`, `serviceHandlers.ts`). These handlers contain the business logic for interacting with services, managing storage, and responding to requests from the UI.
-   **`connectors/`**: This directory contains the logic for establishing and managing connections to the various supported services (Ollama, A1111, etc.).

### 1.2. Frontend UI (`src/`)

-   **`pages/`**: Contains the top-level HTML and entry points for the different UI surfaces (popup, side panel, options, tab).
-   **`components/`**: Contains reusable React components. The most important is **`ViewRouter.tsx`**, which acts as a client-side router to display the correct UI for the active service in the correct context (tab vs. panel).
-   **`views/`**: Contains the high-level view components for each service (e.g., `ChatView.tsx`, `A1111View.tsx`). These are the components that are rendered by the `ViewRouter`.
-   **`hooks/`**: Contains custom React hooks. The most important is **`useChatSession.ts`**, which encapsulates all the logic for managing a chat session, including fetching models, sending messages, and handling streaming responses.
-   **`options/`**: Contains the components for the extension's main settings page.

### 1.3. State Management

-   **Storage:** All persistent state (services, chat history, settings) is managed via the `storageManager.ts` utility, which provides a simple key-value interface to `chrome.storage.local`.
-   **UI State:** UI state is managed within React components using `useState` and custom hooks. State is explicitly "lifted up" to parent components (e.g., in the `Options.tsx` page) to ensure a single source of truth.

## 2. Major Bug Fixes and Refactoring

The following critical bugs were identified and fixed:

### 2.1. Ollama Remote Connection Failure

-   **Problem:** The streaming connection to remote Ollama servers would fail after the initial response.
-   **Root Cause:** The data handling logic in `ollamaConnector.ts` was not correctly processing the streamed JSON response chunks.
-   **Solution:** The connector was rewritten to correctly handle the NDJSON (Newline Delimited JSON) stream format that Ollama uses, ensuring that each JSON object is parsed correctly.

### 2.2. Service Manager UI/UX Failure

-   **Problem:** The Service Manager page in the options was visually broken, and key functions like checking service status or viewing models were not working.
-   **Root Cause:** A cascade of issues stemming from flawed state management. The `ServiceListItem.tsx` component was trying to manage its own local state, which became desynchronized from the parent `Options.tsx` component. There was no code to trigger status checks or model fetching.
-   **Solution:** A complete refactoring was performed:
    1.  All state was "lifted up" to the `Options.tsx` component, making it the single source of truth.
    2.  Centralized event handlers (`handleUpdateService`, `handleCheckStatus`, `handleGetModels`) were created in `Options.tsx`.
    3.  `ServiceListItem.tsx` was rewritten as a "dumb" presentational component that receives data and handlers as props.
    4.  Buttons to trigger status checks and model refreshes were added to the UI, and a list of a service's available models is now displayed.

### 2.3. Chat Models Not Loading

-   **Problem:** The chat view would always display "No models available," even for correctly configured services.
-   **Root Cause:** The `useChatSession.ts` hook was attempting to access `response.models` from the `getModels` background handler, but the handler returns the data in the format `{ success: true, data: [...] }`.
-   **Solution:** The hook was corrected to access `response.data`, which immediately fixed the issue and allowed the list of models to be loaded and displayed.

### 2.4. Default Servers Overwriting User Settings

-   **Problem:** User-configured service URLs were being overwritten by the default "localhost" URLs every time the extension started.
-   **Root Cause:** The initialization logic in `background/main.ts` was unconditionally writing the default services to storage, overwriting any existing user data.
-   **Solution:** The logic was corrected to first check if any services already exist in storage. The default services are now only added if the storage is empty, preserving all user configurations.

This concludes the knowledge transfer. The extension is now in a stable, tested, and well-documented state. 
import React, { useState, useEffect, useCallback } from 'react';
import styles from '@/styles/components/popup/Popup.module.css';
import { Service } from '@/types';
import { sendMessage } from '@/utils/chrome';
import { connectToBackground } from '@/utils/keepAlive';
import '@/styles/global.css';
import Button from '@/components/common/Button';

const App: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activePanelServiceId, setActivePanelServiceId] = useState<string | null>(null);

  useEffect(() => {
    connectToBackground('popup');
  }, []);

  const loadServices = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await sendMessage('getServices');
      if (response.success) {
        setServices(response.services);
      } else {
        setError(response.error || 'Failed to load services.');
      }
      const activeResponse = await sendMessage('getActiveService');
      if (activeResponse.success && activeResponse.service) {
        setActivePanelServiceId(activeResponse.service.id);
      } else {
        setActivePanelServiceId(null);
      }
    } catch (e) {
      setError('An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadServices();
    // Listen for changes from other parts of the extension
    const messageListener = (message: any) => {
      if (message.action === 'activeServiceChanged' || message.action === 'servicesChanged') {
        loadServices();
      }
    };
    chrome.runtime.onMessage.addListener(messageListener);
    return () => chrome.runtime.onMessage.removeListener(messageListener);
  }, [loadServices]);

  const openOptionsPage = () => {
    sendMessage('openOptionsPage');
  };

  const handleOpenInTab = (serviceId: string) => {
    sendMessage('openInTab', { serviceId });
  };

  const handleOpenInPanel = (serviceId: string) => {
    sendMessage('openInPanel', { serviceId });
  };


  return (
    <div className={styles.appContainer}>
      <header className={styles.header}>
        <h1 className={styles.title}>ChatDemon</h1>
        <Button onClick={openOptionsPage} variant="secondary">
          Manage
        </Button>
      </header>
      <main className={styles.main}>
        {isLoading ? (
          <div>Loading services...</div>
        ) : error ? (
          <div className={styles.error}>{error}</div>
        ) : services.length === 0 ? (
          <div className={styles.noServices}>
            <p>No services configured.</p>
            <Button onClick={openOptionsPage}>Add a Service</Button>
          </div>
        ) : (
          <ul className={styles.serviceList}>
            {services.map((service) => (
              <li key={service.id} className={styles.serviceCard}>
                <span className={styles.serviceName}>{service.name}</span>
                <div className={styles.serviceActions}>
                  <Button onClick={() => handleOpenInTab(service.id)}>Tab</Button>
                  <Button
                    onClick={() => handleOpenInPanel(service.id)}
                    variant={activePanelServiceId === service.id ? 'primary' : 'secondary'}
                  >
                    Panel
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
};

export default App; 
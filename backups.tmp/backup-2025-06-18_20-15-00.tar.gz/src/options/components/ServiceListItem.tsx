import React, { useState, useRef, useEffect } from 'react';
import { SERVICE_TYPES, SERVICE_CATEGORIES } from '@/config/constants';
import type { Service, LLMModel } from '@/types';
import styles from './ServiceListItem.module.css';

interface ServiceListItemProps {
  service: Service;
  models: LLMModel[];
  onUpdate: (updatedFields: Partial<Service>) => void;
  onDelete: () => void;
  onCheckStatus: () => void;
  onGetModels: () => void;
  isSelecting?: boolean;
  isSelected?: boolean;
  onSelectionChange?: (id: string) => void;
  startExpanded?: boolean;
}

const ServiceListItem: React.FC<ServiceListItemProps> = ({ 
  service, 
  models,
  onUpdate, 
  onDelete,
  onCheckStatus,
  onGetModels,
  isSelecting = false,
  isSelected = false,
  onSelectionChange,
  startExpanded = false
}) => {
  const [isExpanded, setIsExpanded] = useState(startExpanded);
  const [isEditing, setIsEditing] = useState(startExpanded);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  const [formData, setFormData] = useState<Partial<Service>>({ ...service });
  
  useEffect(() => {
    setFormData({...service});
  }, [service]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({ ...service });
    setIsEditing(false);
  };

  const handleDelete = () => {
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    onDelete();
    setShowDeleteConfirm(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return '#28a745';
      case 'offline': return '#dc3545';
      case 'checking': return '#ffc107';
      default: return '#6c757d';
    }
  };
  
  useEffect(() => {
    if (isExpanded) {
      onGetModels();
    }
  }, [isExpanded, onGetModels]);

  return (
    <div className={styles.serviceCard}>
      {showDeleteConfirm && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <h3>Delete Service</h3>
            <p>Are you sure you want to delete "{service.name}"? This action cannot be undone.</p>
            <div className={styles.modalActions}>
              <button className={styles.dangerButton} onClick={confirmDelete}>Delete</button>
              <button className={styles.cancelButton} onClick={() => setShowDeleteConfirm(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      <div className={styles.serviceHeader}>
        <div className={styles.serviceInfo}>
          {isSelecting && (
            <input 
              type="checkbox" 
              checked={isSelected} 
              onChange={() => onSelectionChange?.(service.id)}
              className={styles.checkbox}
            />
          )}
          <div 
            className={styles.statusIndicator}
            style={{ backgroundColor: getStatusColor(service.status) }}
            onClick={onCheckStatus}
            title={`Click to re-check status (Currently: ${service.status})`}
          />
          <div className={styles.serviceDetails}>
            <h3 className={styles.serviceName}>{service.name}</h3>
            <p className={styles.serviceUrl}>{service.url}</p>
          </div>
        </div>
        <div className={styles.serviceActions}>
           <button onClick={onCheckStatus} className={styles.actionButton}>
              Check Status
            </button>
          <button onClick={() => setIsExpanded(!isExpanded)} className={styles.expandButton} title={isExpanded ? 'Collapse' : 'Expand'}>
            {isExpanded ? '▼' : '▶'}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className={styles.expandedContent}>
          {isEditing ? (
            <form className={styles.editForm}>
               <div className={styles.formGrid}>
                <div className={styles.formField}>
                  <label>Service Name</label>
                  <input type="text" name="name" value={formData.name || ''} onChange={handleInputChange} />
                </div>
                <div className={styles.formField}>
                  <label>Service URL</label>
                  <input type="url" name="url" value={formData.url || ''} onChange={handleInputChange} />
                </div>
                <div className={styles.formField}>
                  <label>Service Type</label>
                  <select name="type" value={formData.type || ''} onChange={handleInputChange}>
                    {Object.values(SERVICE_TYPES).map(type => <option key={type} value={type}>{type}</option>)}
                  </select>
                </div>
                <div className={styles.formField}>
                  <label>Category</label>
                  <select name="category" value={formData.category || ''} onChange={handleInputChange}>
                    {Object.values(SERVICE_CATEGORIES).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
                <div className={styles.formField}>
                    <label>API Key</label>
                    <input type="password" name="apiKey" value={formData.apiKey || ''} onChange={handleInputChange} />
                </div>
                 <div className={styles.formField}>
                    <label>
                      <input type="checkbox" name="requiresApiKey" checked={formData.requiresApiKey || false} onChange={handleInputChange} />
                      Requires API Key
                    </label>
                </div>
                 <div className={styles.formField}>
                    <label>
                      <input type="checkbox" name="enabled" checked={formData.enabled || false} onChange={handleInputChange} />
                      Enabled
                    </label>
                </div>
              </div>
              <div className={styles.formActions}>
                <button type="button" onClick={handleSave} className={styles.saveButton}>Save</button>
                <button type="button" onClick={handleCancel} className={styles.cancelButton}>Cancel</button>
              </div>
            </form>
          ) : (
            <div className={styles.detailsView}>
                <div className={styles.detailItem}><strong>Type:</strong> {service.type}</div>
                <div className={styles.detailItem}><strong>Category:</strong> {service.category}</div>
                <div className={styles.detailItem}><strong>Status:</strong> {service.status} ({service.statusCode || 'N/A'})</div>
                <div className={styles.detailItem}><strong>Enabled:</strong> {service.enabled ? 'Yes' : 'No'}</div>
                <div className={styles.detailItem}><strong>API Key Required:</strong> {service.requiresApiKey ? 'Yes' : 'No'}</div>

                <div className={styles.modelsSection}>
                    <h4>Available Models</h4>
                    <button onClick={onGetModels} className={styles.actionButton}>Refresh Models</button>
                    <div className={styles.modelList}>
                        {models.length > 0 ? (
                            models.map(m => <div key={m.id} className={styles.modelTag}>{m.name}</div>)
                        ) : (
                            <p>No models found. Click "Refresh Models" to load them.</p>
                        )}
                    </div>
                </div>

                <div className={styles.formActions}>
                    <button onClick={() => setIsEditing(true)} className={styles.editButton}>Edit</button>
                    <button onClick={handleDelete} className={styles.deleteButton}>Delete</button>
                </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ServiceListItem; 
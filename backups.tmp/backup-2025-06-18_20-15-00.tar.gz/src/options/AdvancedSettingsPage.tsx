import React, { useState } from 'react';
import AdvancedSettingsModal from '../components/settings/AdvancedSettingsModal';
import Button from '../components/common/Button';
import styles from '@/styles/components/options/Options.module.css';

const AdvancedSettingsPage: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className={styles.optionsContainer}>
      <h2>Advanced Settings</h2>
      <p>Manage detailed extension settings and configurations.</p>
      <Button onClick={() => setIsModalOpen(true)}>Open Settings</Button>
      <AdvancedSettingsModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
};

export default AdvancedSettingsPage; 
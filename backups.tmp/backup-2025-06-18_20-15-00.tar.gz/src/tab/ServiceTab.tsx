import React, { useEffect, useState } from 'react';
import ViewRouter from '@/components/ViewRouter';
import { sendMessage } from '@/utils/chrome';
import { Service } from '@/types';
import styles from '@/styles/components/tab/ServiceTab.module.css';
import '@/styles/global.css';
import { connectToBackground } from '@/utils/keepAlive';

const ServiceTab: React.FC = () => {
  const [service, setService] = useState<Service | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    connectToBackground('tab');
  }, []);

  useEffect(() => {
    const init = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const serviceId = params.get('serviceId');

        if (!serviceId) {
          setError("No service ID provided in the URL.");
          return;
        }

        // Set this service as the active one for this context
        const setActiveResponse = await sendMessage('setActiveService', { serviceId });
        if (!setActiveResponse.success) {
          throw new Error(setActiveResponse.error || `Failed to set active service: ${serviceId}`);
        }
        
        // Now get the full service object
        const getServiceResponse = await sendMessage('getService', { serviceId });
        if (getServiceResponse.success) {
          setService(getServiceResponse.service);
        } else {
          throw new Error(getServiceResponse.error || `Service with ID ${serviceId} not found`);
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : 'An unknown error occurred.');
      }
    };
    init();
  }, []);

  if (error) {
    return (
      <div className={styles.container}>
        <div className={styles.error}>
          <p>{error}</p>
          <button onClick={() => window.location.reload()}>Retry</button>
        </div>
      </div>
    );
  }

  if (!service) {
    return (
      <div className={styles.container}>
        <div className={styles.error}>
          <p>No service selected</p>
          <button onClick={() => window.location.href = chrome.runtime.getURL('src/popup/index.html')}>
            Open Popup
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <ViewRouter service={service} isTab={true} />
    </div>
  );
};

export default ServiceTab; 
import { SERVERS_KEY } from '@/utils/settingsIO';
import { DEFAULT_SERVICES } from '@/config/defaults';
import { Service } from '@/types';

// Mock storageManager at the top level
const mockStorageManager = {
  get: jest.fn(),
  set: jest.fn(),
};
jest.mock('@/storage/storageManager', () => ({
  storageManager: mockStorageManager,
}));

// Mock chrome APIs
const mockChrome = {
  runtime: {
    onInstalled: { addListener: jest.fn() },
    onStartup: { addListener: jest.fn() },
    onConnect: { addListener: jest.fn((cb) => cb({ name: 'test' })) },
    onMessage: { addListener: jest.fn() },
  },
  storage: {
    local: {
      get: jest.fn(),
      set: jest.fn(),
    },
  },
};
global.chrome = mockChrome as any;

describe('Background Script Initialization', () => {
  beforeEach(() => {
    // Reset mocks and modules before each test to ensure isolation
    jest.clearAllMocks();
    jest.resetModules();
  });

  it('should initialize default services if none exist on install', async () => {
    // Arrange: Simulate no existing services
    mockStorageManager.get.mockResolvedValue([]);

    // Act: Isolate the module import to control execution
    await jest.isolateModules(async () => {
      require('../main');
      // The top-level call in main.ts already ran. We can also trigger the listener to be thorough.
      const onInstalledCallback = mockChrome.runtime.onInstalled.addListener.mock.calls[0][0];
      await onInstalledCallback({ reason: 'install' });
    });

    // Assert that it was called, we expect 2 calls in test (top-level + listener)
    // but in a real scenario, only one of these would typically run on a fresh install.
    expect(mockStorageManager.set).toHaveBeenCalled();
    expect(mockStorageManager.set).toHaveBeenCalledWith(SERVERS_KEY, expect.any(Array));
    const savedServices = mockStorageManager.set.mock.calls[0][1];
    const ollamaService = savedServices.find((s: Service) => s.id.includes('ollama'));
    expect(ollamaService.url).toContain('192.168.1.159');
  });

  it('should NOT initialize default services if they already exist', async () => {
    // Arrange: Simulate existing services
    mockStorageManager.get.mockResolvedValue(DEFAULT_SERVICES);

    // Act
    await jest.isolateModules(async () => {
      require('../main');
      const onInstalledCallback = mockChrome.runtime.onInstalled.addListener.mock.calls[0][0];
      await onInstalledCallback({ reason: 'install' });
    });

    // Assert
    expect(mockStorageManager.set).not.toHaveBeenCalled();
  });
}); 
import { serviceHandlers } from './serviceHandlers';
import { chatHandlers } from './chatHandlers';
import { imageHandlers } from './imageHandlers';
import { promptHandlers } from './promptHandlers';
import { panelHandlers } from './panelHandlers';

/**
 * A registry of all available background request handlers.
 * This pattern allows for easy addition of new handlers and avoids circular dependencies.
 */
export const handlers = {
  ...serviceHandlers,
  ...chatHandlers,
  ...imageHandlers,
  ...promptHandlers,
  ...panelHandlers,
};

export type Action = keyof typeof handlers;

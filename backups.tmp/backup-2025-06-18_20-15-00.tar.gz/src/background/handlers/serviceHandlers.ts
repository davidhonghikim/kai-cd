/* global console */
import type { Service, LLMModel } from '@/types';
import { SERVICE_TYPES } from '@/config/constants';
import { RequestHandler } from './types';
import { connectorManager } from '../connectors';
import { storageManager } from '../../storage/storageManager';
import { SERVICE_TYPE_TO_CATEGORY, HEALTH_CHECK_PATHS } from '../../config/constants';
import { SERVERS_KEY } from '../../utils/settingsIO';
import { getStoredServices } from '../utils/storage';

// @ts-ignore
// Temporarily use 'any' for service types to get a build
type ServiceAny = any;

// Message handler for getServices
export const getServices: RequestHandler<undefined, { success: boolean; services: Service[]; error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    console.log('Getting services...');
    const services = await getStoredServices();
    console.log('Retrieved services:', services);
    sendResponse({ success: true, services: services || [] });
    return true;
  } catch (error) {
    console.error('Error getting services:', error);
    try {
      sendResponse({ success: false, services: [], error: 'Failed to get services' });
    } catch (e) {
      console.error('sendResponse failed:', e);
    }
    return true;
  }
};

export const addService: RequestHandler<Partial<Service>, { success: boolean; data?: Service; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
//     const services = await getStoredServices();
    const serviceType = payload.type || SERVICE_TYPES.OLLAMA;
    const newService: Service = {
      id: `srv_${Date.now()}`,
      name: payload.name || 'New Service',
      type: serviceType,
      url: payload.url || '',
      apiKey: payload.apiKey,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isActive: payload.isActive ?? false,
      status: 'inactive',
      category: SERVICE_TYPE_TO_CATEGORY[serviceType],
      requiresApiKey: false,
      enabled: true
    };

    // const updatedServices = [...services, newService]; // Not saving until user clicks save
//     await storageManager.set(SERVERS_KEY, updatedServices);
    sendResponse({ success: true, data: newService });
  } catch (error) {
    console.error('Error adding service:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Failed to add service' });
  }
  return true;
};

export async function updateService(payload: Service): Promise<Service> {
  const services = await getStoredServices();
  const index = services.findIndex((s) => s.id === payload.id);

  if (index === -1) {
    throw new Error('Service not found');
  }

  const updatedService = {
    ...services[index],
    ...payload,
    updatedAt: Date.now()
  };

  const updatedServices = [...services];
  updatedServices[index] = updatedService;

  // Get the connector and update it
  const connector = await connectorManager.getConnector(updatedService);
  if (connector) {
    await connector.updateService(updatedService);
  }

  await storageManager.set(SERVERS_KEY, updatedServices);
  return updatedService;
}

export const removeService: RequestHandler<{ id: string }, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const updatedServices = services.filter(s => s.id !== payload.id);

    connectorManager.removeConnector(payload.id);
    await storageManager.set(SERVERS_KEY, updatedServices);
    sendResponse({ success: true });
  } catch (error) {
    console.error('Error removing service:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Failed to remove service' });
  }
  return true;
};

export const setDefaultModel: RequestHandler<{ serviceId: string; modelId: string }, { success: boolean; service?: Service; error?: string }> = async (payload, _sender, sendResponse) => {
  const { serviceId, modelId } = payload;
  const services = await getStoredServices();
  const index = services.findIndex((s) => s.id === serviceId);

  if (index === -1) {
    throw new Error(`Service not found with id: ${serviceId}`);
  }

  const updatedService: Service = {
    ...services[index],
    model: modelId,
    updatedAt: Date.now(),
  };

  const updatedServices = [...services];
  updatedServices[index] = updatedService;

  await storageManager.set(SERVERS_KEY, updatedServices);
  sendResponse({ success: true, service: updatedService });
  return true;
}

/**
 * Checks if a service is online and reachable.
 * It uses a fetch request with a timeout to prevent long hangs.
 * It will also check for a valid response (e.g., 200 OK).
 */
export async function checkStatus(payload: { serviceId: string }): Promise<{
  status: 'online' | 'offline' | 'error';
  message?: string;
  statusCode?: number;
}> {
  const services = await getStoredServices();
  const service = services.find((s) => s.id === payload.serviceId);

  if (!service || !service.url) {
    return { status: 'error', message: `Service not found or has no URL.` };
  }
  
  const healthCheckPath = HEALTH_CHECK_PATHS[service.type] || '';
  const healthCheckUrl = new URL(healthCheckPath, service.url).toString();

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000); // 5-second timeout

  try {
    const response = await fetch(healthCheckUrl, {
      method: 'GET', // Use GET for broader compatibility, HEAD is not always supported.
      signal: controller.signal,
      mode: 'cors',
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      return { status: 'online', statusCode: response.status };
    } else {
      return {
        status: 'offline',
        message: `Service returned non-OK status: ${response.status}`,
        statusCode: response.status,
      };
    }
  } catch (error) {
    clearTimeout(timeoutId);
    if (error instanceof Error && error.name === 'AbortError') {
      return { status: 'offline', message: 'Connection timed out after 5 seconds.' };
    }
    return { status: 'offline', message: 'Failed to connect. The server may be offline or unreachable.' };
  }
}

export const getModels: RequestHandler<{ serviceId: string }, { success: boolean; models: LLMModel[]; error?: string }> = async (payload, _sender, sendResponse) => {
  const { serviceId } = payload;
  if (!serviceId) {
    sendResponse({ success: false, models: [], error: 'Service ID is required to fetch models.' });
    return true;
  }

  try {
    console.log(`Fetching models for service ID: ${serviceId}`);
    const services = await getStoredServices();
    const service = services.find(s => s.id === serviceId);

    if (!service) {
      sendResponse({ success: false, models: [], error: `Service with ID "${serviceId}" not found.` });
      return true;
    }

    console.log(`Found service: ${service.name}, type: ${service.type}, URL: ${service.url}`);
    let models: LLMModel[] = [];

    if (service.type === SERVICE_TYPES.OLLAMA) {
      try {
        // First try Ollama's direct API
        const url = new URL('/api/tags', service.url).toString();
        console.log(`Fetching models from: ${url}`);
        const response = await fetch(url);
        
        if (response.ok) {
          const data = await response.json();
          console.log(`Received models data:`, data);
          
          if (data.models && Array.isArray(data.models)) {
            models = data.models.map((model: { name: string; [key: string]: any }) => ({
              id: model.name,
              name: model.name,
              details: model,
            }));
            console.log(`Parsed ${models.length} models from Ollama API`);
          } else {
            console.warn('Unexpected response format from Ollama API:', data);
            // Try fallback to Open WebUI's API
            throw new Error('Invalid response format');
          }
        } else {
          throw new Error(`Failed with status: ${response.status}`);
        }
      } catch (ollamaError) {
        console.warn(`Failed to fetch models from Ollama API: ${ollamaError}. Trying Open WebUI API...`);
        
        // Fallback to Open WebUI's API
        try {
          const webUIUrl = new URL('/api/models', service.url).toString();
          console.log(`Fetching models from Open WebUI API: ${webUIUrl}`);
          const webUIResponse = await fetch(webUIUrl);
          
          if (webUIResponse.ok) {
            const webUIData = await webUIResponse.json();
            console.log(`Received models data from Open WebUI:`, webUIData);
            
            if (Array.isArray(webUIData)) {
              models = webUIData.map((model: string) => ({
                id: model,
                name: model,
                details: { name: model },
              }));
              console.log(`Parsed ${models.length} models from Open WebUI API`);
            } else {
              console.warn('Unexpected response format from Open WebUI API:', webUIData);
            }
          } else {
            throw new Error(`Failed with status: ${webUIResponse.status}`);
          }
        } catch (webUIError) {
          console.error(`Failed to fetch models from Open WebUI API: ${webUIError}`);
          // If both methods fail, return a default model so the UI doesn't break
          models = [{ id: 'llama2', name: 'llama2', details: { name: 'llama2' } }];
          console.log('Using default model as fallback');
        }
      }
    } else if (service.type === SERVICE_TYPES.OPENAI_COMPATIBLE) {
      // OpenAI-compatible endpoint for models
      const url = new URL('/v1/models', service.url).toString();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (service.apiKey) headers['Authorization'] = `Bearer ${service.apiKey}`;
      
      console.log(`Fetching OpenAI-compatible models from: ${url}`);
      const response = await fetch(url, { headers });
      
      if (!response.ok) {
        throw new Error(`Failed to fetch models from ${service.name}. Status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log(`Received OpenAI models data:`, data);
      
      if (data.data && Array.isArray(data.data)) {
        models = data.data.map((model: { id: string; [key: string]: any }) => ({
          id: model.id,
          name: model.id,
          details: model,
        }));
        console.log(`Parsed ${models.length} OpenAI models`);
      } else {
        console.warn('Unexpected response format from OpenAI API:', data);
        models = [{ id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', details: {} }];
      }
    } else if (service.type === SERVICE_TYPES.OPEN_WEBUI) {
      // Open WebUI: return a default model (UI is in iframe)
      models = [{ id: 'open-webui', name: 'Open WebUI', details: {} }];
      console.log('Using default model for Open WebUI');
    } else {
      console.warn(`Model fetching not supported for service type: ${service.type}`);
      models = [];
    }

    console.log(`Returning ${models.length} models for ${service.name}`);
    sendResponse({ success: true, models });
  } catch (error) {
    console.error(`Error fetching models:`, error);
    sendResponse({ 
      success: false, 
      models: [], 
      error: error instanceof Error ? error.message : 'Unknown error fetching models' 
    });
  }
  return true;
};

/**
 * Exports selected services to a JSON file.
 */
export const exportServices: RequestHandler<{ serviceIds: string[] }, { success: boolean; data?: string; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceIds } = payload;
    const services = await getStoredServices();
    const servicesToExport = services.filter(service => serviceIds.includes(service.id));
    const data = JSON.stringify(servicesToExport, null, 2);
    sendResponse({ success: true, data });
  } catch (error) {
    console.error('Error exporting services:', error);
    sendResponse({ success: false, error: 'Failed to export services' });
  }
};

/**
 * Imports services from a JSON file.
 */
export const importServices: RequestHandler<{ services: Service[] }, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { services } = payload;
    const existingServices = await getStoredServices();
    const updatedServices = [...existingServices, ...services];
    await storageManager.set(SERVERS_KEY, updatedServices);
  } catch (error) {
    console.error('Error importing services:', error);
    sendResponse({ success: false, error: 'Failed to import services' });
  }
};

/**
 * Updates the order of services in storage.
 */
export const updateServicesOrder: RequestHandler<{ orderedIds: string[] }, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { orderedIds } = payload;
    const services = await getStoredServices();
    const orderedServices = orderedIds.map(id => services.find(s => s.id === id)).filter(Boolean) as Service[];
    await storageManager.set(SERVERS_KEY, orderedServices);
  } catch (error) {
    console.error('Error updating services order:', error);
    sendResponse({ success: false, error: 'Failed to update services order' });
  }
};

/**
 * Gets the currently active service.
 */
export const getActiveService: RequestHandler = async (_payload, _sender, sendResponse) => {
  try {
    const services = await getStoredServices();
    const activeService = services.find(s => s.isActive);
    sendResponse({ success: true, service: activeService || null });
  } catch (error) {
    console.error('Error getting active service:', error);
    sendResponse({ success: false, error: 'Failed to get active service' });
  }
};

export const initializeServices: RequestHandler<undefined, { success: boolean; services: Service[]; error?: string }> = async (_payload, _sender, sendResponse) => {
  try {
    console.log('Manual service initialization requested...');
    const services = await getStoredServices();
    sendResponse({ success: true, services });
    return true;
  } catch (error) {
    console.error('Error initializing services:', error);
    sendResponse({ success: false, services: [], error: 'Failed to initialize services' });
    return true;
  }
};

export const getService: RequestHandler<{ serviceId: string }, { success: boolean; service?: Service; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    const services = await storageManager.get<Service[]>(SERVERS_KEY, []);
    const service = services.find(s => s.id === serviceId);
    if (service) {
      sendResponse({ success: true, service });
    } else {
      sendResponse({ success: false, error: `Service with id ${serviceId} not found.` });
    }
  } catch (error) {
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
  return true;
};

export const serviceHandlers = {
  getServices,
  addService,
  updateService,
  removeService,
  checkStatus,
  getModels,
  exportServices,
  importServices,
  updateServicesOrder,
  getActiveService,
  setDefaultModel,
  initializeServices,
  getService
};

export default serviceHandlers;


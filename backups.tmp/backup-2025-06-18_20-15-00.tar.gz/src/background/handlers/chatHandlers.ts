/* global console */
import { RequestHandler } from './types';
import { getStoredServices } from '../utils/storage';
import { serviceFactory } from '@/services/ServiceFactory';
import type { Service, ChatSession, LLMModel, ChatConnector, ChatMessage } from '@/types';
import { SERVICE_TYPES } from '@/config/constants';

function isChatConnector(connector: any): connector is ChatConnector {
  return typeof connector?.sendMessage === 'function' && 
         typeof connector?.chat === 'function' &&
         typeof connector?.getModels === 'function' &&
         typeof connector?.clearHistory === 'function' &&
         typeof connector?.getHistory === 'function';
}

async function getService(serviceId: string): Promise<Service | undefined> {
  const services = await getStoredServices();
  return services.find(s => s.id === serviceId);
}

async function getConnector(service: Service): Promise<ChatConnector> {
  try {
    // For UI-based services like Open WebUI, A1111, and ComfyUI, create a special connector
    // that provides minimal functionality since these services are primarily used via iframe
    if (
      service.type === SERVICE_TYPES.OPEN_WEBUI ||
      service.type === SERVICE_TYPES.A1111 ||
      service.type === SERVICE_TYPES.COMFY_UI
    ) {
      console.log(`Creating UI-based connector for ${service.type} service: ${service.name}`);
      const connector = await serviceFactory.getConnector(service);
      
      if (!connector) {
        throw new Error(`Failed to create connector for ${service.name}`);
      }
      
      if (isChatConnector(connector)) {
        return connector;
      }
      
      // If it's not a chat connector, create a minimal wrapper
      console.log(`Creating minimal chat connector wrapper for ${service.name}`);
      const chatConnector: ChatConnector = {
        sendMessage: async (message: string): Promise<ChatMessage> => {
          console.log(`[UI Service] Sending message to ${service.name}: ${message}`);
          return {
            id: Date.now().toString(),
            role: 'assistant',
            content: `Please use the ${service.name} interface directly.`,
            timestamp: Date.now()
          };
        },
        chat: async (messages: ChatMessage[], model: string): Promise<ChatMessage> => {
          console.log(`[UI Service] Chat with ${service.name}: ${messages.length} messages, model: ${model}`);
          return {
            id: Date.now().toString(),
            role: 'assistant',
            content: `Please use the ${service.name} interface directly.`,
            timestamp: Date.now()
          };
        },
        getModels: async (): Promise<LLMModel[]> => {
          console.log(`[UI Service] Getting models for ${service.name}`);
          return [{
            id: `${service.type.toLowerCase()}-default`,
            name: `${service.name} Default`,
            details: { type: service.type }
          }];
        },
        clearHistory: async (): Promise<void> => {
          console.log(`[UI Service] Clearing history for ${service.name}`);
        },
        getHistory: async (): Promise<ChatSession[]> => {
          console.log(`[UI Service] Getting history for ${service.name}`);
          return [];
        }
      };
      return chatConnector;
    }
    
    // For regular LLM services
    const connector = await serviceFactory.getConnector(service);
    if (!connector || !isChatConnector(connector)) {
      throw new Error(`No chat connector found for service ${service.id}`);
    }
    return connector;
  } catch (error) {
    console.error(`Error getting connector for ${service.name}:`, error);
    throw error;
  }
}

/**
 * Send a chat message and handle the conversation history (session-based)
 */
export const sendMessage: RequestHandler<{ serviceId: string; messages: ChatMessage[]; model: string; options?: any }, { success: boolean; data?: ChatMessage[]; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId, messages, model, options } = payload;
    console.log('[ChatHandler] sendMessage called with:', { serviceId, model, messageCount: messages.length, options });
    
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }

    const connector = await getConnector(service);
    
    console.log('[ChatHandler] Calling connector.chat with full message history:', { 
      messageCount: messages.length, 
      model, 
      serviceType: service.type,
      options
    });
    
    // Call the chat method with the full message history
    const response = await connector.chat(messages, model, options);
    
    console.log('[ChatHandler] Connector response type:', typeof response);
    console.log('[ChatHandler] Connector response:', response);
    console.log('[ChatHandler] Response content type:', typeof response.content);
    console.log('[ChatHandler] Response content (first 200 chars):', response.content?.substring(0, 200));
    console.log('[ChatHandler] Response content length:', response.content?.length);
    console.log('[ChatHandler] FULL RESPONSE CONTENT:', response.content);
    
    // Return the full conversation history as expected by ChatInterface
    const fullHistory = [...messages, response];
    const responseData = { success: true, data: fullHistory };
    console.log('[ChatHandler] Final response data:', responseData);
    
    sendResponse(responseData);
  } catch (error) {
    console.error('[ChatHandler] Error sending message:', error);
    console.error('[ChatHandler] Error stack:', error instanceof Error ? error.stack : 'No stack');
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
};

/**
 * Abort ongoing request for a service
 */
export const abortRequest: RequestHandler<{ serviceId: string }, { success: boolean; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    console.log('[ChatHandler] Aborting request for service:', serviceId);
    
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }

    const connector = await getConnector(service);
    
    // Call the abort method on the connector
    if (typeof connector.abortRequest === 'function') {
      connector.abortRequest();
      console.log('[ChatHandler] Request aborted successfully');
    } else {
      console.warn('[ChatHandler] Connector does not support abort');
    }
    
    sendResponse({ success: true });
  } catch (error) {
    console.error('[ChatHandler] Error aborting request:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
};

/**
 * Clear chat history for a service (all sessions)
 */
export const clearChatHistory: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }, _sender, sendResponse) => {
  try {
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }

    const connector = await getConnector(service);
    await connector.clearHistory();
    sendResponse();
  } catch (error) {
    console.error('Error clearing chat history:', error);
    sendResponse();
  }
};

/**
 * Get available models for a service
 */
export const getModels: RequestHandler<{ serviceId: string }, { success: boolean; data?: LLMModel[]; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    const connector = await getConnector(service);
    const models = await connector.getModels();
    sendResponse({ success: true, data: models });
  } catch (error) {
    console.error('Error getting models:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
};

/**
 * Get chat sessions for a service
 */
export const getChatHistory: RequestHandler<{ serviceId: string }, { success: boolean; history?: ChatSession[]; error?: string }> = async (payload, _sender, sendResponse) => {
  try {
    const { serviceId } = payload;
    const service = await getService(serviceId);
    if (!service) {
      throw new Error('Service not found');
    }
    const connector = await getConnector(service);
    const history = await connector.getHistory();
    sendResponse({ success: true, history });
  } catch (error) {
    console.error('Error getting chat history:', error);
    sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
  }
};

export const chatHandlers = {
  sendMessage,
  abortRequest,
  clearChatHistory,
  getModels,
  getChatHistory
};

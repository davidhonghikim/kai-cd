import { useState, useEffect, useCallback } from 'react';
import { storageManager } from '@/storage/storageManager';
import { ChatSession, ChatMessage, Service, LLMModel } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { generateSessionTitle, sortSessionsByDate, hasValidContent } from '@/utils/chatUtils';
import { sendMessage as sendChromeMessage } from '@/utils/chrome';

export function useChatSession(serviceId?: string) {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [activeService, setActiveService] = useState<Service | null>(null);
  const [models, setModels] = useState<LLMModel[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const activeSession = sessions.find(s => s.id === currentSessionId) || null;

  const loadInitialData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const serviceToLoad = serviceId
        ? await sendChromeMessage('getService', { serviceId })
        : await sendChromeMessage('getActiveService');

      if (serviceToLoad?.success && serviceToLoad.service) {
        const currentService = serviceToLoad.service;
        setActiveService(currentService);
        const currentServiceId = currentService.id;

        const allSessions = await storageManager.get<ChatSession[]>(`chatSessions_${currentServiceId}`, []);
        const validSessions = allSessions.filter(hasValidContent);
        setSessions(sortSessionsByDate(validSessions));

        const sessionId = await storageManager.get<string | null>(`currentSessionId_${currentServiceId}`, null);
        setCurrentSessionId(sessionId);

        const modelsResponse = await sendChromeMessage('getModels', { serviceId: currentServiceId });
        if (modelsResponse?.success) {
          setModels(modelsResponse.data);
        } else {
          setModels([]);
          console.warn('Could not load models for service', currentServiceId);
        }
      } else {
        setActiveService(null);
        setSessions([]);
        setCurrentSessionId(null);
        setModels([]);
      }
    } catch (e) {
      console.error('Failed to load chat session data:', e);
      setError('Failed to load chat session data.');
    } finally {
      setIsLoading(false);
    }
  }, [serviceId]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  const saveMessages = useCallback(async (newMessages: ChatMessage[]) => {
    if (!activeService || !currentSessionId) return;

    const updatedSession: ChatSession = {
      id: currentSessionId,
      title: activeSession?.title || generateSessionTitle(newMessages),
      messages: newMessages,
      createdAt: activeSession?.createdAt || Date.now(),
      updatedAt: Date.now(),
      serviceId: activeService.id,
    };

    const key = `chatSessions_${activeService.id}`;
    const allSessions = [...sessions];
    const sessionIndex = allSessions.findIndex(s => s.id === currentSessionId);

    if (sessionIndex > -1) {
      allSessions[sessionIndex] = updatedSession;
    } else {
      allSessions.push(updatedSession);
    }
    await storageManager.set(key, allSessions);
    setSessions(sortSessionsByDate(allSessions));
  }, [activeService, sessions, currentSessionId, activeSession]);


  const sendMessage = useCallback(async (message: string, model: string) => {
    if (!activeService || !activeSession) return;

    const userMessage: ChatMessage = { id: uuidv4(), role: 'user', content: message, timestamp: Date.now() };
    const assistantMessage: ChatMessage = { id: uuidv4(), role: 'assistant', content: '', timestamp: Date.now() };
    
    const newMessages = [...activeSession.messages, userMessage, assistantMessage];
    await saveMessages(newMessages);

    const port = chrome.runtime.connect({ name: 'chat' });
    port.postMessage({
      action: 'streamChat',
      payload: {
        serviceId: activeService.id,
        messages: activeSession.messages.concat(userMessage),
        model,
      },
    });

    port.onMessage.addListener(function handleMessage(msg) {
      if (msg.action === 'streamChunk') {
        setSessions(prevSessions => {
          const updatedSessions = prevSessions.map(session => {
            if (session.id === currentSessionId) {
              const lastMsg = session.messages[session.messages.length - 1];
              lastMsg.content += msg.payload;
              return { ...session, messages: [...session.messages] };
            }
            return session;
          });
          return updatedSessions;
        });
      }
      if (msg.action === 'streamEnd') {
        port.disconnect();
      }
      if (msg.action === 'streamError') {
        setError(msg.payload);
        port.disconnect();
      }
    });

  }, [activeService, activeSession, saveMessages, currentSessionId]);

  const createNewSession = useCallback(async (serviceToUseId: string) => {
    const service = await sendChromeMessage('getService', { serviceId: serviceToUseId });
     if (!service.success) {
      setError(`Service ${serviceToUseId} not found.`);
      return;
    }
    
    await sendChromeMessage('setActiveService', { serviceId: serviceToUseId });
    
    const newSession: ChatSession = {
      id: uuidv4(),
      title: 'New Chat',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      serviceId: serviceToUseId,
    };
    
    const key = `chatSessions_${serviceToUseId}`;
    const allSessions = await storageManager.get<ChatSession[]>(key, []);
    allSessions.push(newSession);
    await storageManager.set(key, allSessions);
    await storageManager.set(`currentSessionId_${serviceToUseId}`, newSession.id);

    // Reload all data for the new service
    await loadInitialData();

  }, [loadInitialData]);
  
  const setActiveSession = useCallback(async (sessionId: string) => {
     if (!activeService) return;
    await storageManager.set(`currentSessionId_${activeService.id}`, sessionId);
    setCurrentSessionId(sessionId);
  }, [activeService]);

  return {
    sessions,
    activeSession,
    models,
    isLoading,
    error,
    setActiveSession,
    createNewSession,
    sendMessage,
  };
} 
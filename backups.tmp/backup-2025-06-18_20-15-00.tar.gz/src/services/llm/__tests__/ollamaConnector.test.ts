import { OllamaConnector } from '../ollamaConnector';
import { Service, ChatMessage, ChatCompletionResponse } from '@/types';

// Mock global fetch
const mockFetch = jest.fn();
global.fetch = mockFetch;

describe('OllamaConnector', () => {
  let connector: OllamaConnector;
  const service: Service = {
    id: 'test-ollama',
    name: 'Test Ollama',
    type: 'ollama',
    url: 'http://test-server:11434',
    apiKey: 'test-key',
    isActive: true,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    enabled: true,
    status: 'active',
    category: 'LLM',
    requiresApiKey: true,
  };

  beforeEach(() => {
    // Clear mock history before each test
    mockFetch.mockClear();
    connector = new OllamaConnector(service);
  });

  it('should send a correctly formatted chat request to the Ollama API', async () => {
    // Arrange
    const messages: ChatMessage[] = [
      { id: '1', role: 'user', content: 'Hello, world!', timestamp: Date.now() },
    ];
    const model = 'gemma3:1b';
    const mockApiResponse: ChatCompletionResponse = {
      model: 'gemma3:1b',
      created_at: new Date().toISOString(),
      message: {
        role: 'assistant',
        content: 'Hi there!',
        // The other fields are not part of the core Ollama response
        id: 'mock-id',
        timestamp: Date.now(),
      },
      done: true,
    };

    // Mock a non-streaming response
    mockFetch.mockResolvedValue(new Response(JSON.stringify(mockApiResponse), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    }));

    // Act
    const result = await connector.chat(messages, model);

    // Assert
    expect(mockFetch).toHaveBeenCalledTimes(1);
    
    // Check request format (body)
    const [_url, options] = mockFetch.mock.calls[0];
    const body = JSON.parse(options.body as string);
    expect(body.model).toBe(model);
    expect(body.messages[0].content).toBe('Hello, world!');

    // Check final output message
    expect(result.role).toBe('assistant');
    expect(result.content).toBe('Hi there!');
  });
  
  it('should handle fetch errors gracefully', async () => {
    // Arrange
    mockFetch.mockRejectedValue(new Error('Network error'));
    const messages: ChatMessage[] = [{ id: '1', role: 'user', content: 'test', timestamp: 123 }];

    // Act & Assert
    await expect(connector.chat(messages, 'gemma3:1b')).rejects.toThrow('Network error');
  });
}); 
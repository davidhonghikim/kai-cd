import { BaseConnector } from "../base/BaseConnector";
import { ChatConnector } from "@/types";
import type { Service, ChatMessage, LLMModel, ChatSession } from "@/types";

/**
 * Connector for Open WebUI
 */
export class OpenWebUIConnector extends BaseConnector<Service> implements ChatConnector {
  constructor(service: Service) {
    super(service);
    console.log(`[OpenWebUIConnector] Created for ${service.name} at ${service.url}`);
  }

  /**
   * Connect to the Open WebUI service
   */
  async connect(): Promise<boolean> {
    try {
      console.log(`[OpenWebUIConnector] Connecting to ${this.service.url}`);
      const status = await this.checkStatus();
      this._isConnected = status.isOnline;
      return status.isOnline;
    } catch (error) {
      console.error(`[OpenWebUIConnector] Connection error:`, error);
      this._isConnected = false;
      return false;
    }
  }

  /**
   * Check the status of the Open WebUI service
   */
  async checkStatus(): Promise<{ isOnline: boolean; details?: any; error?: string }> {
    try {
      console.log(`[OpenWebUIConnector] Checking status of ${this.service.url}`);
      const response = await fetch(new URL('/', this.service.url).toString(), {
        method: 'HEAD',
        cache: 'no-cache',
        credentials: 'omit',
      });
      
      const isOnline = response.ok;
      console.log(`[OpenWebUIConnector] Status check result: ${isOnline ? 'online' : 'offline'}`);
      
      return {
        isOnline,
        details: { status: response.status, statusText: response.statusText }
      };
    } catch (error) {
      console.error(`[OpenWebUIConnector] Status check error:`, error);
      return {
        isOnline: false,
        error: error instanceof Error ? error.message : 'Unknown error checking service status'
      };
    }
  }

  /**
   * Get available models from Open WebUI
   */
  async getModels(): Promise<LLMModel[]> {
    try {
      console.log(`[OpenWebUIConnector] Attempting to fetch models from ${this.service.url}`);
      
      // Try multiple API endpoints that Open WebUI might expose
      const endpoints = [
        '/api/models',
        '/api/v1/models',
        '/api/ollama/models'
      ];
      
      let models: LLMModel[] = [];
      let success = false;
      
      for (const endpoint of endpoints) {
        if (success) break;
        
        try {
          const url = new URL(endpoint, this.service.url).toString();
          console.log(`[OpenWebUIConnector] Trying endpoint: ${url}`);
          
          const response = await fetch(url, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' },
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'omit',
            redirect: 'follow',
          });
          
          if (!response.ok) {
            console.warn(`[OpenWebUIConnector] Endpoint ${endpoint} failed with status: ${response.status}`);
            continue;
          }
          
          const data = await response.json();
          console.log(`[OpenWebUIConnector] Received data from ${endpoint}:`, data);
          
          if (Array.isArray(data)) {
            models = data.map(model => ({
              id: typeof model === 'string' ? model : model.id || model.name || 'unknown',
              name: typeof model === 'string' ? model : model.name || model.id || 'Unknown Model',
              details: typeof model === 'object' ? model : { name: model }
            }));
            success = true;
            console.log(`[OpenWebUIConnector] Successfully parsed ${models.length} models from ${endpoint}`);
            break;
          } else if (data.models && Array.isArray(data.models)) {
            models = data.models.map((model: any) => ({
              id: model.id || model.name || 'unknown',
              name: model.name || model.id || 'Unknown Model',
              details: model
            }));
            success = true;
            console.log(`[OpenWebUIConnector] Successfully parsed ${models.length} models from ${endpoint}`);
            break;
          } else {
            console.warn(`[OpenWebUIConnector] Unexpected data format from ${endpoint}:`, data);
          }
        } catch (endpointError) {
          console.warn(`[OpenWebUIConnector] Error fetching from ${endpoint}:`, endpointError);
        }
      }
      
      // If we couldn't get any models, return a default one
      if (!success || models.length === 0) {
        console.log(`[OpenWebUIConnector] Using default model as fallback`);
        return [{ 
          id: 'open-webui-default', 
          name: 'Open WebUI Default Model',
          details: { type: 'open-webui' }
        }];
      }
      
      return models;
    } catch (error) {
      console.error(`[OpenWebUIConnector] Error fetching models:`, error);
      // Return a default model so the UI doesn't break
      return [{ 
        id: 'open-webui-default', 
        name: 'Open WebUI Default Model',
        details: { type: 'open-webui' }
      }];
    }
  }

  /**
   * Send a message to Open WebUI
   * Note: This is a placeholder as we're using iframe for Open WebUI
   */
  async sendMessage(message: string): Promise<ChatMessage> {
    console.log(`[OpenWebUIConnector] Sending message: ${message}`);
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: 'Please use the Open WebUI interface directly for chat functionality.',
      timestamp: Date.now()
    };
  }

  /**
   * Chat with Open WebUI
   * Note: This is a placeholder as we're using iframe for Open WebUI
   */
  async chat(messages: ChatMessage[], model: string): Promise<ChatMessage> {
    console.log(`[OpenWebUIConnector] Chat with model ${model}, ${messages.length} messages`);
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: 'Please use the Open WebUI interface directly for chat functionality.',
      timestamp: Date.now()
    };
  }

  /**
   * Clear chat history
   * Note: This is a placeholder as we're using iframe for Open WebUI
   */
  async clearHistory(): Promise<void> {
    console.log(`[OpenWebUIConnector] Clear history`);
  }

  /**
   * Get chat history
   * Note: This is a placeholder as we're using iframe for Open WebUI
   */
  async getHistory(): Promise<ChatSession[]> {
    console.log(`[OpenWebUIConnector] Get history`);
    return [];
  }

  /**
   * Disconnect from Open WebUI
   */
  async disconnect(): Promise<void> {
    console.log(`[OpenWebUIConnector] Disconnected from ${this.service.name}`);
  }
} 
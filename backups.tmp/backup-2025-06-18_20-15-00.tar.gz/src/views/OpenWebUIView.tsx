import React from 'react';
import { Service } from '@/types';
import styles from '@/styles/components/sidepanel/SidePanel.module.css';

interface OpenWebUIViewProps {
  service: Service;
}

const OpenWebUIView: React.FC<OpenWebUIViewProps> = ({ service }) => {
  const openInNewTab = () => {
    window.open(service.url, '_blank');
  };

  const handleAction = (action: string) => {
    console.log(`Action ${action} clicked for ${service.name}`);
    // In a real implementation, these would call the Open WebUI API endpoints
    switch (action) {
      case 'chat':
        window.open(`${service.url}/chat`, '_blank');
        break;
      case 'models':
        window.open(`${service.url}/models`, '_blank');
        break;
      case 'documents':
        window.open(`${service.url}/documents`, '_blank');
        break;
      case 'settings':
        window.open(`${service.url}/settings`, '_blank');
        break;
      default:
        openInNewTab();
    }
  };

  return (
    <div className={styles.openWebUIPanel}>
      <h2>Open WebUI Quick Actions</h2>
      
      <div className={styles.actionButtons}>
        <button 
          className={styles.actionButton}
          onClick={() => handleAction('chat')}
        >
          <span>💬</span> New Chat
        </button>
        
        <button 
          className={styles.actionButton}
          onClick={() => handleAction('models')}
        >
          <span>🧠</span> Models
        </button>
        
        <button 
          className={styles.actionButton}
          onClick={() => handleAction('documents')}
        >
          <span>📄</span> Documents
        </button>
        
        <button 
          className={styles.actionButton}
          onClick={() => handleAction('settings')}
        >
          <span>⚙️</span> Settings
        </button>
      </div>
      
      <button 
        className={styles.generateButton}
        onClick={openInNewTab}
      >
        Open Full Interface
      </button>
      
      <div className={styles.serverInfo}>
        <p>Server URL: <a href={service.url} target="_blank" rel="noopener noreferrer">{service.url}</a></p>
      </div>
    </div>
  );
};

export default OpenWebUIView; 
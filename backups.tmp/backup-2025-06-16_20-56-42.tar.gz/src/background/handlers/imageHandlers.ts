import { connectorManager } from "../connectors";
import {
  getServices,
  getImageArtifacts as getArtifactsFromStorage,
  addImageArtifact,
  deleteImageArtifact as deleteArtifactFromStorage,
} from "../utils/storage";
import type {
  RequestHandler,
  ImageArtifact,
  ImageGenConnector,
  ImageGenOptions,
  ImageModel,
} from "../../config/types";

interface GenerateImageRequest {
  serviceId: string;
  prompt: string;
  negativePrompt?: string;
  model?: string;
  options?: Record<string, unknown>;
}

/**
 * Generate an image using a service
 */
export const generateImage: RequestHandler<GenerateImageRequest, any> = async ({
  serviceId,
  prompt,
  negativePrompt,
  model,
  options = {},
}) => {
  console.log('--- Generating Image ---');
  console.log({ serviceId, prompt, negativePrompt, model, options });
  // In the future, this will connect to the actual service and generate an image.
  // For now, we'll simulate a successful response.
  await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate network delay
  return {
    success: true,
    message: "Image generation started.",
    // A real implementation would return an image URL or data
    artifacts: [{
        seed: 12345,
        type: 'image',
        base64: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=' // 1x1 red pixel
    }]
  };
};

/**
 * Stop an ongoing image generation
 */
export const stopGeneration: RequestHandler<{ serviceId: string }, any> = async ({ serviceId }) => {
    console.log(`--- Stopping Generation for ${serviceId} ---`);
    // In the future, this will connect to the service and stop the generation process.
    return { success: true, message: "Image generation stopped." };
};

export const getImageArtifacts: RequestHandler<void, ImageArtifact[]> = async () => {
  try {
    return await getArtifactsFromStorage();
  } catch (error) {
    console.error("Error fetching image artifacts:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to fetch image artifacts: ${errorMessage}`);
  }
};

export const deleteImageArtifact: RequestHandler<{ id: string }, void> = async ({ id }) => {
  if (!id) {
    throw new Error("Artifact ID is required");
  }

  try {
    await deleteArtifactFromStorage(id);
  } catch (error) {
    console.error("Error deleting image artifact:", error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to delete image artifact: ${errorMessage}`);
  }
};

/**
 * Get available LoRAs for a service
 */
export const getLoras: RequestHandler<{ serviceId: string }, ImageModel[]> = async ({ serviceId }) => {
  if (!serviceId) {
    throw new Error("Invalid request: serviceId is required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = await connectorManager.getConnector(service) as ImageGenConnector;
    if (!connector) {
      throw new Error(`Connector for service ${serviceId} could not be created`);
    }

    if (typeof connector.getLoras === 'function') {
      return connector.getLoras();
    }

    return [];
  } catch (error) {
    console.error(`Error getting LoRAs for service ${serviceId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get LoRAs: ${errorMessage}`);
  }
};

/**
 * Get available embeddings for a service
 */
export const getEmbeddings: RequestHandler<{ serviceId: string }, ImageModel[]> = async ({ serviceId }) => {
  if (!serviceId) {
    throw new Error("Invalid request: serviceId is required");
  }

  const services = await getServices();
  const service = services.find((s) => s.id === serviceId);

  if (!service) {
    throw new Error(`Service not found: ${serviceId}`);
  }

  try {
    const connector = await connectorManager.getConnector(service) as ImageGenConnector;
    if (!connector) {
      throw new Error(`Connector for service ${serviceId} could not be created`);
    }

    if (typeof connector.getEmbeddings === 'function') {
      return connector.getEmbeddings();
    }

    return [];
  } catch (error) {
    console.error(`Error getting embeddings for service ${serviceId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get embeddings: ${errorMessage}`);
  }
};

/**
 * Retrieves all image artifacts from storage.
 */
export const getArtifacts: RequestHandler<null, ImageArtifact[]> = async () => {
    return await getImageArtifacts();
};

import { storageManager } from "@/storage/storageManager";
import type { RequestHandler, Service } from '@/config/types';

/**
 * Sets the active service in storage. This determines which service the panel will display.
 * After setting, it broadcasts a message to notify other parts of the extension.
 */
export const setActiveService: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }) => {
  const services = await storageManager.get<Service[]>('services', []);
  const serviceToActivate = services.find(s => s.id === serviceId);
  await storageManager.set('activeService', serviceToActivate || null);
  chrome.runtime.sendMessage({ action: 'activeServiceChanged', payload: serviceToActivate });
};

/**
 * Gets the currently active service from storage.
 */
export const getActiveService: RequestHandler<null, Service | null> = async () => {
  return await storageManager.get<Service | null>('activeService', null);
};

/**
 * Hides the side panel for a specific tab.
 */
export const hidePanel: RequestHandler<{ tabId: number }, void> = async ({ tabId }) => {
  if (tabId) {
    await chrome.sidePanel.setOptions({ tabId, enabled: false });
  } else {
    console.warn('hidePanel called without a tabId.');
  }
};

/**
 * Opens the extension's options page.
 */
export const openOptionsPage: RequestHandler<null, void> = async () => {
  chrome.runtime.openOptionsPage();
};

/**
 * Opens a service's URL in a new tab, loading the extension's tab UI.
 */
export const openServiceInTab: RequestHandler<{ serviceId: string }, void> = async ({ serviceId }) => {
  const services = await storageManager.get<Service[]>('services', []);
  const service = services.find((s) => s.id === serviceId);
  if (service) {
    const tabUrl = chrome.runtime.getURL(`src/tab/index.html?serviceId=${serviceId}`);
    chrome.tabs.create({ url: tabUrl });
  } else {
    throw new Error(`Service with id ${serviceId} or its URL not found.`);
  }
};

import React from 'react';
import { Service, SERVICE_TYPES, SERVICE_TYPE_TO_CATEGORY, SERVICE_CATEGORIES } from '@/config/types';
import ChatInterface from './ChatInterface';
import IframeView from './IframeView';
import A1111View from '@/views/A1111View';
import ComfyUIView from '@/views/ComfyUIView';

interface ViewRouterProps {
  service: Service;
  isTab?: boolean;
}

const ViewRouter: React.FC<ViewRouterProps> = ({ service, isTab = false }) => {
  if (!service) {
    return <div style={{ padding: 32, color: 'red' }}>Error: No service loaded. Please select a service.</div>;
  }
  if (!service.type) {
    return <div style={{ padding: 32, color: 'red' }}>Error: Service type missing. Please check your configuration.</div>;
  }
  const category = SERVICE_TYPE_TO_CATEGORY[service.type];

  // UI-based services should always show their iframe
  if (category === SERVICE_CATEGORIES.UI || category === SERVICE_CATEGORIES.AUTOMATION) {
    return <IframeView url={service.url} serviceName={service.name} />;
  }

  // Image services have different views for tab vs panel
  if (category === SERVICE_CATEGORIES.IMAGE) {
    // For tabs, we want to show the service's full UI
    if (isTab) {
      return <IframeView url={service.url} serviceName={service.name} />;
    }

    // For panels, we show a dedicated quick-use UI
    switch (service.type) {
      case SERVICE_TYPES.A1111:
        return <A1111View service={service} isTab={false} />;
      case SERVICE_TYPES.COMFY_UI:
        return <ComfyUIView service={service} isTab={false} />;
      default:
        // Fallback for a generic image service in a panel
        return <IframeView url={service.url} serviceName={service.name} />;
    }
  }

  // LLM services use the ChatInterface
  if (category === SERVICE_CATEGORIES.LLM) {
    return <ChatInterface service={service} isPanel={!isTab} />;
  }

  // Fallback for any other service type
  console.error('Unknown or unsupported service type:', service.type, service);
  return <div style={{ padding: 32, color: 'red' }}>Error: Unknown or unsupported service type: {service.type}</div>;
};

export default ViewRouter;
